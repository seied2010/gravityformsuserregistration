<?php defined( 'ABSPATH' ) || exit; ?>
<?php $journal = hq_section_query( 'journal' ); ?>
<section id="journal" class="hq-section hq-journal-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker"><?php echo esc_html( get_theme_mod( 'hq_journal_kicker', 'برای خواندن و عمیق‌تر دیدن' ) ); ?></p><h2><?php echo esc_html( get_theme_mod( 'hq_journal_title', 'یادداشت‌ها و پژوهش‌ها' ) ); ?></h2><p><?php echo esc_html( get_theme_mod( 'hq_journal_description', 'روایت‌ها، پرسش‌ها و نگاه‌هایی به تاریخ قم.' ) ); ?></p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'journal' ) ); ?>">همهٔ نوشته‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-journal-grid">
		<?php while ( $journal->have_posts() ) : $journal->the_post(); ?>
			<article class="hq-journal-card"><a class="hq-journal-image" href="<?php the_permalink(); ?>"><?php hq_post_image( get_the_ID() ); ?></a><div><p class="hq-article-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><span>·</span><?php the_author(); ?></p><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 22 ) ); ?></p><a class="hq-text-link" href="<?php the_permalink(); ?>">ادامهٔ روایت <?php echo hq_icon( 'arrow' ); ?></a></div></article>
		<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<?php if ( ! $journal->post_count ) : ?><p class="hq-empty-state">هنوز یادداشتی منتشر نشده است.</p><?php endif; ?>
	</div>
</section>
