<?php
defined( 'ABSPATH' ) || exit;

function hq_section_categories( $section ) {
	$names = array( 'wiki' => array( 'ویکی قم', 'دانشنامه قم', 'دانشنامه' ), 'places' => array( 'قم‌شناسی', 'قم شناسی' ), 'journal' => array( 'یادداشت‌ها و پژوهش‌ها', 'یادداشت ها و پژوهش ها' ), 'history' => array( 'مشاهیر و چهره‌ها', 'مشاهیر و چهره ها' ) );
	$normalize = static function ( $value ) { return str_replace( array( ' ', '‌', '-' ), '', $value ); };
	$wanted = array_map( $normalize, $names[ $section ] ?? array() );
	$ids = array();
	foreach ( get_categories( array( 'hide_empty' => false ) ) as $category ) {
		$slugs = array( 'wiki' => 'qomwiki', 'places' => 'qom-studies', 'journal' => 'essays', 'history' => 'celebrities' );
		if ( in_array( $normalize( $category->name ), $wanted, true ) || $category->slug === ( $slugs[ $section ] ?? '' ) ) { $ids[] = $category->term_id; }
	}
	return $ids;
}

function hq_brand_logo() {
	$logo_id = (int) get_theme_mod( 'custom_logo' );
	if ( ! $logo_id ) { return ''; }
	return wp_get_attachment_image( $logo_id, 'medium', false, array( 'class' => 'hq-brand-logo', 'alt' => get_bloginfo( 'name' ) ) );
}

function hq_is_about_page() {
	return is_page() && ( (int) get_theme_mod( 'hq_about_page_id', 0 ) === (int) get_queried_object_id() || false !== mb_strpos( (string) get_the_title(), 'درباره' ) );
}

function hq_is_contact_page() {
	if ( ! is_page() ) { return false; }
	$title = (string) get_the_title();
	return false !== mb_strpos( $title, 'تماس' ) || false !== mb_strpos( $title, 'ارتباط با ما' );
}

function hq_iran_world_category() {
	$selected = (int) get_theme_mod( 'hq_footer_iran_category', 0 );
	if ( $selected ) {
		$category = get_category( $selected );
		if ( $category instanceof WP_Term && ! is_wp_error( $category ) ) { return $category; }
	}
	foreach ( array( 'ایران و جهان', 'ایران‌ و جهان' ) as $name ) {
		$category = get_term_by( 'name', $name, 'category' );
		if ( $category instanceof WP_Term ) { return $category; }
	}
	foreach ( array( 'iran-world', 'iran-and-world' ) as $slug ) {
		$category = get_category_by_slug( $slug );
		if ( $category instanceof WP_Term ) { return $category; }
	}
	return null;
}

function hq_sanitize_whatsapp_number( $value ) {
	$english_digits = strtr( (string) $value, array( '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9', '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9' ) );
	$digits = preg_replace( '/[^0-9]/', '', $english_digits );
	return strlen( $digits ) >= 8 && strlen( $digits ) <= 15 ? $digits : '';
}

function hq_sanitize_bale_username( $value ) {
	return preg_replace( '/[^A-Za-z0-9_]/', '', ltrim( (string) $value, '@' ) );
}

function hq_contact_channels() {
	$whatsapp = hq_sanitize_whatsapp_number( get_theme_mod( 'hq_whatsapp_number', '' ) );
	$bale = hq_sanitize_bale_username( get_theme_mod( 'hq_bale_username', 'mahyarmusavi' ) );
	if ( ! $whatsapp && ! $bale ) { return; }
	echo '<aside class="hq-contact-channels" aria-label="راه‌های ارتباط در پیام‌رسان‌ها"><h2>ارتباط در پیام‌رسان‌ها</h2><div class="hq-contact-links">';
	if ( $whatsapp ) {
		echo '<a class="hq-channel-link" href="' . esc_url( 'https://wa.me/' . $whatsapp ) . '" target="_blank" rel="noopener noreferrer nofollow">' . hq_icon( 'whatsapp' ) . ' واتس‌اپ</a>';
	}
	if ( $bale ) {
		echo '<a class="hq-channel-link" href="' . esc_url( 'https://ble.ir/' . $bale ) . '" target="_blank" rel="noopener noreferrer nofollow">' . hq_icon( 'bale' ) . ' بله</a>';
	}
	echo '</div></aside>';
}

add_action( 'customize_register', function ( $customizer ) {
	$customizer->add_section( 'hq_home', array( 'title' => 'صفحهٔ اصلی همیار قم', 'priority' => 30 ) );
	$customizer->add_setting( 'hq_hero_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
	$customizer->add_control( new WP_Customize_Image_Control( $customizer, 'hq_hero_image', array( 'label' => 'تصویر بخش آغازین', 'section' => 'hq_home' ) ) );
	$customizer->add_setting( 'hq_hero_alt', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	$customizer->add_control( 'hq_hero_alt', array( 'label' => 'توضیح تصویر برای دسترس‌پذیری', 'section' => 'hq_home', 'type' => 'text' ) );
	$customizer->add_setting( 'hq_hero_side', array( 'default' => 'left', 'sanitize_callback' => static function ( $value ) { return in_array( $value, array( 'left', 'right' ), true ) ? $value : 'left'; } ) );
	$customizer->add_control( 'hq_hero_side', array( 'label' => 'جای تصویر در صفحه اصلی', 'section' => 'hq_home', 'type' => 'select', 'choices' => array( 'left' => 'سمت چپ', 'right' => 'سمت راست' ) ) );
	foreach ( array( 'x' => 'جای برش افقی عکس', 'y' => 'جای برش عمودی عکس' ) as $axis => $label ) {
		$customizer->add_setting( 'hq_hero_focus_' . $axis, array( 'default' => '50', 'sanitize_callback' => static function ( $value ) { return in_array( (string) $value, array( '0', '25', '50', '75', '100' ), true ) ? (string) $value : '50'; } ) );
		$customizer->add_control( 'hq_hero_focus_' . $axis, array( 'label' => $label, 'section' => 'hq_home', 'type' => 'select', 'choices' => array( '0' => 'ابتدا', '25' => '۲۵ درصد', '50' => 'وسط', '75' => '۷۵ درصد', '100' => 'انتها' ) ) );
	}
	$customizer->add_section( 'hq_contact', array( 'title' => 'اطلاعات تماس و پیام‌رسان‌ها', 'priority' => 31 ) );
	$customizer->add_setting( 'hq_whatsapp_number', array( 'default' => '', 'sanitize_callback' => 'hq_sanitize_whatsapp_number' ) );
	$customizer->add_control( 'hq_whatsapp_number', array( 'label' => 'شماره واتساپ با کد کشور', 'description' => 'مثال: 989121234567. بدون صفر ابتدا، + یا فاصله. برای مخفی‌شدن پیوند خالی بگذارید.', 'section' => 'hq_contact', 'type' => 'text' ) );
	$customizer->add_setting( 'hq_bale_username', array( 'default' => 'mahyarmusavi', 'sanitize_callback' => 'hq_sanitize_bale_username' ) );
	$customizer->add_control( 'hq_bale_username', array( 'label' => 'شناسه بله', 'description' => 'شناسه بدون @؛ برای مخفی‌شدن پیوند خالی بگذارید.', 'section' => 'hq_contact', 'type' => 'text' ) );
	$customizer->add_section( 'hq_footer_config', array( 'title' => 'پیوندهای پایین صفحه', 'priority' => 32 ) );
	$choices = array( 0 => 'انتخاب خودکار بر اساس عنوان دسته' );
	foreach ( get_categories( array( 'hide_empty' => false ) ) as $category ) { $choices[ $category->term_id ] = $category->name; }
	$customizer->add_setting( 'hq_footer_iran_category', array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
	$customizer->add_control( 'hq_footer_iran_category', array( 'label' => 'دسته ایران و جهان', 'description' => 'در صورت متفاوت‌بودن نام دسته، آن را از فهرست انتخاب کنید.', 'section' => 'hq_footer_config', 'type' => 'select', 'choices' => $choices ) );
} );

add_action( 'init', function () {
	foreach ( array( 'hq_wiki' => array( 'دانشنامه', 'مدخل دانشنامه', 'encyclopedia' ), 'hq_place' => array( 'اماکن تاریخی', 'مکان تاریخی', 'heritage' ) ) as $type => $labels ) {
		register_post_type( $type, array(
			'labels' => array( 'name' => $labels[0], 'singular_name' => $labels[1], 'add_new_item' => 'افزودن ' . $labels[1], 'edit_item' => 'ویرایش ' . $labels[1] ),
			'public' => true, 'show_in_rest' => true, 'has_archive' => true,
			'rewrite' => array( 'slug' => $labels[2] ),
			'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ),
			'menu_icon' => 'hq_wiki' === $type ? 'dashicons-book-alt' : 'dashicons-location-alt',
		) );
	}
} );

add_action( 'after_switch_theme', function () {
	// The next init registers the content types before refreshing their routes.
	update_option( 'hq_flush_routes', '1', false );
} );
add_action( 'init', function () {
	if ( get_option( 'hq_flush_routes' ) || '2.5.0' !== get_option( 'hq_routes_version' ) ) {
		flush_rewrite_rules( false );
		delete_option( 'hq_flush_routes' );
		update_option( 'hq_routes_version', '2.5.0', false );
	}
}, 20 );

function hq_first_letter( $title ) {
	$title = preg_replace( '/^[\s\x{200c}\x{200d}\x{200e}\x{200f}]+/u', '', wp_strip_all_tags( $title ) );
	$letter = mb_substr( $title, 0, 1, 'UTF-8' );
	$map = array( 'ا' => 'الف', 'أ' => 'الف', 'إ' => 'الف', 'ٱ' => 'الف', 'ك' => 'ک', 'ي' => 'ی', 'ئ' => 'ی', 'ة' => 'ه' );
	return $map[ $letter ] ?? $letter;
}

function hq_icon( $name ) {
	$paths = array(
		'whatsapp' => '<path d="M21 11.5a9 9 0 0 1-13.5 7.8L3 21l1.5-4.7A9 9 0 1 1 21 11.5Z"/><path d="M8 7c0 5 4 9 8 9l1-3-3-1-1 1c-1.5-.6-2.4-1.5-3-3l1-1-1-2Z"/>',
		'bale' => '<path d="M20 14a7 7 0 0 1-7 7H4l2-4A8 8 0 1 1 20 14Z"/><path d="m8 11 3 3 6-7"/>',
		'arch' => '<path d="M4 21V10a8 8 0 0 1 16 0v11M8 21V11a4 4 0 0 1 8 0v10M2 21h20M12 2v3"/>',
		'search' => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
		'book' => '<path d="M12 5v16M3 4c4-1 7 0 9 2 2-2 5-3 9-2v15c-4-1-7 0-9 2-2-2-5-3-9-2z"/>',
		'pin' => '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
		'quill' => '<path d="m4 20 5-9L20 3l1 1-8 11-9 5Zm5-9 4 4M3 21l7-7"/>',
		'arrow' => '<path d="M20 12H4m6-6-6 6 6 6"/>',
		'user' => '<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
		'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
		'route' => '<path d="m12 2 10 10-10 10L2 12 10 2zM8 15v-5h8m-3-3 3 3-3 3"/>',
	);
	return '<svg class="hq-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( $paths[ $name ] ?? $paths['arch'] ) . '</svg>';
}

function hq_post_image( $post_id, $class = '' ) {
	if ( has_post_thumbnail( $post_id ) ) {
		echo get_the_post_thumbnail( $post_id, 'medium_large', array( 'class' => $class, 'loading' => 'lazy' ) );
	} else {
		echo '<img class="' . esc_attr( $class ) . '" src="' . esc_url( get_theme_file_uri( 'assets/heritage.svg' ) ) . '" alt="تصویرسازی معماری ایرانی" loading="lazy" width="720" height="840">';
	}
}

add_action( 'add_meta_boxes', function ( $post_type ) {
	if ( ! in_array( $post_type, array( 'post', 'hq_place' ), true ) ) { return; }
	add_meta_box( 'hq-place-location', 'نشانی و مسیریابی', function ( $post ) {
		wp_nonce_field( 'hq_place_location', 'hq_place_nonce' );
		foreach ( array( 'address' => 'نشانی', 'latitude' => 'عرض جغرافیایی', 'longitude' => 'طول جغرافیایی' ) as $key => $label ) {
			echo '<p><label>' . esc_html( $label ) . '<br><input class="widefat" name="hq_' . esc_attr( $key ) . '" value="' . esc_attr( get_post_meta( $post->ID, '_hq_' . $key, true ) ) . '"' . ( 'address' === $key ? '' : ' inputmode="decimal" dir="ltr"' ) . '></label></p>';
		}
	}, $post_type );
} );
add_action( 'save_post', function ( $post_id ) {
	if ( ! in_array( get_post_type( $post_id ), array( 'post', 'hq_place' ), true ) ) { return; }
	if ( ! isset( $_POST['hq_place_nonce'] ) || ! is_string( $_POST['hq_place_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hq_place_nonce'] ) ), 'hq_place_location' ) || ! current_user_can( 'edit_post', $post_id ) || wp_is_post_revision( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}
	foreach ( array( 'address' => 0, 'latitude' => 90, 'longitude' => 180 ) as $key => $limit ) {
		if ( ! isset( $_POST[ 'hq_' . $key ] ) || ! is_string( $_POST[ 'hq_' . $key ] ) ) { continue; }
		$value = sanitize_text_field( wp_unslash( $_POST[ 'hq_' . $key ] ) );
		if ( $limit && ( ! is_numeric( $value ) || abs( (float) $value ) > $limit ) ) {
			delete_post_meta( $post_id, '_hq_' . $key );
			continue;
		}
		update_post_meta( $post_id, '_hq_' . $key, $value );
	}
} );

function hq_route_url( $post_id ) {
	$lat = get_post_meta( $post_id, '_hq_latitude', true );
	$lng = get_post_meta( $post_id, '_hq_longitude', true );
	if ( '' === $lat || '' === $lng || ! is_numeric( $lat ) || ! is_numeric( $lng ) || abs( (float) $lat ) > 90 || abs( (float) $lng ) > 180 ) { return ''; }
	return add_query_arg( array( 'api' => '1', 'destination' => $lat . ',' . $lng ), 'https://www.google.com/maps/dir/' );
}
