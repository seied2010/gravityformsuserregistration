<?php
/** Every category uses the same journal card layout and the native archive query. */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" class="hq-container hq-content">
	<header class="hq-directory-head"><p class="hq-kicker"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">خانه</a> / بایگانی</p><h1><?php single_cat_title(); ?></h1><?php the_archive_description( '<div class="hq-archive-description">', '</div>' ); ?></header>
	<?php if ( have_posts() ) : ?>
	<div class="hq-journal-grid">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'hq-journal-card' ); ?>>
			<a class="hq-journal-image" href="<?php the_permalink(); ?>"><?php hq_post_image( get_the_ID() ); ?></a>
			<div><p class="hq-article-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><span>·</span><?php the_author(); ?></p><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 22 ) ); ?></p><a class="hq-text-link" href="<?php the_permalink(); ?>">ادامهٔ روایت <?php echo hq_icon( 'arrow' ); ?></a></div>
		</article>
	<?php endwhile; ?>
	</div>
	<?php the_posts_pagination( array( 'prev_text' => 'صفحهٔ قبل', 'next_text' => 'صفحهٔ بعد' ) ); ?>
	<?php else : ?><p class="hq-empty-state">هنوز مطلبی در این دسته منتشر نشده است.</p><?php endif; ?>
</main>
<?php get_footer(); ?>
