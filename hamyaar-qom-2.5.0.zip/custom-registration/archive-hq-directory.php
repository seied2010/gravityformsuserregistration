<?php
/** Full, paginated directory. Homepage contains an intentionally small sample only. */
defined( 'ABSPATH' ) || exit;
$section = hq_request_directory_section();
if ( ! $section ) { wp_safe_redirect( home_url( '/' ) ); exit; }
$paged = isset( $_GET['hq_page'] ) && is_scalar( $_GET['hq_page'] ) ? min( 100000, max( 1, absint( wp_unslash( $_GET['hq_page'] ) ) ) ) : 1;
$search = isset( $_GET['hq_find'] ) && is_string( $_GET['hq_find'] ) ? sanitize_text_field( wp_unslash( $_GET['hq_find'] ) ) : '';
$letter = hq_directory_requested_letter();
$args = hq_section_query_args( $section, 24, $paged, $search );
if ( $letter ) { $args['hq_directory_letter'] = $letter; }
$query = new WP_Query( $args );
get_header();
?>
<main id="main-content" class="hq-container hq-content hq-directory">
	<div class="hq-directory-head">
		<p class="hq-kicker"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">صفحه اصلی</a> / فهرست کامل</p>
		<h1><?php echo esc_html( hq_managed_sections()[ $section ] ); ?></h1>
		<p>نمایش <?php echo esc_html( number_format_i18n( $query->found_posts ) ); ?> مطلب منتشرشده از منبع انتخابی این بخش؛ امکان مشاهده تمام صفحات با صفحه‌بندی.</p>
		<form action="<?php echo esc_url( hq_section_url( $section ) ); ?>" method="get" class="hq-directory-search" role="search">
			<?php if ( ! get_option( 'permalink_structure' ) ) : ?><input type="hidden" name="hq_directory" value="<?php echo esc_attr( $section ); ?>"><?php endif; ?>
			<label for="hq-directory-find" class="screen-reader-text">جستجو در این فهرست</label>
			<input type="search" id="hq-directory-find" name="hq_find" value="<?php echo esc_attr( $search ); ?>" placeholder="عنوان یا عبارت مورد نظر…">
			<button class="hq-btn hq-btn-primary" type="submit">جستجو</button>
		</form>
	    <nav class="hq-directory-alphabet" aria-label="فهرست الفبایی">
	        <a class="hq-az-btn<?php echo '' === $letter ? ' active' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'hq_find' => $search ), hq_section_url( $section ) ) ); ?>">همه</a>
	        <?php foreach ( hq_directory_letters() as $initial ) : ?><a class="hq-az-btn<?php echo $letter === $initial ? ' active' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'hq_letter' => $initial, 'hq_find' => $search ), hq_section_url( $section ) ) ); ?>"><?php echo esc_html( $initial ); ?></a><?php endforeach; ?>
	    </nav>
	</div>
	<?php if ( $query->have_posts() ) : ?>
		<div class="hq-content-grid">
		<?php while ( $query->have_posts() ) : $query->the_post(); ?>
			<article <?php post_class( 'hq-card hq-directory-card' ); ?>>
				<?php if ( has_post_thumbnail() ) : ?><a href="<?php the_permalink(); ?>" class="hq-archive-image"><?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) ); ?></a><?php endif; ?>
				<div class="hq-directory-card-body"><p class="hq-archive-meta"><?php echo esc_html( get_the_date() ); ?></p><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><p class="hq-archive-excerpt"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 26 ) ); ?></p><a href="<?php the_permalink(); ?>" class="hq-text-link">مطالعه مطلب <?php echo hq_icon( 'arrow' ); ?></a></div>
			</article>
		<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<?php
		$base = add_query_arg( array( 'hq_find' => $search, 'hq_letter' => $letter, 'hq_page' => '%#%' ), hq_section_url( $section ) );
		echo '<nav class="hq-directory-pagination" aria-label="صفحه‌بندی فهرست">' . wp_kses_post( paginate_links( array( 'base' => $base, 'format' => '', 'current' => $paged, 'total' => $query->max_num_pages, 'prev_text' => 'قبلی', 'next_text' => 'بعدی' ) ) ) . '</nav>';
		?>
	<?php else : ?><p class="hq-empty-state">با منبع و فیلتر فعلی محتوایی پیدا نشد. اگر نوشته‌های قدیمی را نمی‌بینید، از مدیریت سایت ← ابزارها ← گزارش منابع همیار، نوع و شمار واقعی نوشته‌ها را بررسی کنید.</p><?php endif; ?>
</main>
<?php get_footer(); ?>
