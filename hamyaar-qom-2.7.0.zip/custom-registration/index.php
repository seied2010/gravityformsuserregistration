<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" class="hq-container hq-content">
<?php if ( is_search() ) : ?><h1>نتایج جستجو برای «<?php echo esc_html( get_search_query() ); ?>»</h1><?php get_search_form(); ?><?php elseif ( is_archive() ) : ?><h1><?php if ( is_category() ) { single_cat_title(); } elseif ( is_tag() ) { single_tag_title(); } elseif ( is_tax() ) { single_term_title(); } elseif ( is_post_type_archive() ) { post_type_archive_title(); } else { echo esc_html( get_the_archive_title() ); } ?></h1><?php endif; ?>
<?php if ( have_posts() ) : ?>
	<?php if ( ! is_singular() ) { echo '<div class="hq-journal-grid">'; } ?>
	<?php while ( have_posts() ) : the_post(); ?>
		<?php if ( is_singular() ) : ?>
			<article <?php post_class( array_merge( array( 'hq-entry', hq_is_about_page() ? 'hq-entry--about' : '', hq_is_contact_page() ? 'hq-entry--contact' : '' ), hq_single_layout( get_the_ID() ) ) ); ?>>
				<p class="hq-kicker"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">خانه</a> / <?php echo esc_html( get_the_title() ); ?></p>
				<h1><?php the_title(); ?></h1>
				<?php if ( 'page' !== get_post_type() ) : ?><p class="hq-entry-meta"><?php echo esc_html( get_the_date() ); ?> · <?php the_author(); ?></p><?php endif; ?>
				<?php if ( has_post_thumbnail() ) : ?><figure class="hq-entry-featured"><?php the_post_thumbnail( 'large', array( 'loading' => 'eager', 'sizes' => '(min-width: 1600px) 1300px, 90vw' ) ); ?></figure><?php endif; ?>
				<div class="hq-entry-content"><?php the_content(); wp_link_pages(); ?></div>
				<?php if ( hq_is_contact_page() ) { hq_contact_channels(); } ?>
				<?php $route = hq_route_url( get_the_ID() ); if ( $route ) : ?><a class="hq-route-link" href="<?php echo esc_url( $route ); ?>" target="_blank" rel="noopener noreferrer"><?php echo hq_icon( 'route' ); ?>مسیریابی</a><?php endif; ?>
			</article>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'card' ); ?>
		<?php endif; ?>
	<?php endwhile; ?>
	<?php if ( ! is_singular() ) { echo '</div>'; } ?>
	<?php the_posts_pagination( array( 'prev_text' => 'صفحهٔ قبل', 'next_text' => 'صفحهٔ بعد' ) ); ?>
<?php else : ?>
	<h1><?php echo is_search() ? 'نتیجه‌ای پیدا نشد' : 'محتوایی پیدا نشد'; ?></h1>
	<p>عبارت دیگری را جستجو کنید یا به <a href="<?php echo esc_url( home_url( '/' ) ); ?>">صفحهٔ اصلی</a> برگردید.</p>
	<?php if ( ! is_search() ) { get_search_form(); } ?>
<?php endif; ?>
</main>
<?php get_footer(); ?>
