<?php
/** Shared journal card for homepage, archives, search and section directories. */
defined( 'ABSPATH' ) || exit;
$heading = isset( $args['heading'] ) && 'h3' === $args['heading'] ? 'h3' : 'h2';
?>
<article <?php post_class( 'hq-journal-card' ); ?>>
	<a class="hq-journal-image" href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>"><?php hq_post_image( get_the_ID() ); ?></a>
	<div class="hq-journal-card-body"><p class="hq-article-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><span>·</span><?php the_author(); ?></p>
		<<?php echo $heading; ?>><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></<?php echo $heading; ?>>
		<p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 22 ) ); ?></p>
		<a class="hq-text-link" href="<?php the_permalink(); ?>">ادامهٔ روایت <?php echo hq_icon( 'arrow' ); ?></a>
	</div>
</article>
