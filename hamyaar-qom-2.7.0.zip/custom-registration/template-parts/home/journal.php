<?php defined( 'ABSPATH' ) || exit; ?>
<?php $journal = hq_section_query( 'journal' ); ?>
<section id="journal" class="hq-section hq-journal-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker"><?php echo esc_html( get_theme_mod( 'hq_journal_kicker', 'برای خواندن و عمیق‌تر دیدن' ) ); ?></p><h2><?php echo esc_html( get_theme_mod( 'hq_journal_title', 'یادداشت‌ها و پژوهش‌ها' ) ); ?></h2><p><?php echo esc_html( get_theme_mod( 'hq_journal_description', 'روایت‌ها، پرسش‌ها و نگاه‌هایی به تاریخ قم.' ) ); ?></p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'journal' ) ); ?>">همهٔ نوشته‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-journal-grid">
		<?php while ( $journal->have_posts() ) : $journal->the_post(); ?>
			<?php get_template_part( 'template-parts/content', 'card', array( 'heading' => 'h3' ) ); ?>
		<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<?php if ( ! $journal->post_count ) : ?><p class="hq-empty-state">هنوز یادداشتی منتشر نشده است.</p><?php endif; ?>
	</div>
</section>
