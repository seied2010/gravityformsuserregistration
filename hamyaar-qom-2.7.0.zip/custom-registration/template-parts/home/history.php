<?php defined( 'ABSPATH' ) || exit; ?>
<?php $figures = hq_section_query( 'history' ); ?>
<?php if ( $figures->have_posts() ) : ?>
<section id="figures" class="hq-section hq-figures-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker"><?php echo esc_html( get_theme_mod( 'hq_history_kicker', 'نام‌هایی در حافظهٔ شهر' ) ); ?></p><h2><?php echo esc_html( get_theme_mod( 'hq_history_title', 'مشاهیر و چهره‌ها' ) ); ?></h2><p><?php echo esc_html( get_theme_mod( 'hq_history_description', 'آشنایی با کسانی که نامشان با سرگذشت قم پیوند خورده است.' ) ); ?></p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'history' ) ); ?>">همهٔ روایت‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-figures-grid"><?php while ( $figures->have_posts() ) : $figures->the_post(); ?><a class="hq-figure-card hq-card" href="<?php the_permalink(); ?>"><span class="hq-figure-image"><?php hq_post_image( get_the_ID() ); ?><span class="hq-figure-title"><?php the_title(); ?></span></span><span class="hq-text-link">خواندن روایت <?php echo hq_icon( 'arrow' ); ?></span></a><?php endwhile; wp_reset_postdata(); ?></div>
	</div>
</section>
<?php endif; ?>
