<?php defined( 'ABSPATH' ) || exit; ?>
<?php $places = hq_section_query( 'places' ); ?>
<section id="heritage" class="hq-section hq-heritage-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker"><?php echo esc_html( get_theme_mod( 'hq_places_kicker', 'رد پای تاریخ در کوچه‌های شهر' ) ); ?></p><h2><?php echo esc_html( get_theme_mod( 'hq_places_title', 'قم‌شناسی' ) ); ?></h2><p><?php echo esc_html( get_theme_mod( 'hq_places_description', 'میراثی که دیدنی‌ست' ) ); ?></p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'places' ) ); ?>">همهٔ مکان‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-places-grid">
		<?php while ( $places->have_posts() ) : $places->the_post(); $route = hq_route_url( get_the_ID() ); ?>
			<article class="hq-place-card hq-card"><a class="hq-place-image" href="<?php the_permalink(); ?>"><?php hq_post_image( get_the_ID() ); ?><span class="hq-image-label"><?php echo hq_icon( 'pin' ); ?><?php echo esc_html( get_theme_mod( 'hq_places_title', 'قم‌شناسی' ) ); ?></span></a><div class="hq-place-content"><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 22 ) ); ?></p><div class="hq-place-actions"><a class="hq-text-link" href="<?php the_permalink(); ?>">شناخت بیشتر <?php echo hq_icon( 'arrow' ); ?></a><?php if ( $route ) : ?><a class="hq-route-link" href="<?php echo esc_url( $route ); ?>" target="_blank" rel="noopener noreferrer"><?php echo hq_icon( 'route' ); ?>مسیریابی</a><?php endif; ?></div></div></article>
		<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<?php if ( ! $places->post_count ) : ?><p class="hq-empty-state">هنوز مکانی در این بخش منتشر نشده است.</p><?php endif; ?>
	</div>
</section>
