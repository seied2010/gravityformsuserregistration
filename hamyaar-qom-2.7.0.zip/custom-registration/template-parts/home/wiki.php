<?php defined( 'ABSPATH' ) || exit; ?>
<?php
$wiki = hq_section_query( 'wiki' );
$letters = array_merge( array( 'همه' ), hq_directory_letters() );
?>
<section id="encyclopedia" class="hq-section hq-wiki-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker"><?php echo esc_html( get_theme_mod( 'hq_wiki_kicker', 'واژه به واژه، نزدیک‌تر به قم' ) ); ?></p><h2><?php echo esc_html( get_theme_mod( 'hq_wiki_title', 'دانشنامه قم' ) ); ?></h2><p><?php echo esc_html( get_theme_mod( 'hq_wiki_description', 'جست‌وجویی میان نام‌ها، مکان‌ها و روایت‌های شهر.' ) ); ?></p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'wiki' ) ); ?>">همهٔ مدخل‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-wiki-tools"><label class="hq-wiki-search" for="wiki-search-input"><?php echo hq_icon( 'search' ); ?><span class="screen-reader-text">جستجو میان مدخل‌های این بخش</span><input id="wiki-search-input" type="search" placeholder="جستجو میان مدخل‌های تازه…" autocomplete="off"></label><span class="hq-wiki-count" aria-live="polite" data-total="<?php echo esc_attr( $wiki->post_count ); ?>"><?php echo esc_html( number_format_i18n( $wiki->post_count ) ); ?> مدخل در این بخش</span></div>
		<div class="hq-az-list" role="group" aria-label="رفتن به فهرست کامل هر حرف از دانشنامه">
		<?php foreach ( $letters as $letter ) : ?><a class="hq-az-btn" href="<?php echo esc_url( 'همه' === $letter ? hq_section_url( 'wiki' ) : add_query_arg( 'hq_letter', $letter, hq_section_url( 'wiki' ) ) ); ?>" title="نمایش همه مدخل‌های حرف <?php echo esc_attr( $letter ); ?>"><?php echo esc_html( $letter ); ?></a><?php endforeach; ?>
		</div>
		<div class="hq-wiki-grid">
		<?php while ( $wiki->have_posts() ) : $wiki->the_post(); ?>
			<a class="hq-wiki-card hq-card" href="<?php the_permalink(); ?>" data-letter="<?php echo esc_attr( hq_first_letter( get_the_title() ) ); ?>" data-title="<?php echo esc_attr( get_the_title() ); ?>"><span class="hq-wiki-initial"><?php echo esc_html( hq_first_letter( get_the_title() ) ); ?></span><span><strong><?php the_title(); ?></strong><small><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 10 ) ); ?></small></span><?php echo hq_icon( 'arrow' ); ?></a>
		<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<p class="hq-empty-state" id="hq-wiki-empty"<?php if ( $wiki->post_count ) { echo ' hidden'; } ?>><?php echo $wiki->post_count ? 'مدخلی با این حرف یا عبارت پیدا نشد.' : 'هنوز مدخلی در دانشنامه منتشر نشده است.'; ?></p>
	</div>
</section>
