<?php defined( 'ABSPATH' ) || exit; ?>
<section class="hq-paths" aria-label="مسیرهای شناخت قم">
	<div class="hq-container hq-path-grid">
	<?php foreach ( array(
        array( 'book', 'wiki', 'دانشنامهٔ قم', 'از نام‌ها، واژه‌ها و روایت‌ها بیشتر بدانید.', '#encyclopedia' ),
        array( 'arch', 'places', 'قم‌شناسی', 'بناها و محله‌های تاریخی را از نو بشناسید.', '#heritage' ),
        array( 'quill', 'journal', 'یادداشت و پژوهش', 'با نگاه پژوهشگران، به گذشته سفر کنید.', '#journal' ),
    ) as $path ) :
        $path_title = get_theme_mod( 'hq_path_' . $path[1] . '_title', $path[2] );
        $path_description = get_theme_mod( 'hq_path_' . $path[1] . '_description', $path[3] );
        $path_url = get_theme_mod( 'hq_path_' . $path[1] . '_url', '' ) ?: ( hq_home_block_enabled( $path[1] ) ? $path[4] : hq_section_url( $path[1] ) );
    ?>
		<a class="hq-path" href="<?php echo esc_url( $path_url ); ?>"><span class="hq-path-icon"><?php echo hq_icon( $path[0] ); ?></span><span><strong><?php echo esc_html( $path_title ); ?></strong><small><?php echo esc_html( $path_description ); ?></small></span><?php echo hq_icon( 'arrow' ); ?></a>
	<?php endforeach; ?>
	</div>
</section>
