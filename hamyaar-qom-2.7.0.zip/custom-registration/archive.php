<?php
/** One archive layout for categories, tags, taxonomies, dates and authors. */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" class="hq-container hq-content hq-archive">
	<header class="hq-directory-head"><p class="hq-kicker"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">خانه</a> / بایگانی</p><h1><?php if ( is_category() ) { single_cat_title(); } else { echo wp_kses_post( get_the_archive_title() ); } ?></h1><?php the_archive_description( '<div class="hq-archive-description">', '</div>' ); ?></header>
	<?php if ( have_posts() ) : ?>
	<div class="hq-journal-grid">
		<?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'card' ); endwhile; ?>
	</div>
	<?php the_posts_pagination( array( 'prev_text' => 'صفحهٔ قبل', 'next_text' => 'صفحهٔ بعد' ) ); ?>
	<?php else : ?><p class="hq-empty-state">هنوز مطلبی در این بایگانی منتشر نشده است.</p><?php endif; ?>
</main>
<?php get_footer(); ?>
