/* Native Customizer sort/checkbox controls, no frontend dependency. */
(function ($) {
  'use strict';
  function syncOrder($control) {
    var value = [];
    $control.find('.hq-customizer-sortable > li').each(function () {
      value.push({ id: $(this).data('id'), enabled: $(this).find('input[type="checkbox"]').prop('checked') });
    });
    $control.find('.hq-sortable-value').val(JSON.stringify(value)).trigger('input').trigger('change');
  }
  function syncCategories($control) {
    var value = [];
    $control.find('.hq-category-checks input:checked').each(function () {
      value.push(Number(this.value));
    });
    $control.find('.hq-category-checks-value').val(JSON.stringify(value)).trigger('input').trigger('change');
  }
  function initControls() {
    $('.customize-control-hq_sortable_sections').each(function () {
      var $control = $(this);
      var $list = $control.find('.hq-customizer-sortable');
      if (!$list.length || $list.data('ready')) { return; }
      $list.data('ready', true);
      if (typeof $.fn.sortable === 'function') {
        $list.sortable({ axis: 'y', handle: '.hq-drag-handle', update: function () { syncOrder($control); } });
      }
      $list.on('click', '.hq-move-section', function () {
        var $item = $(this).closest('li');
        if ($(this).data('direction') === 'up') { $item.prev().before($item); }
        else { $item.next().after($item); }
        syncOrder($control);
        this.focus();
      });
      $list.on('change', 'input[type="checkbox"]', function () { syncOrder($control); });
    });
    $('.customize-control-hq_category_checklist').each(function () {
      var $control = $(this);
      if ($control.data('ready')) { return; }
      $control.data('ready', true).on('change', '.hq-category-checks input', function () { syncCategories($control); });
    });
  }
  $(initControls);
  if (window.wp && window.wp.customize) {
    window.wp.customize.bind('ready', initControls);
  }
})(jQuery);
