<?php
/** Native single-post template: RTL prose, centered media, native content filters. */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" class="hq-container hq-content">
	<?php while ( have_posts() ) : the_post(); ?>
	<article <?php post_class( array( 'hq-entry', 'single-post-container', 'hq-entry--fit-' . hq_sanitize_one_of( get_post_meta( get_the_ID(), '_hq_featured_fit', true ) ?: get_theme_mod( 'hq_single_image_fit', 'contain' ), array( 'contain' => 1, 'cover' => 1 ), 'contain' ) ) ); ?>>
		<header class="hq-single-header"><p class="hq-kicker"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">خانه</a> / <?php the_title(); ?></p><h1><?php the_title(); ?></h1><p class="hq-entry-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time> · <?php the_author(); ?></p></header>
		<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?><figure class="hq-entry-featured"><?php the_post_thumbnail( 'large', array( 'loading' => 'eager', 'sizes' => '(min-width: 860px) 818px, calc(100vw - 82px)' ) ); ?></figure><?php endif; ?>
		<div class="entry-content hq-entry-content"><?php the_content(); wp_link_pages( array( 'before' => '<nav class="hq-post-pages" aria-label="صفحه‌های نوشته">', 'after' => '</nav>' ) ); ?></div>
		<?php $route = hq_route_url( get_the_ID() ); if ( $route ) : ?><a class="hq-route-link" href="<?php echo esc_url( $route ); ?>" target="_blank" rel="noopener noreferrer"><?php echo hq_icon( 'route' ); ?>مسیریابی</a><?php endif; ?>
	</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
