<?php
/** Categories share the same canonical archive template. */
defined( 'ABSPATH' ) || exit;
require get_theme_file_path( 'archive.php' );
