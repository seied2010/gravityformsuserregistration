<?php
/** Page composition is controlled by the native WordPress Customizer. */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" class="hq-home">
<?php
foreach ( hq_current_home_layout() as $block ) {
    if ( ! $block['enabled'] ) { continue; }
    get_template_part( 'template-parts/home/' . $block['id'] );
}
?>
</main>
<?php get_footer(); ?>
