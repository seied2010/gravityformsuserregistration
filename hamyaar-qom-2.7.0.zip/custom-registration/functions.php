<?php
/** Native WordPress registration. No Gravity Forms or other plugin is required. */
defined( 'ABSPATH' ) || exit;

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'hamyaar-qom', get_stylesheet_uri(), array(), '2.7.0' );
	wp_enqueue_script( 'hamyaar-qom', get_theme_file_uri( 'assets/portal.js' ), array(), '2.7.0', true );
} );
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', array( 'style', 'script' ) );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 120, 'width' => 340, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'align-wide' );
	register_nav_menus( array( 'primary' => 'فهرست اصلی', 'footer' => 'فهرست پایین صفحه' ) );
} );

require_once get_theme_file_path( 'inc/portal.php' );
require_once get_theme_file_path( 'inc/content-manager.php' );
require_once get_theme_file_path( 'inc/appearance.php' );
require_once get_theme_file_path( 'inc/theme-customizer.php' );

function native_registration_url() {
	return add_query_arg( 'register', '1', home_url( '/' ) );
}

/** Routing applies only to ordinary public requests, never admin or previews. */
function hq_public_route_request() {
	return ! is_admin() && ! wp_doing_ajax() && ! is_customize_preview()
		&& 'wp-login.php' !== ( $GLOBALS['pagenow'] ?? '' );
}

function native_registration_request() {
	if ( ! hq_public_route_request() ) { return false; }
	return ( isset( $_GET['register'] ) && '1' === $_GET['register'] )
		|| ( isset( $_GET['registered'] ) && '1' === $_GET['registered'] )
		|| ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && 'create_account' === native_registration_value( 'action' ) );
}

add_filter( 'template_include', function ( $template ) {
	return native_registration_request() ? get_theme_file_path( 'registration.php' ) : $template;
}, 99 );

function native_registration_value( $key ) {
	return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
}

function native_registration_error( $message, $status = 422 ) {
	$GLOBALS['native_registration_error'] = $message;
	status_header( $status );
}

add_action( 'template_redirect', function () {
	if ( ! native_registration_request() ) { return; }
	nocache_headers();
	if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || 'create_account' !== native_registration_value( 'action' ) ) {
		return;
	}
	if ( is_user_logged_in() ) {
		native_registration_error( 'شما قبلاً وارد حساب خود شده‌اید.', 403 );
		return;
	}
	if ( ! get_option( 'users_can_register' ) ) {
		native_registration_error( 'ثبت‌نام در حال حاضر غیرفعال است.', 403 );
		return;
	}
	if ( ! wp_verify_nonce( native_registration_value( '_wpnonce' ), 'native_create_account' ) ) {
		native_registration_error( 'اعتبار فرم تمام شده است. صفحه را تازه کنید و دوباره تلاش کنید.', 403 );
		return;
	}
	if ( '' !== native_registration_value( 'website' ) ) {
		native_registration_error( 'درخواست ثبت‌نام معتبر نیست.', 400 );
		return;
	}
	$rate_key = 'native_reg_' . hash_hmac( 'sha256', $_SERVER['REMOTE_ADDR'] ?? 'unknown', wp_salt( 'nonce' ) );
	$attempts = (int) get_transient( $rate_key );
	if ( $attempts >= 10 ) {
		native_registration_error( 'تعداد درخواست‌ها زیاد است. ۱۵ دقیقهٔ دیگر دوباره تلاش کنید.', 429 );
		return;
	}
	set_transient( $rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );
	$username = trim( native_registration_value( 'username' ) );
	$email = trim( native_registration_value( 'email' ) );
	$password = native_registration_value( 'password' );
	if ( strlen( $username ) < 3 || strlen( $username ) > 60 || ! validate_username( $username ) || sanitize_user( $username, true ) !== $username ) {
		native_registration_error( 'نام کاربری باید ۳ تا ۶۰ نویسه و شامل حروف لاتین، عدد، فاصله یا نشانه‌های مجاز باشد.' );
		return;
	}
	if ( ! is_email( $email ) || strlen( $email ) > 100 ) {
		native_registration_error( 'یک نشانی ایمیل معتبر وارد کنید.' );
		return;
	}
	$password_length = mb_strlen( $password, 'UTF-8' );
	if ( $password_length < 12 || $password_length > 128 ) {
		native_registration_error( 'رمز عبور باید بین ۱۲ تا ۱۲۸ نویسه باشد.' );
		return;
	}
	if ( ! hash_equals( $password, native_registration_value( 'password_confirmation' ) ) ) {
		native_registration_error( 'رمز عبور و تکرار آن یکسان نیستند.' );
		return;
	}
	$user_id = wp_insert_user( array(
		'user_login' => $username,
		'user_email' => $email,
		'user_pass'  => $password,
		'role'       => 'subscriber',
	) );
	if ( is_wp_error( $user_id ) ) {
		$duplicate = array_intersect( $user_id->get_error_codes(), array( 'existing_user_login', 'existing_user_email' ) );
		native_registration_error( $duplicate ? 'این نام کاربری یا ایمیل قبلاً ثبت شده است.' : 'ساخت حساب انجام نشد. دوباره تلاش کنید.' );
		return;
	}
	wp_safe_redirect( add_query_arg( 'registered', '1', native_registration_url() ), 303 );
	exit;
} );

// Upgrade only former stock section copy; preserve the owner's custom wording.
foreach ( array(
	'hq_places_title' => array( 'اماکن تاریخی' => 'قم‌شناسی', 'میراثی که دیدنی‌ست' => 'قم‌شناسی' ),
	'hq_places_description' => array( 'مکان‌هایی برای مکث، شناخت و دوباره دیدن.' => 'میراثی که دیدنی‌ست' ),
	'hq_history_title' => array( 'تاریخ و چهره‌های ماندگار' => 'مشاهیر و چهره‌ها', 'تاریخ و مشاهیر' => 'مشاهیر و چهره‌ها' ),
	'hq_path_places_title' => array( 'میراث و اماکن' => 'قم‌شناسی', 'اماکن تاریخی' => 'قم‌شناسی' ),
) as $setting => $replacements ) {
	add_filter( 'theme_mod_' . $setting, static function ( $value ) use ( $replacements ) { // Core may pass an array while aggregating Customizer settings.
		return is_string( $value ) ? ( $replacements[ $value ] ?? $value ) : $value; } );
}

// WordPress login uses the same uploaded identity, with no stock WordPress mark.
add_filter( 'login_headerurl', static function () { return home_url( '/' ); } );
add_filter( 'login_headertext', static function () { return get_bloginfo( 'name' ); } );
add_action( 'login_enqueue_scripts', function () {
	$url = wp_get_attachment_image_url( (int) get_theme_mod( 'custom_logo' ), 'medium' );
	$css = '#login h1 a{background-image:none;width:100%;height:auto;text-indent:0;font-size:24px;line-height:1.5;}';
	if ( $url ) {
		$css .= '#login h1 a{background-image:url(' . wp_json_encode( esc_url_raw( $url ) ) . ');background-size:contain;background-position:center;background-repeat:no-repeat;height:100px;text-indent:-9999px;}';
	}
	wp_add_inline_style( 'login', $css );
} );

// Preserve the native toolbar for administrators without modifying any user roles.
add_filter( 'show_admin_bar', static function ( $show ) {
	return current_user_can( 'manage_options' ) ? true : $show;
}, 99 );

/** A useful destination for every signed-in user, respecting native capabilities. */
function hq_account_url() {
	return current_user_can( 'manage_options' ) ? admin_url() : admin_url( 'profile.php' );
}
