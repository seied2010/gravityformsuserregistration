<?php
/** Independent content-source controls and archive diagnostics. */
defined( 'ABSPATH' ) || exit;

function hq_managed_sections() {
	return array( 'wiki' => 'دانشنامه قم', 'places' => 'قم‌شناسی', 'history' => 'مشاهیر و چهره‌ها', 'journal' => 'یادداشت‌ها و پژوهش‌ها' );
}

function hq_home_sections() {
	return array( 'hero' => 'تصویر و معرفی آغازین', 'paths' => 'مسیرهای شناخت', 'wiki' => 'دانشنامه قم', 'places' => 'قم‌شناسی', 'history' => 'مشاهیر و چهره‌ها', 'journal' => 'یادداشت‌ها و پژوهش‌ها', 'community' => 'دعوت به همراهی' );
}

function hq_layout_default() {
	$result = array();
	foreach ( hq_home_sections() as $key => $label ) { $result[] = array( 'id' => $key, 'enabled' => true ); }
	return $result;
}

function hq_normalize_layout( $value ) {
	if ( is_string( $value ) ) { $value = json_decode( $value, true ); }
	$allowed = hq_home_sections();
	$seen = array();
	$result = array();
	if ( is_array( $value ) ) {
		foreach ( $value as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['id'] ) ) { continue; }
			$key = (string) $item['id'];
			if ( ! isset( $allowed[ $key ] ) || isset( $seen[ $key ] ) ) { continue; }
			$seen[ $key ] = true;
			$result[] = array( 'id' => $key, 'enabled' => ! empty( $item['enabled'] ) );
		}
	}
	foreach ( $allowed as $key => $label ) {
		if ( ! isset( $seen[ $key ] ) ) { $result[] = array( 'id' => $key, 'enabled' => true ); }
	}
	return $result;
}

function hq_sanitize_home_layout( $value ) {
	return wp_json_encode( hq_normalize_layout( $value ) );
}

function hq_current_home_layout() {
	return hq_normalize_layout( get_theme_mod( 'hq_home_layout', '' ) );
}

function hq_home_block_enabled( $key ) {
    foreach ( hq_current_home_layout() as $block ) {
        if ( $block['id'] === $key ) { return (bool) $block['enabled']; }
    }
    return false;
}

function hq_public_content_types() {
	$objects = get_post_types( array( 'public' => true ), 'objects' );
	$types = array();
	foreach ( $objects as $type => $object ) {
		if ( in_array( $type, array( 'page', 'attachment' ), true ) ) { continue; }
		$types[ $type ] = $object->labels->name;
	}
	return $types;
}

function hq_sanitize_source_type( $value ) {
	$value = (string) $value;
	return in_array( $value, array( 'auto', 'all' ), true ) || array_key_exists( $value, hq_public_content_types() ) ? $value : 'auto';
}

function hq_sanitize_section_category( $value ) {
	$value = (int) $value;
	return -1 === $value || 0 === $value || term_exists( $value, 'category' ) ? $value : -1;
}

function hq_sanitize_section_count( $value ) {
	return min( 24, max( 1, absint( $value ) ) );
}

function hq_sanitize_order( $value ) {
	return in_array( $value, array( 'mixed', 'newest', 'oldest', 'title' ), true ) ? $value : 'mixed';
}

function hq_section_defaults() {
	return array( 'wiki' => 12, 'places' => 3, 'history' => 4, 'journal' => 4 );
}

/** Known names are fallbacks only; a saved category ID always has precedence. */
function hq_section_category_aliases() {
	return array(
		'wiki' => array( 'names' => array( 'دانشنامه قم', 'دانشنامهٔ قم', 'ویکی قم', 'دانشنامه' ), 'slugs' => array( 'qomwiki', 'qom-wiki', 'encyclopedia', 'wiki' ) ),
		'places' => array( 'names' => array( 'قم‌شناسی', 'قم شناسی' ), 'slugs' => array( 'qom-studies', 'qomstudies', 'qom-shenasi' ) ),
		'history' => array( 'names' => array( 'مشاهیر و چهره‌ها', 'مشاهیر و چهره ها' ), 'slugs' => array( 'celebrities', 'notables', 'history-notables' ) ),
		'journal' => array( 'names' => array( 'یادداشت‌ها و پژوهش‌ها', 'یادداشت ها و پژوهش ها', 'یادداشت‌ها', 'یادداشت ها' ), 'slugs' => array( 'essays', 'research', 'journal' ) ),
	);
}

function hq_normalize_category_name( $value ) {
	return preg_replace( '/[\s\x{200c}\x{200d}\x{200e}\x{200f}\x{0640}\x{064b}-\x{065f}-]+/u', '', strtr( (string) $value, array( 'ي' => 'ی', 'ك' => 'ک' ) ) );
}

function hq_section_categories( $section ) {
	$aliases = hq_section_category_aliases()[ $section ] ?? null;
	if ( ! $aliases ) { return array(); }
	$selected = (int) get_theme_mod( "hq_{$section}_category", 'wiki' === $section ? 0 : -1 );
	if ( $selected > 0 ) {
		$term = get_term( $selected, 'category' );
		return $term instanceof WP_Term ? array( $selected ) : array();
	}
	// The encyclopedia intentionally uses all recent posts until a category is chosen.
	if ( 'wiki' === $section ) { return array(); }
	foreach ( array( 'name' => $aliases['names'], 'slug' => $aliases['slugs'] ) as $field => $values ) {
		foreach ( $values as $value ) {
			$term = get_term_by( $field, $value, 'category' );
			if ( $term instanceof WP_Term ) { return array( (int) $term->term_id ); }
		}
	}
	$wanted = array_map( 'hq_normalize_category_name', $aliases['names'] );
	foreach ( get_categories( array( 'hide_empty' => false, 'orderby' => 'term_id', 'order' => 'ASC' ) ) as $term ) {
		if ( in_array( hq_normalize_category_name( $term->name ), $wanted, true ) ) { return array( (int) $term->term_id ); }
	}
	return array();
}

function hq_section_config( $section ) {
	$defaults = hq_section_defaults();
	if ( ! isset( $defaults[ $section ] ) ) { return null; }
	return array( 'count' => 'places' === $section ? hq_sanitize_section_count( get_theme_mod( 'hq_places_count', $defaults['places'] ) ) : $defaults[ $section ] );
}

function hq_section_query_args( $section, $limit, $paged = 1, $search = '' ) {
	if ( ! hq_section_config( $section ) ) { return array( 'post__in' => array( 0 ) ); }
	$args = array(
		'post_type' => 'post', 'post_status' => 'publish',
		'posts_per_page' => max( 1, absint( $limit ) ), 'paged' => max( 1, absint( $paged ) ),
		'ignore_sticky_posts' => true, 'orderby' => array( 'date' => 'DESC', 'ID' => 'DESC' ), 'order' => 'DESC',
	);
	$ids = hq_section_categories( $section );
	if ( $ids ) {
		$args['tax_query'] = array( array( 'taxonomy' => 'category', 'field' => 'term_id', 'terms' => $ids, 'include_children' => false ) );
	} elseif ( 'wiki' !== $section || (int) get_theme_mod( 'hq_wiki_category', 0 ) > 0 ) {
		// A deleted/missing selected category must never expose unrelated posts.
		$args['post__in'] = array( 0 );
	}
	if ( '' !== $search ) { $args['s'] = $search; }
	return $args;
}

function hq_section_query( $section, $limit = null ) {
	$config = hq_section_config( $section );
	if ( ! $config ) { return new WP_Query( array( 'post__in' => array( 0 ) ) ); }
	$args = hq_section_query_args( $section, null === $limit ? $config['count'] : $limit );
	$args['no_found_rows'] = true;
	return new WP_Query( $args );
}

function hq_section_url( $section ) {
    if ( ! isset( hq_managed_sections()[ $section ] ) ) { return home_url( '/' ); }
    return get_option( 'permalink_structure' )
        ? home_url( '/hamyaar-directory/' . $section . '/' )
        : add_query_arg( 'hq_directory', $section, home_url( '/' ) );
}

add_action( 'init', function () {
    add_rewrite_rule( '^hamyaar-directory/(wiki|places|history|journal)/?$', 'index.php?hq_directory=$matches[1]', 'top' );
}, 5 );
add_filter( 'query_vars', function ( $vars ) {
    $vars[] = 'hq_directory';
    return $vars;
} );
add_filter( 'document_title_parts', function ( $parts ) {
    $section = hq_request_directory_section();
    if ( $section ) { $parts['title'] = hq_managed_sections()[ $section ] . ' | فهرست کامل'; }
    return $parts;
} );


function hq_directory_letters() {
    return array( 'آ', 'الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'ژ', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ک', 'گ', 'ل', 'م', 'ن', 'و', 'ه', 'ی' );
}

function hq_directory_requested_letter() {
    $letter = isset( $_GET['hq_letter'] ) && is_string( $_GET['hq_letter'] ) ? sanitize_text_field( wp_unslash( $_GET['hq_letter'] ) ) : '';
    return in_array( $letter, hq_directory_letters(), true ) ? $letter : '';
}

add_filter( 'posts_where', function ( $where, $query ) {
    $letter = $query->get( 'hq_directory_letter' );
    if ( ! $letter || ! in_array( $letter, hq_directory_letters(), true ) ) { return $where; }
    global $wpdb;
    $prefixes = 'الف' === $letter ? array( 'ا', 'أ', 'إ', 'ٱ' ) : array( $letter );
    $parts = array();
    foreach ( $prefixes as $prefix ) {
        $parts[] = $wpdb->prepare( "{$wpdb->posts}.post_title LIKE %s", $wpdb->esc_like( $prefix ) . '%' );
    }
    return $where . ' AND (' . implode( ' OR ', $parts ) . ')';
}, 10, 2 );

function hq_request_directory_section() {
	$value = get_query_var( 'hq_directory', '' );
	$raw = is_string( $value ) ? sanitize_key( $value ) : '';
	if ( ! $raw && isset( $_GET['hq_directory'] ) && is_string( $_GET['hq_directory'] ) ) { $raw = sanitize_key( wp_unslash( $_GET['hq_directory'] ) ); }
	return isset( hq_managed_sections()[ $raw ] ) ? $raw : '';
}

// The previous /qomwiki/ landing page can remain empty after a migration.
// Preserve old menu links by temporarily redirecting the legacy directory URL.
add_action( 'template_redirect', function () {
    if ( ! hq_public_route_request() || hq_request_directory_section() ) { return; }
    if ( is_page( 'qomwiki' ) ) {
        wp_safe_redirect( hq_section_url( 'wiki' ), 302 );
        exit;
    }
}, 1 );

add_filter( 'template_include', function ( $template ) {
	if ( hq_public_route_request() && hq_request_directory_section() ) { return get_theme_file_path( 'archive-hq-directory.php' ); }
	return $template;
}, 80 );
add_filter( 'redirect_canonical', function ( $redirect ) {
	return hq_public_route_request() && hq_request_directory_section() ? false : $redirect;
} );

function hq_sanitize_category_list( $value ) {
	if ( is_string( $value ) ) { $value = json_decode( $value, true ); }
	if ( ! is_array( $value ) ) { return '[]'; }
	$result = array();
	foreach ( $value as $id ) {
		$id = absint( $id );
		if ( $id && term_exists( $id, 'category' ) ) { $result[ $id ] = $id; }
	}
	return wp_json_encode( array_values( $result ) );
}

function hq_archive_image_categories() {
	$list = json_decode( (string) get_theme_mod( 'hq_archive_image_categories', '[]' ), true );
	return is_array( $list ) ? array_map( 'absint', $list ) : array();
}

add_action( 'pre_get_posts', function ( $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_category() ) { return; }
	$category = (int) $query->get_queried_object_id();
	if ( ! in_array( $category, hq_archive_image_categories(), true ) ) { return; }
	$meta = (array) $query->get( 'meta_query', array() );
	$meta[] = array( 'key' => '_thumbnail_id', 'compare' => 'EXISTS' );
	$query->set( 'meta_query', $meta );
} );

add_action( 'admin_menu', function () {
	add_management_page( 'وضعیت محتوای همیار', 'گزارش منابع همیار', 'manage_options', 'hq-content-audit', 'hq_render_content_audit' );
} );

function hq_render_content_audit() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	global $wpdb;
	$rows = $wpdb->get_results( "SELECT post_type, post_status, COUNT(*) AS count, MIN(post_date) AS oldest, MAX(post_date) AS newest FROM {$wpdb->posts} WHERE post_status IN ('publish','draft','private') AND post_type NOT IN ('attachment','revision','nav_menu_item') GROUP BY post_type, post_status ORDER BY post_type, post_status" );
	$registered = get_post_types( array(), 'names' );
	?><div class="wrap"><h1>گزارش منابع محتوایی همیار</h1><p>این گزارش فقط خواندنی است و هیچ نوشته‌ای را حذف، تبدیل یا منتقل نمی‌کند. برای انتخاب منبع صفحه اصلی به «نمایش ← سفارشی‌سازی ← منابع و بخش‌های صفحه اصلی» بروید.</p><table class="widefat striped"><thead><tr><th>نوع محتوا</th><th>وضعیت</th><th>تعداد</th><th>قدیمی‌ترین تاریخ</th><th>جدیدترین تاریخ</th><th>ثبت‌شده در وردپرس؟</th></tr></thead><tbody><?php
	foreach ( $rows as $row ) {
		echo '<tr><td><code>' . esc_html( $row->post_type ) . '</code></td><td>' . esc_html( $row->post_status ) . '</td><td>' . esc_html( number_format_i18n( $row->count ) ) . '</td><td>' . esc_html( $row->oldest ) . '</td><td>' . esc_html( $row->newest ) . '</td><td>' . ( in_array( $row->post_type, $registered, true ) ? 'بله' : '<strong>خیر — نوع قدیمی/غیرفعال</strong>' ) . '</td></tr>';
	}
	?></tbody></table><h2>تعداد نوشته‌ها در دسته‌ها</h2><table class="widefat striped"><thead><tr><th>دسته</th><th>نامک</th><th>تعداد ثبت‌شده</th><th>شناسه</th></tr></thead><tbody><?php
	foreach ( get_categories( array( 'hide_empty' => false ) ) as $term ) {
		echo '<tr><td>' . esc_html( $term->name ) . '</td><td><code>' . esc_html( $term->slug ) . '</code></td><td>' . esc_html( number_format_i18n( $term->count ) ) . '</td><td>' . esc_html( $term->term_id ) . '</td></tr>';
	}
	?></tbody></table><p><strong>توجه:</strong> اگر نوع محتوای قدیمی «ثبت‌نشده» باشد، بازیابی لینک‌ها و نمایش عمومی آن نیازمند بررسی افزونه یا ساختار قبلی است؛ صرف تغییر قالب داده‌های مفقود یا جداول مستقل را بازیابی نمی‌کند.</p></div><?php
}

