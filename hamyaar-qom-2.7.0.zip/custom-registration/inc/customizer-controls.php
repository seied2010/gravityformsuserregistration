<?php
defined( 'ABSPATH' ) || exit;
if ( class_exists( 'WP_Customize_Control' ) ) {
	class HQ_Sortable_Sections_Control extends WP_Customize_Control {
		public $type = 'hq_sortable_sections';
		public function render_content() {
			$items = hq_normalize_layout( $this->value() );
			?><label><span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span><span class="description customize-control-description">بخش‌ها را با کشیدن دستگیره مرتب کنید. تیک هر بخش نمایش آن را کنترل می‌کند. برای ذخیره «انتشار» را بزنید.</span></label>
			<ul class="hq-customizer-sortable">
			<?php foreach ( $items as $item ) : ?>
			<li data-id="<?php echo esc_attr( $item['id'] ); ?>"><span class="hq-drag-handle" title="جابه‌جایی" aria-hidden="true">☰</span><button type="button" class="hq-move-section" data-direction="up" aria-label="انتقال به بالا">↑</button><button type="button" class="hq-move-section" data-direction="down" aria-label="انتقال به پایین">↓</button><label><input type="checkbox" <?php checked( $item['enabled'] ); ?>><span><?php echo esc_html( hq_home_sections()[ $item['id'] ] ); ?></span></label></li>
			<?php endforeach; ?>
			</ul><input type="hidden" class="hq-sortable-value" <?php $this->link(); ?> value="<?php echo esc_attr( hq_sanitize_home_layout( $this->value() ) ); ?>">
			<?php
		}
	}
	class HQ_Category_Checklist_Control extends WP_Customize_Control {
		public $type = 'hq_category_checklist';
		public function render_content() {
			$selected = json_decode( (string) $this->value(), true );
			$selected = is_array( $selected ) ? array_map( 'intval', $selected ) : array();
			?><label><span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span><span class="description customize-control-description">دسته‌هایی که در صفحه بایگانی فقط نوشته دارای تصویر شاخص نمایش دهند، علامت بزنید. مطالب حذف نمی‌شوند؛ صرفاً از فهرست آن دسته پنهان می‌شوند.</span></label>
			<div class="hq-category-checks">
			<?php foreach ( get_categories( array( 'hide_empty' => false ) ) as $category ) : ?><label><input type="checkbox" value="<?php echo esc_attr( $category->term_id ); ?>" <?php checked( in_array( (int) $category->term_id, $selected, true ) ); ?>><span><?php echo esc_html( $category->name ); ?></span></label><?php endforeach; ?>
			</div><input type="hidden" class="hq-category-checks-value" <?php $this->link(); ?> value="<?php echo esc_attr( hq_sanitize_category_list( $this->value() ) ); ?>">
			<?php
		}
	}
}

