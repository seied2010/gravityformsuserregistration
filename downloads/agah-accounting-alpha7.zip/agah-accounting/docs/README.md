# راهنمای مستندات alpha7

نسخه جاری alpha7، ERP0.18.0-alpha، Schema8 و۵۶جدول است. از HANDOFF-NEXT و REPORT-16-18 شروع کنید. قراردادهای جدید CONTRACTS-16-18، تنظیم و بازیابی BACKUP-RECOVERY و استقرار DEPLOYMENT-CHECKLIST هستند. گزارش‌ها و قراردادهای مراحل پیشین، تاریخچه و مرجع ماژول مربوط‌اند. شواهد این تحویل در test-results/phase-16-18 قرار دارد.
