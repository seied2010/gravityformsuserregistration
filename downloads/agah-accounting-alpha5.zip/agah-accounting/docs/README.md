# مستندات حسابداری آگاه

نسخه جاری alpha5، Schema6 است. از README و HANDOFF-NEXT شروع کنید؛ گزارش جاری REPORT-10-12.md، قراردادهای این بسته CONTRACTS-10-12.md و شواهد docs/test-results/phase-10-12 است. سندهای مراحل قبلی تاریخچهٔ نسخه‌اند.
