# وابستگی و مجوز

- PHP/WordPress/MariaDB زیرساخت هستند؛ نسخه‌های آزموده در گزارش ثبت شده‌اند.
- هیچ کتابخانهٔ PHP/JS تازه برای runtime اضافه نشده است. TOTP و تقویم/جمع محلی در همین پروژه‌اند.
- فونت Vazirmatn از فایل نسخهٔ ارسالی حفظ شده؛ متن مجوز SIL Open Font License 1.1 از مخزن رسمی rastikerdar/vazirmatn در assets/fonts/OFL.txt درج شده است. فایل فونت جایگزین/دانلود مجدد نشده است.
- Playwright 1.62.1 (Apache-2.0)، Chromium، Python و WP-CLI فقط ابزار آزمون‌اند؛ داخل runtime قالب بارگذاری نمی‌شوند. WP-CLI از builds رسمی GitHub با TLS دریافت شد.
- اسکریپت/فونت خارجی یا CDN در رابط ERP درخواست نمی‌شود؛ آزمون مرورگر آن را بررسی می‌کند.
