#!/usr/bin/env bash
# اجرای آزمون‌های نصب محلی؛ فقط سایت دورریختنی و دارای AGAH_TEST_MODE.
set -euo pipefail
: "${AGAH_TEST_COMPOSE:=/workspace/agah-test/compose.yaml}"
: "${AGAH_TEST_URL:=http://127.0.0.1:8081}"
export AGAH_TEST_COMPOSE AGAH_TEST_URL
agah_theme_path="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
agah_fixture_file="$(mktemp /tmp/agah-fixture.XXXXXX)"
trap 'rm -f "$agah_fixture_file"' EXIT
chmod 600 "$agah_fixture_file"
docker compose -f "$AGAH_TEST_COMPOSE" exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/smoke.php
docker compose -f "$AGAH_TEST_COMPOSE" exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/run.php
python3 "$agah_theme_path/tests/integration/concurrency.py"
python3 "$agah_theme_path/tests/integration/business-concurrency.py"
python3 "$agah_theme_path/tests/integration/trade-concurrency.py"
python3 "$agah_theme_path/tests/integration/finance-concurrency.py"
docker compose -f "$AGAH_TEST_COMPOSE" exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/browser-fixture.php > "$agah_fixture_file"
node "$agah_theme_path/tests/security/browser.cjs" "$agah_fixture_file" "${AGAH_TEST_SCREENSHOTS:-/tmp/agah-screenshots}"

docker compose -f "$AGAH_TEST_COMPOSE" exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/browser-fixture.php > "$agah_fixture_file"
node "$agah_theme_path/tests/security/business-browser.cjs" "$agah_fixture_file" "${AGAH_TEST_SCREENSHOTS:-/tmp/agah-screenshots}"

docker compose -f "$AGAH_TEST_COMPOSE" exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/trade-browser-fixture.php > "$agah_fixture_file"
node "$agah_theme_path/tests/security/trade-browser.cjs" "$agah_fixture_file" "${AGAH_TEST_SCREENSHOTS:-/tmp/agah-screenshots}"

docker compose -f "$AGAH_TEST_COMPOSE" exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/finance-browser-fixture.php > "$agah_fixture_file"
node "$agah_theme_path/tests/security/finance-browser.cjs" "$agah_fixture_file" "${AGAH_TEST_SCREENSHOTS:-/tmp/agah-screenshots}"
