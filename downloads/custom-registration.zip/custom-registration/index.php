<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body>
<?php wp_body_open(); ?>
<main>
<p class="eyebrow">خوش آمدید</p>
<?php if ( is_user_logged_in() ) : ?>
	<h1>حساب شما آماده است</h1>
	<p class="intro">شما وارد حساب خود شده‌اید.</p>
	<a class="button" href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>">مشاهدهٔ پروفایل</a>
	<p class="footnote"><a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">خروج از حساب</a></p>
<?php elseif ( isset( $_GET['registered'] ) && '1' === $_GET['registered'] ) : ?>
	<h1>ثبت‌نام انجام شد</h1>
	<p class="notice success" role="status">حساب شما ساخته شد. اکنون می‌توانید با نام کاربری و رمز عبور خود وارد شوید.</p>
	<a class="button" href="<?php echo esc_url( wp_login_url( home_url( '/' ) ) ); ?>">ورود به حساب</a>
<?php elseif ( ! get_option( 'users_can_register' ) ) : ?>
	<h1>ثبت‌نام بسته است</h1>
	<p class="intro">در حال حاضر امکان ساخت حساب جدید وجود ندارد.</p>
<?php else : ?>
	<h1>حساب خود را بسازید</h1>
	<p class="intro">اطلاعات زیر را وارد کنید تا حساب شما ساخته شود.</p>
	<?php if ( isset( $GLOBALS['native_registration_error'] ) ) : ?>
		<p class="notice error" role="alert"><?php echo esc_html( $GLOBALS['native_registration_error'] ); ?></p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="hidden" name="action" value="create_account">
		<?php wp_nonce_field( 'native_create_account' ); ?>
		<label for="username">نام کاربری</label>
		<input id="username" name="username" dir="ltr" autocomplete="username" minlength="3" maxlength="60" required value="<?php echo esc_attr( native_registration_value( 'username' ) ); ?>">
		<label for="email">نشانی ایمیل</label>
		<input id="email" name="email" type="email" dir="ltr" autocomplete="email" maxlength="100" required value="<?php echo esc_attr( native_registration_value( 'email' ) ); ?>">
		<label for="password">رمز عبور</label>
		<input id="password" name="password" type="password" dir="ltr" autocomplete="new-password" minlength="12" maxlength="128" aria-describedby="password-hint" required>
		<p id="password-hint" class="hint">حداقل ۱۲ نویسه؛ از یک رمز عبور طولانی و منحصربه‌فرد استفاده کنید.</p>
		<label for="password-confirmation">تکرار رمز عبور</label>
		<input id="password-confirmation" name="password_confirmation" type="password" dir="ltr" autocomplete="new-password" minlength="12" maxlength="128" required>
		<div class="trap" aria-hidden="true"><label for="website">وب‌سایت</label><input id="website" name="website" tabindex="-1" autocomplete="off"></div>
		<button type="submit">ساخت حساب</button>
	</form>
	<p class="footnote">قبلاً ثبت‌نام کرده‌اید؟ <a href="<?php echo esc_url( wp_login_url( home_url( '/' ) ) ); ?>">وارد شوید</a></p>
<?php endif; ?>
</main>
<?php wp_footer(); ?>
</body>
</html>
