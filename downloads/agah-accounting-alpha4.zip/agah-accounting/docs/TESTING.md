# آزمون‌ها و بازتولید

**فقط سایت WordPress دورریختنی.** آزمون‌ها کاربر، شرکت، نقش، سند، نشست و رکورد ممیزی می‌سازند. smoke برای سنجش تشخیص دست‌کاری عمداً یکی از زنجیره‌های شرکت آزمایشی خودش را تغییر می‌دهد. fixture مرورگر سهمیه‌های DB آزمایشی را پاک می‌کند تا اجرای قبلی، اجرای تازه را قفل نکند. هرگز روی اطلاعات واقعی اجرا نکنید.

در wp-config سایت آزمایشی `AGAH_TEST_MODE=true` تعریف کنید. روی سایت اصلی آن را تعریف نکنید. WP-CLI و مسیر WordPress/قالب لازم است. اجرای پایه از ریشهٔ WordPress:

```sh
wp eval-file wp-content/themes/agah-accounting/tests/smoke.php
wp eval-file wp-content/themes/agah-accounting/tests/run.php
```

runner مجموع واقعی را اعلام و در شکست exit غیرصفر می‌دهد؛ صفر آزمون، موفقیت نیست. نسخهٔ قدیمی smoke اصلاح شده تا شکست در scope اجرای WP-CLI گم نشود. دادهٔ test در transaction تست سراسری پنهان نشده است؛ commit، rollback و FK واقعی بررسی می‌شوند.

## اجرای محیط Docker همین تحویل

compose خارج از قالب در `/workspace/agah-test/compose.yaml` است. PHP داخل سرویس wordpress اجرا می‌شود و WP-CLI در `/tmp/wp` قرار دارد. اگر کانتینر عوض شد، phar رسمی WP-CLI را دوباره از منبع معتبر با TLS دریافت و در آن کپی کنید. خودِ phar داخل ZIP قالب نیست.

```sh
cd /workspace/agah-test
docker compose up -d --wait
docker compose exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/smoke.php
docker compose exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/run.php
cd /workspace/agah-project/agah-accounting
AGAH_TEST_COMPOSE=/workspace/agah-test/compose.yaml python3 tests/integration/concurrency.py
```

هم‌زمانی با چند فرایند WP-CLI و چند اتصال DB واقعی اجرا می‌شود: چهار تأیید، چهار POST منطقی همسان، هشت سهمیه و هشت ثبت ممیزی. صرفاً mock یا اجرای ترتیبی نیست.

## مرورگر

Node و Playwright 1.62.1 و Chromium در ابزار آزمون استفاده شده‌اند؛ وابستگی runtime محصول نیستند و از CDN در رابط بارگذاری نمی‌شوند. fixture خروجی شامل **گذرواژهٔ آزمایشی** است؛ فقط در فایل خصوصی خارج از بسته نگهداری و بعد از تست حذف کنید.

```sh
umask 077
docker compose -f /workspace/agah-test/compose.yaml exec -T wordpress php /tmp/wp --allow-root eval-file wp-content/themes/agah-accounting/tests/browser-fixture.php > /tmp/agah-fixture.json
AGAH_TEST_URL=http://127.0.0.1:8081 node tests/security/browser.cjs /tmp/agah-fixture.json /tmp/agah-screenshots
rm /tmp/agah-fixture.json
```

`CHROMIUM_PATH` مسیر مرورگر را عوض می‌کند. مرورگر runner در کانتینر با `--no-sandbox` اجرا می‌شود؛ این برای **محیط آزمون ایزوله** است و تنظیم امنیتی محصول/وب‌سرور نیست. برای نصب مستقل ابزار تست، نسخهٔ Playwright را در پروژهٔ ابزار جداگانه pin کنید؛ نیاز نیست package.json به قالب اضافه شود.

بررسی‌ها: ورود واقعی و CSRF، صفحات، کنترل دسترسی و ۴۰۴، فرم حساب/نقش/عضو/شرکت/سال، ردیف پویا، ثبت→تأیید→قطعی، CSV ضد فرمول، Excel XML، خطا و حفظ مقدار، فونت محلی/عدم درخواست خارجی، نمای موبایل، ثبت تکراری، فعال‌سازی MFA، مصرف کد بازیابی، ورود از نشست دیگر، الزام شرکتی و پایان بی‌فعالیتی.

## اجرای یک‌دستوری مجموعهٔ آماده

از ریشهٔ قالب و با پیش‌نیازهای بالا:

```sh
bash tests/run-all.sh
```

این فرمان smoke، مجموعهٔ PHP، هم‌زمانی و مرورگر را به ترتیب با حفظ exit status اجرا می‌کند و فایل موقت اطلاعات ورود را پاک می‌کند. نمونهٔ واقعی اجرای آن در `docs/test-results/run-all.log` ثبت شده است. آزمون migration مستقل است: نسخهٔ alpha1 را در سایت سوم نصب کنید، smoke اولیه را اجرا و `tests/migration.php capture` را از فایل کپی‌شده خارج از theme اجرا کنید؛ پس از جایگزینی ZIP alpha2، همان فایل با `verify` هش تمام ستون‌های قبلی را مقایسه می‌کند. نتیجهٔ این ارتقای واقعی در migration.log است.

## نتیجه و حدود

خروجی خام و جدول نتیجه در REPORT-1-3.md و `docs/test-results/` است. screenshotها مربوط به دادهٔ آزمایشی‌اند. نصب ZIP نهایی روی WordPress جداگانه نیز بررسی می‌شود. ایمیل واقعی، پیامک واقعی، بار بزرگ، WordPress/PHPهای دیگر، افزونه‌های ثالث و حسابرسی رسمی مالی «اجرا نشد» هستند؛ گذر آزمون‌های فعلی به‌معنی تأیید آن‌ها نیست.

## آزمون‌های مراحل ۴–۶

run.php علاوه بر گروه قبلی integration/business.php را اجرا می‌کند. business-concurrency.py دو فرایند مستقل برای تسویهٔ یک مانده، وصول یک چک و ثبت یک شناسه اجرا می‌کند. business-browser.cjs مسیرهای واقعی فرم و CSV و مغایرت‌گیری را بررسی می‌کند. run-all.sh هر دو گروه را هم اجرا می‌کند؛ fixture هر گروه خصوصی و تازه است. لاگ‌های این تحویل در docs/test-results/phase-4-6 هستند. migration.php این نسخه، capture روی Schema 3 و verify روی Schema 4 است؛ ردیف‌های قبلی باید باقی بمانند و افزودن مجوز حساس فقط برای company_admin مجاز است.

## مراحل ۷–۹

همان `bash tests/run-all.sh`: smoke، PHP کامل، سه runner هم‌زمانی و سه runner مرورگر. tests/integration/trade.php تراکنش/دفتر/انبار/مجوز و تمام FKهای جدید را می‌آزماید؛ trade-concurrency.py چهار رقابت مستقل و سه invariant دارد. trade-browser-fixture.php JSON خصوصی فقط در فایل موقت می‌سازد؛ در گزارش/Git منتشر نشود. trade-browser.cjs فرم، idempotency، CSRF، IDOR، نقش فقط‌خواندنی، CSV، موبایل و PDF A4/A5 را روی HTTP واقعی می‌سنجد.

برای ارتقای alpha3→alpha4: در سایت دورریختنی با نسخهٔ قدیمی، اسکریپت مستقل tests/upgrade-trade.php را به /tmp کپی و `wp eval-file /tmp/upgrade-trade.php capture` اجرا کنید؛ سپس ZIP تازه را جایگزین و `wp eval-file .../tests/upgrade-trade.php verify` اجرا کنید. اسکریپت tests/migration.php مخصوص ارتقای تاریخی alpha2→alpha3 حفظ شده و برای نسخه جدید نیست. نتایج فعلی در docs/test-results/phase-7-9 هستند.
