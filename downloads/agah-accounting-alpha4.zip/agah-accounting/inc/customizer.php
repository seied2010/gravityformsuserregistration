<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function agah_sanitize_link( $v ) {
	return esc_url_raw( $v, array( 'http', 'https', 'tel', 'mailto' ) );
}

function agah_sanitize_html( $v ) {
	return current_user_can( 'unfiltered_html' ) ? $v : wp_kses_post( $v );
}

function agah_customize( $wp_customize ) {

	$wp_customize->add_panel( 'agah_panel', array( 'title' => 'تنظیمات قالب آگاه', 'priority' => 30 ) );

	$sections = array(
		'look'     => 'رنگ و ظاهر',
		'header'   => 'هدر و نوار بالا',
		'hero'     => 'بخش اول صفحهٔ اصلی',
		'strip'    => 'نوار مزایا',
		'features' => 'قابلیت‌ها',
		'showcase' => 'نمایش گزارش‌ها',
		'steps'    => 'مراحل شروع',
		'pricing'  => 'پلن‌ها و قیمت',
		'faq'      => 'پرسش‌های متداول',
		'seo'      => 'سئو و اشتراک‌گذاری',
		'float'    => 'دکمه‌های تماس شناور',
		'cta'      => 'فراخوان و مطالب',
		'contact'  => 'تماس و فوتر',
	);
	$i = 1;
	foreach ( $sections as $id => $title ) {
		$wp_customize->add_section( 'agah_' . $id, array( 'title' => $title, 'panel' => 'agah_panel', 'priority' => $i++ ) );
	}

	/* رنگ‌ها */
	$colors = array(
		'agah_c_brand'   => array( 'رنگ برند (دکمه‌ها و لینک‌ها)', '#1F6F5C' ),
		'agah_c_primary' => array( 'رنگ عنوان‌ها و بخش‌های تیره', '#12304A' ),
		'agah_c_accent'  => array( 'رنگ تأکید', '#C8963E' ),
		'agah_c_bg'      => array( 'پس‌زمینهٔ بخش‌های روشن', '#F5F8F7' ),
	);
	foreach ( $colors as $id => $c ) {
		$wp_customize->add_setting( $id, array( 'default' => $c[1], 'sanitize_callback' => 'sanitize_hex_color' ) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, array( 'label' => $c[0], 'section' => 'agah_look' ) ) );
	}
	$ranges = array(
		'agah_radius' => array( 'گردی گوشه‌ها (پیکسل)', 14, 0, 28, 1 ),
		'agah_width'  => array( 'عرض محتوا (پیکسل)', 1180, 960, 1440, 20 ),
		'agah_fs'     => array( 'اندازهٔ متن (پیکسل)', 16, 14, 20, 1 ),
	);
	foreach ( $ranges as $id => $r ) {
		$wp_customize->add_setting( $id, array( 'default' => $r[1], 'sanitize_callback' => 'absint' ) );
		$wp_customize->add_control( $id, array( 'label' => $r[0], 'section' => 'agah_look', 'type' => 'range', 'input_attrs' => array( 'min' => $r[2], 'max' => $r[3], 'step' => $r[4] ) ) );
	}

	/* فیلدهای دستی هدر و فوتر */
	$manual = array(
		array( 'agah_mark', 'حروف لوگوی متنی (وقتی لوگو بارگذاری نشده)', 'ID', 'header', 'text' ),
		array( 'agah_mark_name', 'نام برند در ماکت داشبورد', get_bloginfo( 'name' ), 'header', 'text' ),
		array( 'agah_login_text', 'دکمهٔ ورود: متن', 'ورود', 'header', 'text' ),
		array( 'agah_login_url', 'دکمهٔ ورود: لینک', '#', 'header', 'url' ),
		array( 'agah_signup_text', 'دکمهٔ شروع: متن', 'شروع رایگان', 'header', 'text' ),
		array( 'agah_signup_url', 'دکمهٔ شروع: لینک', '#pricing', 'header', 'url' ),
		array( 'agah_topbar_text', 'متن نوار بالا (خالی = نوار نمایش داده نشود)', '', 'header', 'text' ),
		array( 'agah_phone', 'تلفن', '021-12345678', 'contact', 'text' ),
		array( 'agah_email', 'ایمیل', 'info@idpa.ir', 'contact', 'email' ),
		array( 'agah_address', 'نشانی', 'تهران، خیابان نمونه، پلاک ۱', 'contact', 'text' ),
		array( 'agah_hours', 'ساعت کاری', 'شنبه تا چهارشنبه، ۹ تا ۱۷', 'contact', 'text' ),
		array( 'agah_footer_about', 'دربارهٔ ما (فوتر)', 'مجموعهٔ خدمات حسابداری و مشاورهٔ مالی', 'contact', 'textarea' ),
		array( 'agah_ct_to', 'ایمیل دریافت پیام‌های فرم تماس (خالی = ایمیل مدیر سایت)', '', 'contact', 'email' ),
		array( 'agah_ct_ok', 'پیام موفقیت پس از ارسال فرم', 'پیام شما ثبت شد. به‌زودی با شما تماس می‌گیریم.', 'contact', 'text' ),
		array( 'agah_ct_btn', 'متن دکمهٔ فرم تماس', 'ارسال درخواست', 'contact', 'text' ),
		array( 'agah_trust_html', 'کد نماد اعتماد / ساماندهی (کد HTML را همان‌طور که دریافت کرده‌اید بچسبانید)', '', 'contact', 'html' ),
		array( 'agah_meta_desc', 'توضیح متا صفحهٔ اصلی (حدود ۱۵۰ کاراکتر؛ در نتایج گوگل دیده می‌شود)', '', 'seo', 'textarea' ),
		array( 'agah_og_image', 'تصویر پیش‌فرض اشتراک‌گذاری (آدرس کامل تصویر)', '', 'seo', 'url' ),
		array( 'agah_fl_phone', 'شمارهٔ تماس (دکمهٔ «تماس»)', '', 'float', 'text' ),
		array( 'agah_fl_whatsapp', 'لینک واتساپ (مثلاً https://wa.me/989121234567)', '', 'float', 'url' ),
		array( 'agah_fl_telegram', 'لینک تلگرام (مثلاً https://t.me/username)', '', 'float', 'url' ),
		array( 'agah_fl_eitaa', 'لینک ایتا', '', 'float', 'url' ),
		array( 'agah_copyright', 'متن کپی‌رایت', 'تمامی حقوق این سایت محفوظ است.', 'contact', 'text' ),
	);
	$fields = array_merge( $manual, require get_template_directory() . '/inc/fields.php' );

	foreach ( $fields as $f ) {
		list( $id, $default, $label, $section, $type ) = $f;
		$static = in_array( $id, array( 'agah_ct_to', 'agah_ct_ok', 'agah_trust_html', 'agah_meta_desc', 'agah_og_image', 'agah_fl_phone', 'agah_fl_whatsapp', 'agah_fl_telegram', 'agah_fl_eitaa' ), true );
		$cb = 'sanitize_text_field';
		if ( 'html' === $type )     $cb = 'agah_sanitize_html';
		if ( 'textarea' === $type ) $cb = 'sanitize_textarea_field';
		if ( 'url' === $type )      $cb = 'agah_sanitize_link';
		if ( 'email' === $type )    $cb = 'sanitize_email';
		$wp_customize->add_setting( $id, array( 'default' => $default, 'sanitize_callback' => $cb, 'transport' => $static ? 'refresh' : 'postMessage' ) );

		/* آیکن قلم در پیش‌نمایش: کلیک روی آن، فیلد همین بخش را در پنل باز می‌کند */
		if ( ! $static && isset( $wp_customize->selective_refresh ) ) {
			$is_text = in_array( $type, array( 'text', 'textarea' ), true );
			$wp_customize->selective_refresh->add_partial( $id, array(
				'selector'            => '[data-agah="' . $id . '"]',
				'settings'            => array( $id ),
				'container_inclusive' => false,
				'fallback_refresh'    => true,
				'render_callback'     => $is_text
					? function () use ( $id, $default ) { return esc_html( agah_mod( $id, $default ) ); }
					: '__return_false',
			) );
		}
		$wp_customize->add_control( $id, array( 'label' => $label, 'section' => 'agah_' . $section, 'type' => ( in_array( $type, array( 'url', 'html' ), true ) ? ( 'html' === $type ? 'textarea' : 'text' ) : $type ) ) );
	}
}
add_action( 'customize_register', 'agah_customize' );
