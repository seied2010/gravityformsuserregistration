<?php
/**
 * نقطهٔ ورود سامانهٔ حسابداری (ERP). همهٔ فایل‌های erp/ از اینجا بارگذاری می‌شوند.
 * استقلال: این پوشه به هیچ تابع قالب (agah_*) وابسته نیست؛ برای تبدیل به افزونه فقط همین پوشه + یک هدر افزونه لازم است.
 * ثابت‌های لازم: ABSPATH (وردپرس). مسیر پایه از AGAH_ERP_DIR گرفته می‌شود.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'AGAH_ERP_DIR', __DIR__ );
define( 'AGAH_ERP_VERSION', '0.9.0-alpha' );

if ( version_compare( PHP_VERSION, '7.4', '<' ) || ! extension_loaded( 'sodium' ) ) {
	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-error"><p>سامانهٔ حسابداری آگاه به PHP نسخهٔ ۷٫۴ یا بالاتر و افزونهٔ sodium نیاز دارد؛ سامانه غیرفعال شد.</p></div>';
	} );
	return;
}

foreach ( array(
	'Core/Errors', 'Core/Db', 'Core/Money', 'Core/Jalali', 'Core/Crypto', 'Core/Request', 'Core/Settings', 'Core/Sequence',
	'Core/Business', 'Core/BusinessSchema', 'Core/TradeSchema', 'Core/TradeMath', 'Core/Schema', 'Core/Access', 'Core/Ctx', 'Core/Audit', 'Core/Idempotency', 'Security/Caps',
	'Security/RateLimiter', 'Security/Totp', 'Security/TwoFactor', 'Security/SmsProvider', 'Security/SmsOtp', 'Security/Auth', 'Http/SecurityController',
	'Modules/Accounting/ChartSeed', 'Modules/Accounting/FiscalService', 'Modules/Accounting/AccountService',
	'Modules/Inventory/StockService', 'Modules/Trade/InvoiceService', 'Modules/Parties/PartyService', 'Modules/Catalog/CatalogService', 'Modules/Treasury/TreasuryService',
	'Modules/Company/CompanyService', 'Modules/Company/MemberService', 'Modules/Accounting/DetailService', 'Modules/Accounting/VoucherService', 'Modules/Accounting/ReportService', 'Http/TradeController', 'Http/CommerceController', 'Http/ModuleController', 'Http/Page',
) as $f ) {
	require_once AGAH_ERP_DIR . '/src/' . $f . '.php';
}

/** نشانی صفحهٔ سامانه. */
function agah_erp_url( $args = array() ) {
	$id  = (int) get_option( 'agah_erp_page_id' );
	$url = $id ? get_permalink( $id ) : '';
	$url = $url ? $url : home_url( '/accounting/' );
	return $args ? add_query_arg( $args, $url ) : $url;
}

/** ساخت پایگاه داده و صفحهٔ /accounting/ هنگام فعال‌سازی قالب. */
function agah_erp_activate() {
	\Agah\Erp\Core\Schema::install();
	agah_erp_ensure_page();
}
add_action( 'after_switch_theme', 'agah_erp_activate' );

function agah_erp_ensure_page() {
	$id = (int) get_option( 'agah_erp_page_id' );
	if ( $id && 'page' === get_post_type( $id ) && 'trash' !== get_post_status( $id ) ) {
		return;
	}
	$existing = get_page_by_path( 'accounting' );
	if ( $existing ) {
		$id = (int) $existing->ID;
		if ( false === strpos( $existing->post_content, '[agah_erp]' ) ) {
			wp_update_post( array( 'ID' => $id, 'post_content' => $existing->post_content . "\n[agah_erp]" ) );
		}
	} else {
		$id = (int) wp_insert_post( array(
			'post_title' => 'سامانه حسابداری', 'post_name' => 'accounting', 'post_status' => 'publish', 'post_type' => 'page', 'post_content' => '[agah_erp]',
		) );
	}
	if ( $id ) {
		update_option( 'agah_erp_page_id', $id, false );
	}
}

/** ارتقای خودکار ساختار پایگاه داده (فقط وقتی نسخه عوض شده باشد). */
add_action( 'init', array( '\Agah\Erp\Core\Schema', 'maybeUpgrade' ), 5 );
add_action( 'init', 'agah_erp_ensure_page', 6 );

/** هشدار مدیریتی: موتور غیر InnoDB یا نبود کلیدهای خارجی = خطر ناسازگاری داده. */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$eng = (array) get_option( 'agah_erp_engine_error', array() );
	$fk  = \Agah\Erp\Core\Schema::missingForeignKeys();
	if ( $eng ) {
		echo '<div class="notice notice-error"><p><strong>حسابداری آگاه:</strong> جدول‌های زیر InnoDB نیستند و تراکنش مالی امن نیست: <code>' . esc_html( implode( ', ', $eng ) ) . '</code>. موتور پایگاه داده را به InnoDB تبدیل کنید.</p></div>';
	}
	if ( $fk ) {
		echo '<div class="notice notice-warning"><p><strong>حسابداری آگاه:</strong> برخی کلیدهای خارجی ساخته نشد: <code>' . esc_html( implode( ', ', $fk ) ) . '</code>. جزئیات در لاگ خطای سرور.</p></div>';
	}
	if ( ! \Agah\Erp\Core\Crypto::hasConfiguredKey() ) {
		echo '<div class="notice notice-info"><p><strong>حسابداری آگاه:</strong> کلید رمزنگاری اختصاصی تنظیم نشده است. ثابت <code>AGAH_ENC_KEY</code> را (base64 از ۳۲ بایت تصادفی) در wp-config.php تعریف کنید؛ بدون آن، داده‌های رمزشده به saltهای وردپرس وابسته‌اند.</p></div>';
	}
} );

\Agah\Erp\Http\Page::register();

\Agah\Erp\Security\Auth::register();
\Agah\Erp\Http\SecurityController::register();
add_action('agah_erp_daily', ['\Agah\Erp\Core\Idempotency', 'cleanup']);
add_action('init', function(){ if(!wp_next_scheduled('agah_erp_daily')) wp_schedule_event(time()+3600, 'daily', 'agah_erp_daily'); });

\Agah\Erp\Http\ModuleController::register();
