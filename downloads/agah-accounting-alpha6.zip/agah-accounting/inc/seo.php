<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* اگر افزونهٔ سئو فعال است، قالب خودش چیزی چاپ نمی‌کند تا تکراری نشود */
function agah_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

function agah_seo_head() {
	if ( agah_seo_plugin_active() ) {
		return;
	}
	$name = get_bloginfo( 'name' );
	$home = is_front_page() || is_home();
	$img  = agah_mod( 'agah_og_image', '' );

	if ( is_singular() && ! $home ) {
		$id    = get_queried_object_id();
		$title = get_the_title( $id );
		$desc  = has_excerpt( $id ) ? get_the_excerpt( $id ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_post_field( 'post_content', $id ) ) ), 28, '' );
		$url   = get_permalink( $id );
		$type  = 'article';
		if ( has_post_thumbnail( $id ) ) {
			$img = get_the_post_thumbnail_url( $id, 'large' );
		}
	} else {
		$title = $name;
		$desc  = agah_mod( 'agah_meta_desc', get_bloginfo( 'description' ) );
		$url   = $home ? home_url( '/' ) : '';
		$type  = 'website';
	}
	if ( ! $img && has_custom_logo() ) {
		$img = wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' );
	}

	$desc = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $desc ) ) );
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<meta name="theme-color" content="' . esc_attr( agah_mod( 'agah_c_brand', '#1F6F5C' ) ) . '">' . "\n";
	echo '<meta property="og:locale" content="fa_IR">' . "\n";
	echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( $name ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	if ( $desc ) {
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	if ( $url ) {
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	}
	if ( $img ) {
		echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
	}
	echo '<meta name="twitter:card" content="' . ( $img ? 'summary_large_image' : 'summary' ) . '">' . "\n";

	/* داده‌های ساختاریافتهٔ سازمان: فقط اطلاعاتی که خودتان واقعاً در سفارشی‌ساز وارد کرده‌اید */
	if ( $home ) {
		$data = array( '@context' => 'https://schema.org', '@type' => 'Organization', 'name' => $name, 'url' => home_url( '/' ) );
		if ( has_custom_logo() ) {
			$data['logo'] = wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' );
		}
		if ( $v = get_theme_mod( 'agah_phone', '' ) )   $data['telephone'] = $v;
		if ( $v = get_theme_mod( 'agah_email', '' ) )   $data['email'] = $v;
		if ( $v = get_theme_mod( 'agah_address', '' ) ) $data['address'] = $v;
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . '</script>' . "\n";
	}
}
add_action( 'wp_head', 'agah_seo_head', 2 );

/* دکمه‌های تماس شناور (فقط موارد پرشده) */
function agah_floating_contact() {
	$b = array();
	if ( $p = agah_mod( 'agah_fl_phone', '' ) ) {
		$b[] = array( 'تماس', 'tel:' . preg_replace( '/[^0-9+]/', '', $p ), 'phone' );
	}
	foreach ( array( 'agah_fl_whatsapp' => 'واتساپ', 'agah_fl_telegram' => 'تلگرام', 'agah_fl_eitaa' => 'ایتا' ) as $k => $l ) {
		if ( $u = agah_mod( $k, '' ) ) {
			$b[] = array( $l, $u, $k );
		}
	}
	if ( ! $b ) {
		return;
	}
	echo '<div class="float-contact" aria-label="راه‌های ارتباطی">';
	foreach ( $b as $x ) {
		printf( '<a class="fc" href="%s" rel="noopener">%s</a>', esc_url( $x[1], array( 'http', 'https', 'tel' ) ), esc_html( $x[0] ) );
	}
	echo '</div>';
}
add_action( 'wp_footer', 'agah_floating_contact' );
