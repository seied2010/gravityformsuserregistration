<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* زمان مطالعه (فارسی‌پسند: شمارش کلمه با فاصله، نه str_word_count) */
function agah_reading_time( $post_id = null ) {
	$text  = wp_strip_all_tags( strip_shortcodes( get_post_field( 'post_content', $post_id ?: get_the_ID() ) ) );
	$words = count( preg_split( '/\s+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY ) );
	$min   = max( 1, (int) ceil( $words / 180 ) );
	return number_format_i18n( $min ) . ' دقیقه مطالعه';
}

/* دستهٔ اصلی نوشته (دستهٔ پیش‌فرض «دسته‌بندی‌نشده» نمایش داده نمی‌شود) */
function agah_primary_category( $post_id = null ) {
	$cats = get_the_category( $post_id ?: get_the_ID() );
	foreach ( (array) $cats as $c ) {
		if ( (int) $c->term_id !== (int) get_option( 'default_category' ) ) {
			return $c;
		}
	}
	return null;
}

function agah_breadcrumbs() {
	$items = array( array( 'خانه', home_url( '/' ) ) );
	$posts = get_option( 'page_for_posts' );
	if ( $posts ) {
		$items[] = array( get_the_title( $posts ), get_permalink( $posts ) );
	}
	if ( is_singular( 'post' ) && ( $c = agah_primary_category() ) ) {
		$items[] = array( $c->name, get_category_link( $c ) );
	}
	$items[] = array( get_the_title(), '' );
	echo '<nav class="crumbs" aria-label="مسیر صفحه"><ol>';
	foreach ( $items as $i => $it ) {
		echo '<li>' . ( $it[1] ? '<a href="' . esc_url( $it[1] ) . '">' . esc_html( $it[0] ) . '</a>' : '<span aria-current="page">' . esc_html( wp_trim_words( $it[0], 8, '…' ) ) . '</span>' ) . '</li>';
	}
	echo '</ol></nav>';
}

/* ---------- آدرس (پیوند یکتا) ---------- */

/* ۱) نیم‌فاصله، «ي/ك» عربی و ارقام فارسی در نامکِ آدرس نرمال می‌شوند (در غیر این صورت آدرس با %e2%80%8c و ... زشت می‌شود) */
function agah_slug_normalize( $title ) {
	$title = str_replace( array( "\xE2\x80\x8C", 'ي', 'ك' ), array( '-', 'ی', 'ک' ), $title );
	return strtr( $title, array( '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9' ) );
}
add_filter( 'sanitize_title', 'agah_slug_normalize', 5 );

/* ۲) نامک خودکارِ نوشتهٔ تازه کوتاه می‌شود (۶ کلمهٔ اول عنوان). نامکی که خودتان بنویسید دست‌نخورده می‌ماند */
function agah_short_auto_slug( $data, $postarr ) {
	if ( 'post' !== $data['post_type'] || ! empty( $postarr['post_name'] ) || empty( $data['post_title'] ) ) {
		return $data;
	}
	if ( ! in_array( $data['post_status'], array( 'publish', 'future', 'private' ), true ) ) {
		return $data;
	}
	$slug = sanitize_title( wp_trim_words( $data['post_title'], 6, '' ) );
	if ( $slug ) {
		$id = isset( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;
		$data['post_name'] = wp_unique_post_slug( $slug, $id, $data['post_status'], $data['post_type'], (int) $data['post_parent'] );
	}
	return $data;
}
add_filter( 'wp_insert_post_data', 'agah_short_auto_slug', 10, 2 );

/* ۳) هشدار مدیریتی: ساختار پیوند یکتا مناسب نیست. خودکار تغییر نمی‌دهیم (تغییر خودکار لینک‌های قدیمی و سئو را می‌شکند) */
function agah_permalink_notice() {
	if ( ! current_user_can( 'manage_options' ) || get_user_meta( get_current_user_id(), 'agah_perma_dismissed', true ) ) {
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'options-permalink' ), true ) ) {
		return;
	}
	$st = (string) get_option( 'permalink_structure' );
	if ( '' !== $st && ! preg_match( '/%(year|monthnum|day|hour|minute|second|category|author|post_id)%/', $st ) ) {
		return;
	}
	$dismiss = wp_nonce_url( add_query_arg( 'agah_perma_dismiss', '1' ), 'agah_perma' );
	echo '<div class="notice notice-warning"><p><strong>آدرس نوشته‌ها:</strong> ساختار فعلی پیوند یکتا (<code dir="ltr">' . esc_html( $st ?: 'ساده: ?p=123' ) . '</code>) برای سئو و خوانایی بهینه نیست. پیشنهاد: «نام نوشته» (<code dir="ltr">/%postname%/</code>) از «تنظیمات › پیوندهای یکتا». '
		. 'اگر سایت قبلاً در گوگل ایندکس شده، بعد از تغییر باید ریدایرکت ۳۰۱ از آدرس‌های قدیمی بگیرید. <a href="' . esc_url( admin_url( 'options-permalink.php' ) ) . '">باز کردن تنظیمات</a> | <a href="' . esc_url( $dismiss ) . '">دیگر نشان نده</a></p></div>';
}
add_action( 'admin_notices', 'agah_permalink_notice' );

function agah_permalink_dismiss() {
	if ( isset( $_GET['agah_perma_dismiss'] ) && current_user_can( 'manage_options' ) && check_admin_referer( 'agah_perma' ) ) {
		update_user_meta( get_current_user_id(), 'agah_perma_dismissed', 1 );
		wp_safe_redirect( remove_query_arg( array( 'agah_perma_dismiss', '_wpnonce' ) ) );
		exit;
	}
}
add_action( 'admin_init', 'agah_permalink_dismiss' );
