# گزارش بستهٔ سوم — مراحل ۷ تا ۹

نسخه **3.0.0-alpha4**، ERP **0.9.0-alpha**، Schema **5**، ۴۱ جدول. تاریخ اجرا: ۱۹ اکتبر ۲۰۲۶. مبنا v3.0.0-alpha3 است. این بسته برای بازبینی آزمایشی فنی/حسابداری تحویل می‌شود؛ آماده‌بودن کل ERP یا بهره‌برداری نهایی ادعا نمی‌شود.

## نتیجهٔ قابل بررسی

- فروش: پیش‌فاکتور، سفارش، پیش‌نویس/صدور فاکتور، برگشت مرتبط و سقف تجمعی؛ تخفیف خط و کل با ریال دقیق؛ نرخ/مبلغ مالیات ذخیره‌شده؛ ثبت دریافتنی/فروش/تخفیف/مالیات و بهای تمام‌شده در دائمی. چاپ با snapshot اطلاعات غیرمحرمانه و A4/A5؛ گزارش خالص به شخص/کالا/ثبت‌کننده/ماه و سود ناخالص؛ مانده و aging فعلی.
- خرید: درخواست→سفارش→فاکتور، برگشت مرتبط، هزینه جانبی تسهیم‌شده بر بهای خالص/مقدار کالا، بدهی تأمین‌کننده؛ روش periodic/inventory. پرداخت فوری یا مستقل و اعمال پیش‌پرداخت واقعی؛ چک و وجه نقد/بانک از خزانهٔ موجود استفاده می‌کنند.
- انبار: چندانبار، موجودی واقعی، کاردکس با ماندهٔ جاری، انتقال با حفظ ارزش، رسید افتتاحیه، حواله مصرف، انبارگردانی با مقدار شمارش‌شده و سند تعدیل؛ حداقل موجودی/هشدار؛ میانگین موزون متحرک و FIFO با لایه/برداشت و ابطال دقیق؛ تطبیق مجموع ارزش با دفتر موجودی در دائمی.
- یکپارچگی: سند/شماره/انبار/اعمال پیش‌پرداخت/تسویه/ممیزی و idempotency در تراکنش مشترک؛ عملیات شکست‌خورده شماره یا اثر جزئی باقی نمی‌گذارد. ابطال برگه‌های مالی فیزیکی حذف نمی‌کند. برگشت از نرخ و مقدار و بهای مبدأ پیروی می‌کند. استرداد، دریافتنی مشتری را با پرداختنی تأمین‌کننده اشتباه نمی‌گیرد.
- اصلاح حالت مرزی: اگر دریافت اصلی بعد از استرداد برگشت باطل شود، outstanding اصل، پول استردادشده را هم لحاظ می‌کند. این حالت برای هم‌خوانی aging با دفتر تست مستقل دارد.
- رابط فارسی محلی و بدون CDN؛ جدول قابل اسکرول، منوی جمع‌شونده موبایل، PRG، خطای امن و حفظ ورودی، خروجی CSV همه صفحات با مجوز مستقل. هیچ داده مالی نمونه در نصب عادی ایجاد نمی‌شود.

## آزمون‌های اجراشده و نتیجهٔ واقعی

| بررسی | دستور/روش | نتیجه |
|---|---|---|
| مجموعه یک‌دستوری | `bash tests/run-all.sh` روی /workspace/agah-test | pass؛ ۲۲۵ PHP در آن زمان، ۱۹ بررسی چندفرایندی و ۱۰۴ مرورگر؛ همگی صفر شکست |
| PHP پس از آخرین اصلاح مالی | `wp eval-file .../tests/run.php` | **۲۲۶ pass، صفر fail/skipped**؛ integration-final.log |
| مرورگر تجارت پس از تقویت ورودی آرایه | `node tests/security/trade-browser.cjs <fixture خصوصی> <screenshots>` | **۳۴ pass، صفر fail/skipped**؛ browser-trade-final.log؛ همراه ۴۳+۲۸ قبلی مجموع جاری **۱۰۵** بررسی مرورگر |
| رقابت مالی نهایی | `python3 tests/integration/trade-concurrency.py` | **۷ pass**؛ هم‌زمانی فاکتور/موجودی/برگشت/پیش‌پرداخت و سه invariant؛ با ۷+۵ قبلی مجموع ۱۹ |
| نصب مستقل WordPress تازه | `wp theme install /tmp/alpha4.zip --activate` | pass؛ theme=3.0.0-alpha4 schema=5 tables=41 companies=0 قبل از اجرای fixture |
| PHP از ZIP نصب مستقل | همان `wp eval-file .../tests/run.php` داخل agah-fresh-7-9 | **۲۲۶ pass، صفر fail/skipped**؛ clean-integration.log |
| smoke از ZIP نصب مستقل | `wp eval-file .../tests/smoke.php` | **۲۷ PASS، ALL PASSED**؛ clean-smoke.log |
| ارتقای واقعی alpha3→alpha4 | `tests/upgrade-trade.php capture` روی نسخه قدیم؛ نصب ZIP؛ `verify` روی جدید | **حفظ هر ۳۴ جدول قدیمی** با مقایسه هش تمام ستون‌های قدیمی؛ افزوده‌شدن فقط grants و رکورد migration در جدول‌های مربوط مجاز؛ صفر داده از دست رفت |
| PHP syntax | `find ... -name '*.php' -print0` به `xargs -0 -n1 php -l` | **۱۱۷ فایل pass**؛ php-lint.log |
| JS syntax | `node --check` برای assets و runnerهای مرورگر | pass |
| چاپ PDF | تولید واقعی با Playwright و بررسی MediaBox | A4: 594.95996×841.91998 pt؛ A5: 420×594.95996 pt، هر دو PDF واقعی |
| آرشیو | ZipFile.testzip و نصب از خود ZIP | pass؛ checksum بسته‌ها در SHA256SUMS.txt |

آزمون نهایی PHP شامل همهٔ ۵۷ سناریو/قید افزوده بر ۱۶۹ بررسی قدیمی است. حوزه‌ها: گردکردن چهاراعشار، تخفیف و تسهیم دقیق، نرخ تأییدنشده، تغییر نرخ draft، ثبات snapshot صادرشده، برگشت کامل و جزئی تا آخرین ریال، خرید ادواری/دائمی، FIFO و ابطال لایه، موجودی ناکافی، انتقال/شمارش، سند قطعی و rollback تسویه، پیش‌پرداخت/استرداد، نقش فروشنده، IDOR، تمام FKهای مرکب جدید و زنجیره ممیزی/توازن دفتر. تست malformed array در مرورگر، فرم را با خطای امن و قابل استفاده حفظ می‌کند.

نسخه‌های واقعاً استفاده‌شده: WordPress 7.1.3، PHP 8.2.34، MariaDB 11.4.13، Playwright 1.62.1 و Chromium محلی. fixture مرورگر حاوی رمز موقت است و در بسته/Git/گزارش نیست. عکس‌ها و PDF بازبینی فقط شرکت‌های آزمایشی را نشان می‌دهند. mail transport در Docker پیکربندی نشده؛ هشدار sendmail هنگام نصب WordPress به‌معنی تست ایمیل نیست.

## حدود و موارد باز همین بسته

این موارد صریحاً جزو امکانات آماده نیستند:

1. گزینهٔ فعال‌کردن موجودی منفی ساخته نشده؛ منفی همیشه رد می‌شود. برای پشتیبانی مالی درست، قیمت‌گذاری خروج قبل از خرید و سند اصلاح بهای بعدی باید جدا طراحی/آزمایش شود.
2. تغییر روش بهای تمام‌شده/ادواری‌دائمی پس از گردش، بازقیمت‌گذاری تاریخ گذشته و backdate کالا/انبار فراهم نیستند. فرایند درخواستی که به گردش بعدی وابسته است، با پیام روشن رد می‌شود؛ داده یا قیمت تاریخی پنهانی بازنویسی نمی‌شود.
3. ابطال برگه دارای سند قطعی، دوره بسته یا وابستگی زنده، رد می‌شود. تسویه مشترک چندفاکتوری باید ابتدا مستقل در خزانه باطل شود. برگشت مرتبط همچنان برای گردش‌های بعدی قابل استفاده است، با شرط موجودی و تاریخ معتبر.
4. هزینه جانبی خرید بین goods به ارزش/مقدار تسهیم و جزو بدهی همان تأمین‌کننده می‌شود؛ چند طلبکار هزینه جانبی یا مالیات جداگانه حمل/خدمات جانبی ندارد. مالیاتِ خط از خالص کالای همان خط است. این سیاست باید پیش از مصرف واقعی به تأیید حسابدار مسئول برسد.
5. رسید انبار در UI برای افتتاحیه، حواله برای مصرف و شمارش برای تعدیل است؛ حساب مقابل افتتاحیه/سایر هزینه‌ها ثابت سیستمی است و انتخاب حساب مقابل در این UI ندارد.
6. aging گزارش ماندهٔ فعلی تا امروز است؛ بازیابی ماندهٔ تاریخی پس از ابطال‌های بعدی ندارد. گروه ماه، ماه میلادیِ ذخیره DB است و صریحاً همین برچسب را دارد. سود کالا گزارش مدیریتی از snapshot بهای خط است؛ در ادواری، صورت مالی نهایی به بستن دوره وابسته است.
7. بستن موجودی/خرید روش ادواری و صورت‌های مالی کامل، مرحله۱۱ است. پیوست، حقوق، دارایی ثابت، گزارش قانونی، backup/restore و سفارشی‌سازی نهایی مراحل بعد هستند.
8. فاکتور ساخته‌شده خارج از UI alpha3 ممکن است انبار/بهای snapshot نداشته باشد؛ ارتقا آن را حدس نمی‌زند. استفاده از برگشت/انبار برای چنین داده‌ای نیازمند مهاجرت اختصاصی و بازبینی است. دادهٔ قبلی حفظ می‌شود.
9. PDF از چاپ مرورگر است؛ آرشیو امضاشده/مهر دیجیتال، ارسال دولتی، پیامک/ایمیل واقعی، HTTPS عملیاتی، سازگاری افزونه‌های ثالث و بار سنگین آزموده نشده‌اند. تغییر فایل لوگوی رسانه در WordPress، آرشیو باینری ثابت لوگو ایجاد نمی‌کند.

تغییر ساختار عمومی بدون دلیل انجام نشد؛ قرارداد فاکتور موجود توسعهٔ افزایشی یافت. ایجاد سرویس Inventory پیش‌نیاز صدور فروش/خرید اتمیک بود؛ سه مرحله به‌صورت یک بسته منسجم تست و نسخه‌گذاری می‌شوند. نقش سفارشی خودکار گسترش نمی‌یابد؛ grants منابع تازه فقط به نقش‌های builtin مناسب می‌رسند. مدیر WordPress عضو خودکار شرکت نیست.

## نصب و ارتقا

۱. فایل `agah-accounting-3.0.0-alpha4.zip` را **بدون استخراج** در نمایش ← پوسته‌ها ← افزودن ← بارگذاری پوسته نصب کنید. فایل review ZIP قالب قابل نصب نیست.
۲. برای ارتقا همان پوشه agah-accounting جایگزین شود؛ ابتدا backup هماهنگ فایل+DB+کلید بگیرید و نسخه آزمایشی سایت را بررسی کنید. کلید رمزنگاری قبلی و saltها تغییر نکنند.
۳. migration افزایشی Schema4→5 هفت جدول، FK و ستون‌های تازه می‌سازد؛ گزینه نسخه فقط بعد از موفقیت ثبت می‌شود. دادهٔ مالی و کاربران نسخه قبلی حذف نمی‌شوند؛ downgrade خودکار نداریم.
۴. پیش از گردش واقعی، در بخش انبارها روش average/FIFO و ادواری/دائمی را انتخاب و انبار فعال تعریف کنید. موجودی افتتاحیه واقعی با بهای کل واقعی، شخص و کالا و نرخ مالیات تأییدشده لازم است. خدمت انبار نمی‌پذیرد.
۵. پیش‌نویس را بازبینی و صادر کنید؛ چک/تسویه و برگشت از صفحه مربوط و با مجوز مناسب انجام می‌شود. نقص ارتقا یا FK لاگ خصوصی می‌خواهد؛ هشدار را دور نزنید.

## باقی‌ماندهٔ پروژه

بستهٔ بعدی مراحل **۱۰–۱۲: هزینه و درآمد متفرقه، صورت‌های مالی و بستن حساب‌ها/سال، داشبورد** است. سپس ۱۳–۱۵ پیوست، حقوق و دارایی ثابت؛ ۱۶–۱۸ گزارش قانونی، پشتیبان/پایش و ظاهر نهایی. موارد باز همین بسته باید در بازبینی تعیین تکلیف شوند. طرح تفکیک ERP به افزونه موجود است اما اجرای آن انجام نشده و تأیید مستقل می‌خواهد.

## فهرست فایل‌های جدید یا تغییرکرده

- `CHANGELOG.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `HANDOFF-NEXT.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `README.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `REPORT-7-9.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `changelog.txt` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/ARCHITECTURE.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/CONTRACTS-7-9.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/DB-SCHEMA.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/FILE-MAP.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/INSTALL.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/PLUGIN-SPLIT.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/README.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/ROADMAP.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/SECURITY.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/TESTING.md` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `docs/test-results/phase-7-9/browser-trade-final.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/clean-final-install.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/clean-install.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/clean-integration.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/clean-smoke.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/concurrency-trade-final.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/integration-final.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/php-lint.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/run-all.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/upgrade-install.log` — شاهد خام اجرای واقعی آزمون/نصب
- `docs/test-results/phase-7-9/upgrade-preservation.log` — شاهد خام اجرای واقعی آزمون/نصب
- `erp/assets/commerce.js` — دارایی محلی فرم/چاپ/منوی موبایل
- `erp/assets/erp.css` — دارایی محلی فرم/چاپ/منوی موبایل
- `erp/bootstrap.php` — بارگذاری ماژول‌های جدید و نسخه ERP
- `erp/src/Core/BusinessSchema.php` — ستون‌های افزایشی فاکتور/خط و counter_sys خزانه
- `erp/src/Core/Schema.php` — نسخه۵ و اتصال مهاجرت افزایشی
- `erp/src/Core/Settings.php` — روش بهای تمام‌شده شرکت
- `erp/src/Core/TradeMath.php` — تسهیم دقیق و برگشت تجمعی ریال
- `erp/src/Core/TradeSchema.php` — DDL و FKهای هفت جدول و مجوزهای افزایشی
- `erp/src/Http/CommerceController.php` — اتصال آداپتور جدید به PRG و کنترل مجوز مشترک
- `erp/src/Http/ModuleController.php` — اتصال آداپتور جدید به PRG و کنترل مجوز مشترک
- `erp/src/Http/TradeController.php` — آداپتور HTTP، مجوز، ورودی و CSV
- `erp/src/Modules/Accounting/VoucherService.php` — نگاشت مجوز و کنترل مبدأ واقعی سند خودکار
- `erp/src/Modules/Catalog/CatalogService.php` — جلوگیری از تغییر ساختار و حذف کالای دارای گردش انبار
- `erp/src/Modules/Company/CompanyService.php` — اعطای مجوز تازه در ساخت شرکت بدون داده نمونه
- `erp/src/Modules/Inventory/StockService.php` — گردش و ارزش‌گذاری، لایه FIFO، شمارش و تطبیق
- `erp/src/Modules/Trade/InvoiceService.php` — قیمت، زنجیرهٔ برگه، صدور، برگشت، ابطال، پیش‌پرداخت و گزارش
- `erp/src/Modules/Treasury/TreasuryService.php` — تسویه و استرداد با حساب مقابل صحیح، مانده و پیش‌بینی
- `erp/src/Security/Caps.php` — منابع مستقل انبار/گردش و نقش مناسب
- `erp/views/business-treasury-form.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/legacy-viewCompany.php` — مسیریابی مجوز و منوی جمع‌شونده موبایل
- `erp/views/stock-docs.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/stock-inventory.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/stock-line.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/stock-warehouses.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/trade-aging.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/trade-document.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/trade-filters.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/trade-form.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/trade-line.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/trade-list.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `erp/views/trade-report.php` — نمای مستقل فارسی با escape، فرم و نمایش داده واقعی
- `functions.php` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `readme.txt` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `style.css` — مستندسازی نسخه، قرارداد، محدودیت و مسیر ادامه
- `tests/integration/business.php` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/integration/core.php` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/integration/trade-concurrency-setup.php` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/integration/trade-concurrency-worker.php` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/integration/trade-concurrency.py` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/integration/trade.php` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/run-all.sh` — افزودن آزمون‌های دامنه، رقابت و رابط تجارت
- `tests/run.php` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/security/trade-browser.cjs` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/trade-browser-fixture.php` — سناریوی واقعی آزمون یا به‌روزرسانی انتظار Schema
- `tests/upgrade-trade.php` — مقایسه هش تمام ستون‌های قدیمی هنگام ارتقای واقعی

## پیوست خروجی خام

گزارش‌های نصب/ارتقا و syntax به‌صورت فایل جدا در docs/test-results/phase-7-9 حفظ شده‌اند. در ادامه خروجی واقعی آخرین مجموعه PHP، آخرین رابط تجارت، رقابت تجارت و حفظ دادهٔ ارتقا آمده است. خروجی اجرای یک‌دستوری قبل از افزودن آخرین تست نیز با تعداد واقعی آن در run-all.log حفظ شده است؛ شمارش‌ها با هم جایگزین نشده‌اند.

### integration-final.log

```text
PASS RFC6238 SHA1 timestamp 59
PASS RFC6238 SHA1 timestamp 1111111109
PASS RFC6238 SHA1 timestamp 1111111111
PASS RFC6238 SHA1 timestamp 1234567890
PASS RFC6238 SHA1 timestamp 2000000000
PASS RFC6238 SHA1 timestamp 20000000000
PASS TOTP wrong format rejected
PASS TOTP current/adjacent steps and expiry
PASS Base32 random key uses 32 valid symbols
PASS Password short/no letter/no number rejected
PASS Money accepts Persian digits and exact toman fraction
PASS Money overflow and fractions rejected
PASS Encryption authentication detects tampering
PASS Jalali leap day and roundtrip
PASS Upgrade preserves baseline rows and installs business tables
PASS Schema upgrade repeatability preserves rows
PASS Idempotency claim complete and replay result
PASS Token payload substitution and company/user tampering rejected
PASS Token rollback releases claim and domain change
PASS Unsigned and expired form token rejected
PASS Idempotency requires transaction
PASS Rate limit exact cap and window expiry
PASS Login errors identical for invalid username/password
PASS Login IP+user throttle also covers email alias
PASS Login IP aggregate throttles many distinct usernames
PASS New session has no second factor marker
PASS Idle session destroys only expired token
PASS TOTP enrollment requires correct password
PASS Pending secret encrypted and bound to session
PASS Enable verifies first code and creates eight hashed backup codes
PASS TOTP initial code replay is rejected
PASS TOTP next step accepted once; replay rejected
PASS Backup code is consumed exactly once
PASS Other WP session cannot inherit verified factor
PASS Require2fa company policy applied
PASS TOTP brute force bounded
PASS TOTP disable requires password and invalidates marker
PASS SMS disabled without selected provider
PASS SMS code stored hashed and bound to session; one-time use
PASS SMS expires after two minutes
PASS SMS five failed attempts block correct code
PASS SMS hourly send cap enforced
PASS Cannot remove/downgrade last active company admin
PASS Member existing user added with scoped role
PASS Custom role matrix saves exact caps and audits
PASS System role editing/deleting rejected
PASS Removed member history retained; no WordPress user deleted
PASS Company edits encrypt national identifier and preserve metadata
PASS Detail create/update/read persists
PASS Duplicate detail code rejected
PASS Unused custom account structure can update
PASS Balanced draft saved without number and excluded from ledger
PASS Draft imbalance allowed; approval rejected
PASS Both debit and credit in one line rejected
PASS Non-leaf and incompatible details rejected
PASS Float money rejected and no partial voucher persists
PASS Approval allocates number and journals balance
PASS Approved voucher cannot become unbalanced by edit
PASS Optimistic revision rejects stale edit
PASS Finalize locks contents and physical deletion
PASS Reopen requires reason and keeps number
PASS Detail with turnover cannot delete
PASS Void retains number and excludes journal
PASS System post creates approved source-linked voucher
PASS System duplicate source/manual edit/void rejected
PASS System void returns effect from journal
PASS Account ledger opening and cumulative closing from real entries
PASS Trial balance two/four columns and general/subsidiary all balance
PASS Ledger pagination carries previous page running balance
PASS Closed period blocks create and edit of existing voucher
PASS Year with draft cannot close; no-draft closes and reopens
PASS Approval rechecks account activation after draft creation
PASS Audit intact after all operations; national id masked
PASS Foreign company context always NotFound
PASS Foreign account line rejected before DB mutation
PASS Company-scoped detail/report/member IDOR rejected
PASS Voucher foreign id get/edit/state/delete all NotFound
PASS Service company argument cannot override current context
PASS Viewer server denies company_settings.edit
PASS Viewer server denies member.create
PASS Viewer server denies member.edit
PASS Viewer server denies role.edit
PASS Viewer server denies detail.create
PASS Viewer server denies detail.delete
PASS Viewer server denies voucher.create
PASS Viewer server denies voucher.edit
PASS Viewer server denies voucher.approve
PASS Viewer server denies voucher.finalize
PASS Viewer server denies voucher.void
PASS Viewer server denies voucher.reopen
PASS Viewer server denies voucher.delete
PASS Viewer can read vouchers and real ledger
PASS Role matrix exact capabilities company_admin
PASS Role matrix exact capabilities accountant
PASS Role matrix exact capabilities cashier
PASS Role matrix exact capabilities storekeeper
PASS Role matrix exact capabilities salesperson
PASS Role matrix exact capabilities viewer
PASS DB rejects cross-company role assignment
PASS No new business foreign key bypass: voucher detail of foreign company rejected by DB
PASS Business schema all composite foreign keys installed
PASS National check digits reject repeated and invalid personal IDs
PASS Party encrypts national ID, blind index and public hint only
PASS Duplicate national ID rejected and counter rollback leaves no party
PASS Party name and active status update its linked detail atomically
PASS Sensitive reveal requires capability and creates masked audit
PASS Seeded tax is unknown and cannot issue taxable snapshot
PASS Tax snapshot uses date and half-up per-line integer rounding
PASS Overlapping tax dates and out-of-range percentage rejected
PASS Goods/service price fields persist as exact Rial integers
PASS Referenced unit deletion and duplicate barcode rejected
PASS IBAN rejects bad checksum and account has dedicated detail
PASS Receipt posts balanced automatic source voucher and bank balance
PASS Party with posted movement cannot delete; statement matches its ledger
PASS Transfer changes both accounts and preserves aggregate cash
PASS Same-account transfer and cash-to-bank method mismatch rejected
PASS Pending cheque affects notes receivable and forecast, not bank
PASS Collected cheque moves notes to bank
PASS Stale cheque revision and invalid backwards date rejected
PASS Returned collected cheque reverses bank and restores party claim
PASS Void document reverses all event vouchers and original with no residual effect
PASS Partial multi-item settlement sums to allocated invoice amount
PASS Over-settlement rolls back number, document and voucher atomically
PASS Returned cheque releases only its allocation and retains cash settlement
PASS Void settlement document releases all remaining allocations
PASS Changing tax rate does not mutate stored invoice-line snapshot
PASS Bank reconciliation uses matched real ledger lines and shows zero difference
PASS Cash account cannot be reconciled as a bank
PASS Cashier can post receipt without generic manual-voucher permission
PASS Cashier cannot reveal national identity or confirm tax rates
PASS Cross-company party/account/item/tax inputs rejected by services
PASS Outgoing payment cheque collection/return restores payable and cash
PASS Final source voucher blocks full void and rolls back earlier event reversals
PASS Credit limit warning equals the real receivable-detail ledger balance
PASS Bank reconciliation rejects a same-company line from another treasury account
PASS DB composite FK rejects foreign parent: fk_b_parties_detail_id
PASS DB composite FK rejects foreign parent: fk_b_items_unit_id
PASS DB composite FK rejects foreign parent: fk_b_items_group_id
PASS DB composite FK rejects foreign parent: fk_b_items_tax_rate_id
PASS DB composite FK rejects foreign parent: fk_b_items_sale_account_id
PASS DB composite FK rejects foreign parent: fk_b_items_purchase_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_accounts_detail_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_accounts_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_party_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_source_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_target_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_fiscal_year_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_doc_items_doc_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_doc_items_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_doc_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_doc_item_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_party_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_cheque_events_cheque_id
PASS DB composite FK rejects foreign parent: fk_b_cheque_events_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_party_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_fiscal_year_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_invoice_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_item_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_tax_rate_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_invoice_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_doc_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_doc_item_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliations_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliation_items_reconciliation_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliation_items_voucher_line_id
PASS Business audit chain intact and all approved vouchers balanced
PASS Trade allocation preserves every Rial including zero weights and rounding
PASS Proforma and sales order issue without accounting or inventory movement
PASS Repeated conversion and stale draft revisions rejected
PASS Purchase capitalizes net plus allocated freight and keeps input VAT separate
PASS Costing method and goods accounting mode cannot change after movement
PASS Sale uses four decimals, per-line rounding, exact discounts and cost-of-sales
PASS Issued invoice keeps tax snapshot when rate changes
PASS Insufficient stock rolls back vouchers, invoice number and every stock move
PASS Purchase cannot be voided after dependent inventory movement
PASS Full linked sale return restores original cost and original tax, capped by source qty
PASS Return void restores remaining return entitlement and exact inventory value
PASS Treasury allocation sees actual invoice balance and disallows overpayment
PASS Invoice void reverses its treasury settlement, source voucher and inventory atomically
PASS Warehouse transfer preserves exact company value and destination cost
PASS Stocktake treats input as counted stock and posts shortage adjustment
PASS Minimum alert and kardex use real counted quantities and running values
PASS Purchase return removes inventory and input VAT with balanced supplier reversal
PASS FIFO consumes oldest layer then partial next layer at exact cost
PASS FIFO void restores layer quantities and values without deleting picks
PASS Backdated stock entry rejected instead of silently recosting history
PASS Invoice issue applies advance and immediate cash in one transaction
PASS Paid sale return refunds through receivables rather than supplier payables
PASS Void frees advance and reverses its allocation voucher but preserves original advance
PASS Unconfirmed tax prevents draft pricing and leaves no invoice or lines
PASS Foreign warehouse item invoice and company are rejected at public services
PASS Salesperson issues own automatic invoice without manual voucher permission
PASS Salesperson cannot issue purchase or stock document or void issued sale
PASS Sales and purchase reports group actual net rows and aging uses real balance
PASS Trade audit chains and all approved documents remain balanced
PASS Three partial returns sum exactly to original rounded amount and discount
PASS Changing catalog kind or deleting item with stock-only history is forbidden
PASS Trade DB composite FK rejects foreign parent: fk_t_invoices_parent_id
PASS Trade DB composite FK rejects foreign parent: fk_t_invoice_lines_source_line_id
PASS Trade DB composite FK rejects foreign parent: fk_t_invoice_lines_warehouse_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_docs_fiscal_year_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_docs_voucher_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_warehouse_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_item_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_invoice_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_invoice_line_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_stock_doc_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_layers_move_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_layers_warehouse_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_layers_item_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_picks_move_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_picks_layer_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_minimums_warehouse_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_minimums_item_id
PASS Trade DB composite FK rejects foreign parent: fk_t_invoice_advances_invoice_id
PASS Trade DB composite FK rejects foreign parent: fk_t_invoice_advances_doc_id
PASS Periodic purchase posts purchases and maintains physical value without perpetual COGS
PASS Final invoice source prevents void and rolls back related settlement changes
PASS Cross-company invoice reads and wrong system-voucher source are rejected
PASS Invalid immediate settlement rolls back issued invoice, voucher and stock
PASS Changed tax requires draft review before issue instead of silently changing amount
PASS Issued print snapshot preserves party name without encrypted or plaintext identity
PASS Reversing original receipt after return refund restores full debt including cash refunded

RESULT: 226 passed; 0 failed; 0 skipped
Success: All selected tests executed.
```

### browser-trade-final.log

```text
PASS Render trade route trade_proforma
PASS Render trade route trade_sale_order
PASS Render trade route trade_sale
PASS Render trade route trade_sale_return
PASS Render trade route trade_purchase_request
PASS Render trade route trade_purchase_order
PASS Render trade route trade_purchase
PASS Render trade route trade_purchase_return
PASS Render trade route warehouses
PASS Render trade route stock_docs
PASS Render trade route inventory
PASS Render trade route trade_report
PASS Render trade route trade_aging
PASS Render trade route purchase_report
PASS Render trade route purchase_aging
PASS Persian sale draft persists through real POST and renders print document
PASS Invalid edit preserves Persian fields and correct kind without internal error
PASS Malformed line array returns safe validation and usable form
PASS Dynamic invoice rows add and remove without losing existing line
PASS Sale issue posts source voucher and immediately settles bank amount
PASS Replayed issue POST returns original result without issuing another invoice
PASS Invoice PDF prints A4 and A5 using local assets
PASS Linked sale return converts and issues from stored original prices
PASS Return then sale void reverse actual dependent effects
PASS Purchase draft freight allocation and issue run through real UI
PASS Proforma converts into sales order with no source voucher
PASS Warehouse transfer UI and kardex reflect destination movement
PASS Inventory CSV downloads actual balances and kardex is separate
PASS Trade CSV requires nonce and company-bound read access
PASS Foreign invoice GET is 404 before rendering data
PASS Foreign invoice POST with otherwise valid nonce is 404
PASS Missing CSRF nonce rejects invoice state mutation
PASS Viewer cannot open create invoice or inventory write form
PASS Invoice mobile layout is RTL and fits viewport
RESULT: 34 passed; 0 failed; 0 skipped
```

### concurrency-trade-final.log

```text
PASS simultaneous same commits exactly once
PASS simultaneous stock commits exactly once
PASS simultaneous return commits exactly once
PASS simultaneous advance commits exactly once
PASS competing sale preserves positive stock and ledger reconciliation
PASS advance consumed once and audit hash chain remains valid
PASS rollback leaves gap-free accounting numbers
RESULT: 7 passed; 0 failed; 0 skipped
```

### upgrade-preservation.log

```text
PASS upgrade preserves parties (8 rows)
PASS upgrade preserves units (8 rows)
PASS upgrade preserves item_groups (4 rows)
PASS upgrade preserves tax_rates (12 rows)
PASS upgrade preserves items (4 rows)
PASS upgrade preserves treasury_accounts (8 rows)
PASS upgrade preserves treasury_docs (28 rows)
PASS upgrade preserves treasury_doc_items (32 rows)
PASS upgrade preserves cheques (16 rows)
PASS upgrade preserves cheque_events (52 rows)
PASS upgrade preserves invoices (4 rows)
PASS upgrade preserves invoice_lines (4 rows)
PASS upgrade preserves settlements (8 rows)
PASS upgrade preserves bank_reconciliations (4 rows)
PASS upgrade preserves bank_reconciliation_items (8 rows)
PASS upgrade preserves companies (8 rows)
PASS upgrade preserves roles (50 rows)
PASS upgrade preserves role_caps (2772 rows)
PASS upgrade preserves company_members (14 rows)
PASS upgrade preserves settings (6 rows)
PASS upgrade preserves fiscal_years (8 rows)
PASS upgrade preserves fiscal_periods (96 rows)
PASS upgrade preserves accounts (698 rows)
PASS upgrade preserves details (22 rows)
PASS upgrade preserves vouchers (70 rows)
PASS upgrade preserves voucher_lines (142 rows)
PASS upgrade preserves sequences (18 rows)
PASS upgrade preserves audit_log (244 rows)
PASS upgrade preserves idempotency (2 rows)
PASS upgrade preserves auth_states (2 rows)
PASS upgrade preserves rate_limits (62 rows)
PASS upgrade preserves login_otp (2 rows)
PASS upgrade preserves audit_heads (9 rows)
PASS upgrade preserves schema_migrations (2 rows)
RESULT: 34 preserved tables; 0 failed
```
