<aside class="sidebar">
<?php
if(!defined('ABSPATH')) exit; if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
<?php else : ?>
	<section class="widget"><h3 class="widget-title">جستجو</h3><?php get_search_form(); ?></section>
	<section class="widget"><h3 class="widget-title">دسته‌ها</h3><ul><?php wp_list_categories( array( 'title_li' => '' ) ); ?></ul></section>
<?php endif; ?>
</aside>
