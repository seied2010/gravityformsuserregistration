<?php
if(!defined('ABSPATH')) exit; get_header(); ?>
<div class="shell section" style="text-align:center">
	<h1>صفحه پیدا نشد</h1>
	<p>نشانی را بررسی کنید یا از صفحهٔ اصلی ادامه دهید.</p>
	<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">بازگشت به صفحهٔ اصلی</a>
</div>
<?php get_footer(); ?>
