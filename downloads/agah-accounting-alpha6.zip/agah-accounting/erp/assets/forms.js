/* فرم‌های ERP: جلوگیری از ارسال دوباره، محاسبهٔ دقیق BigInt و تفصیلی وابسته؛ دادهٔ کاربر با innerHTML نوشته نمی‌شود. */
(function () {
    'use strict';
    const digits = s => String(s).replace(/[۰-۹]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/[٬,\s]/g,'').replace(/٫/g,'.');
    document.querySelectorAll('.erp form[method="post"]').forEach(form => {
        form.addEventListener('submit',e=>{
            if(form.dataset.submitting) { e.preventDefault();return; }
            form.dataset.submitting='1';
            form.querySelectorAll('button[type="submit"]').forEach(b=>{b.disabled=true;b.setAttribute('aria-busy','true');});
        });
    });
    document.querySelectorAll('[data-print]').forEach(b=>b.addEventListener('click',()=>window.print()));
    const form=document.querySelector('.erp-voucher-form');
    if(form) {
        const body=form.querySelector('[data-lines]');let next=body.children.length;
        const fmt=n=>new Intl.NumberFormat('fa-IR').format(n);
        const amount=s=>{
            s=digits(s||'0');if(!/^\d+(\.\d)?$/.test(s)) throw new Error('invalid');
            const [whole,frac='0']=s.split('.');
            if(form.dataset.unit==='toman') return BigInt(whole)*10n+BigInt(frac);
            if(frac!=='0') throw new Error('rial');return BigInt(whole);
        };
        const totals=()=>{
            let debit=0n,credit=0n;const output=form.querySelector('[data-totals]');
            try {
                body.querySelectorAll('[data-line]').forEach(r=>{debit+=amount(r.querySelector('[data-debit]').value);credit+=amount(r.querySelector('[data-credit]').value);});
                output.textContent='جمع بدهکار: '+fmt(debit)+' ریال | بستانکار: '+fmt(credit)+' ریال | اختلاف: '+fmt(debit-credit)+' ریال';
                output.classList.toggle('erp-err',debit!==credit);
            } catch(e) {output.textContent='مبلغ معتبر وارد کنید؛ جمع نهایی در سرور کنترل می‌شود.';output.classList.add('erp-err');}
        };
        const dependent=r=>{
            const a=r.querySelector('[data-account]'),d=r.querySelector('[data-detail]'),o=a.selectedOptions[0];
            const rule=o?.dataset.rule||'optional',kind=o?.dataset.kind||'';
            [...d.options].forEach(opt=>{opt.hidden=opt.value!=='0' && (rule==='none'||(kind && opt.dataset.kind!==kind));opt.disabled=opt.hidden;});
            if(d.selectedOptions[0]?.disabled) d.value='0';
            d.required=rule==='required';d.options[0].disabled=d.required;
        };
        const bind=r=>{
            const a=r.querySelector('[data-account]');a.addEventListener('change',()=>dependent(r));dependent(r);
            r.querySelector('[data-account-search]').addEventListener('input',e=>{
                const q=digits(e.target.value).toLocaleLowerCase();
                [...a.options].forEach(o=>{o.hidden=o.value!=='' && !digits(o.textContent).toLocaleLowerCase().includes(q);});
            });
            r.querySelector('[data-remove-line]').addEventListener('click',()=>{if(body.children.length>1) {r.remove();totals();}});
        };
        const add=()=>{
            if(body.children.length>=200) return;
            const template=document.querySelector('[data-line-template]');const r=template.content.firstElementChild.cloneNode(true);
            r.querySelectorAll('[name]').forEach(el=>{el.name=el.name.replace('__INDEX__',String(next));});next++;
            body.append(r);bind(r);r.querySelector('select').focus();totals();
        };
        body.querySelectorAll('[data-line]').forEach(bind);body.addEventListener('input',totals);
        form.querySelector('[data-add-line]').addEventListener('click',add);totals();
        form.addEventListener('keydown',e=>{if(e.altKey&&e.key.toLowerCase()==='n'){e.preventDefault();add();}if(e.altKey&&e.key.toLowerCase()==='s'){e.preventDefault();form.requestSubmit();}});
    }
    /* انتخابگر محلی شمسی با Intl تقویم ایرانی مرورگر؛ ذخیره و اعتبارسنجی قطعی در PHP/Jalali انجام می‌شود. */
    const calFmt=new Intl.DateTimeFormat('en-US-u-ca-persian',{year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});
    const parts=date=>{const p={};calFmt.formatToParts(date).forEach(x=>{if(x.type!=='literal')p[x.type]=Number(x.value);});return p;};
    const plus=(date,n)=>new Date(date.getTime()+n*86400000);
    function initCalendars(root=document){root.querySelectorAll('[data-jalali]').forEach(input=>{
        if(input.dataset.calendarReady)return;input.dataset.calendarReady='1';
        input.placeholder=input.placeholder||'۱۴۰۵/۰۱/۰۱';
        const trigger=document.createElement('button');trigger.type='button';trigger.className='btn btn-outline btn-sm erp-date-trigger';trigger.textContent='انتخاب تاریخ';trigger.setAttribute('aria-label','انتخاب تاریخ شمسی');
        input.insertAdjacentElement('afterend',trigger);
        trigger.addEventListener('click',()=>{
            document.querySelectorAll('.erp-calendar').forEach(x=>x.remove());
            const box=document.createElement('div');box.className='erp-calendar';box.setAttribute('role','dialog');box.setAttribute('aria-label','تقویم شمسی');
            trigger.insertAdjacentElement('afterend',box);
            let current=new Date();current=new Date(Date.UTC(current.getFullYear(),current.getMonth(),current.getDate()));
            const wanted=digits(input.value).match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
            if(wanted) {
                const approx=new Date(Date.UTC(Number(wanted[1])+621,Number(wanted[2])+1,20));
                for(let n=-65;n<65;n++){const candidate=plus(approx,n),p=parts(candidate);if(p.year===Number(wanted[1])&&p.month===Number(wanted[2])&&p.day===Number(wanted[3])){current=candidate;break;}}
            }
            const choose=date=>{const p=parts(date);input.value=p.year+'/'+String(p.month).padStart(2,'0')+'/'+String(p.day).padStart(2,'0');input.dispatchEvent(new Event('input',{bubbles:true}));box.remove();input.focus();};
            const button=(text,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=text;b.addEventListener('click',fn);return b;};
            const render=()=>{
                box.replaceChildren();const p=parts(current),first=plus(current,1-p.day),head=document.createElement('div');
                head.append(button('ماه قبل',()=>{current=plus(first,-1);render();}));
                const title=document.createElement('strong');title.textContent=new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'long',timeZone:'UTC'}).format(current);head.append(title);
                head.append(button('ماه بعد',()=>{current=plus(first,32);const np=parts(current);current=plus(current,1-np.day);render();}));box.append(head);
                const grid=document.createElement('div');grid.className='erp-calendar-grid';['ش','ی','د','س','چ','پ','ج'].forEach(t=>{const s=document.createElement('span');s.textContent=t;grid.append(s);});
                const offset=(first.getUTCDay()+1)%7;for(let i=0;i<offset;i++)grid.append(document.createElement('span'));
                for(let i=0;i<31;i++){const date=plus(first,i),v=parts(date);if(v.month!==p.month)break;const b=button(new Intl.NumberFormat('fa-IR').format(v.day),()=>choose(date));b.setAttribute('aria-label',v.year+'/'+v.month+'/'+v.day);grid.append(b);}
                box.append(grid,button('امروز',()=>choose(new Date())),button('بستن',()=>{box.remove();trigger.focus();}));
            };
            box.addEventListener('keydown',e=>{if(e.key==='Escape'){box.remove();trigger.focus();}});render();box.querySelector('button').focus();
        });
    });}
    window.agahInitCalendars=initCalendars;initCalendars();
}());
