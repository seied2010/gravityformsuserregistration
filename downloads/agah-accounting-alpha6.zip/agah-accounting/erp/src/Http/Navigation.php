<?php
/** منوی دسته‌بندی‌شده با مجوز هر صفحه؛ چیدمان سراسری فقط از تنظیم مجاز سفارشی‌ساز سایت خوانده می‌شود. */
namespace Agah\Erp\Http;
use Agah\Erp\Core\Ctx;
use Agah\Erp\Security\Caps;
if(!defined('ABSPATH'))exit;
final class Navigation {
    public static function mode(){return get_theme_mod('agah_erp_menu_layout','top')==='sidebar'?'sidebar':'top';}
    public static function render(array $nav,$current,$cid){
        $labels=['general'=>'عمومی','company'=>'شرکت و دسترسی','accounting'=>'حسابداری','party'=>'اشخاص','catalog'=>'کالا و مالیات','inventory'=>'انبار','sales'=>'فروش','purchase'=>'خرید','treasury'=>'خزانه','expense'=>'هزینه و درآمد','payroll'=>'حقوق و دستمزد','assets'=>'دارایی ثابت','report'=>'گزارش‌ها'];$groups=[];$resources=Caps::resources();
        foreach($nav as $key=>$data){if(!Ctx::can($data[1]))continue;$resource=explode('.',$data[1])[0];$group=$resources[$resource][1]??'general';$groups[$group][$key]=$data[0];}
        echo '<details class="erp-navigation erp-no-print" open><summary>بخش‌های سامانه</summary><nav class="erp-nav" aria-label="منوی سامانه">';
        foreach($labels as $group=>$label)if(isset($groups[$group])){echo '<section class="erp-nav-group"><h3>'.esc_html($label).'</h3>';foreach($groups[$group] as $key=>$text)echo '<a href="'.esc_url(agah_erp_url(['c'=>$cid,'p'=>$key])).'"'.($key===$current?' class="on" aria-current="page"':'').'>'.esc_html($text).'</a>';echo '</section>';}
        echo '</nav></details>';
    }
}
