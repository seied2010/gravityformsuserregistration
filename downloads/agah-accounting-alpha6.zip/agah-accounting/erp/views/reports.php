<?php
/** دفاتر و تراز واقعی با ماندهٔ اول، جمع بازه و ماندهٔ نهایی؛ چاپ و خروجی همان فیلتر را دارند. */
namespace Agah\Erp\Http;
use Agah\Erp\Core\{Db,Ctx,Request,Money,Jalali,Crypto,Audit,Settings};
use Agah\Erp\Modules\Accounting\{AccountService,DetailService,FiscalService,VoucherService,ReportService,ChartSeed};
use Agah\Erp\Modules\Company\{CompanyService,MemberService};
if(!defined('ABSPATH')) exit;
$f=self::filters();$r=ReportService::ledger($cid,$f,Request::int('get','pg',1));
$accounts=Db::rows('SELECT id,code,name FROM '.Db::t('accounts').' WHERE company_id=%d ORDER BY code',$cid);
$details=Db::rows('SELECT id,code,name FROM '.Db::t('details').' WHERE company_id=%d ORDER BY code',$cid);
$summary=in_array($f['mode'],['general','subsidiary','trial2','trial4'],true);$trial2=$f['mode']==='trial2';
?>
<section class="erp-card erp-print-document"><h2><?php echo esc_html(Ctx::company()['name'].' — '.ReportService::MODES[$f['mode']]); ?></h2>
<p>فقط اسناد تأییدشده و قطعی؛ واحد نمایش: <?php echo Ctx::unit()==='rial'?'ریال':'تومان'; ?>. فایل‌های خروجی همواره به ریال هستند.</p>
<form method="get" action="<?php echo esc_url(agah_erp_url()); ?>" class="erp-filter erp-no-print"><input type="hidden" name="page_id" value="<?php echo (int)get_option('agah_erp_page_id'); ?>"><input type="hidden" name="c" value="<?php echo (int)$cid; ?>"><input type="hidden" name="p" value="reports">
<label>گزارش<select name="mode"><?php foreach(ReportService::MODES as $k=>$label): ?><option value="<?php echo esc_attr($k); ?>" <?php selected($k,$f['mode']); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
<?php foreach(['from'=>'از تاریخ شمسی','to'=>'تا تاریخ شمسی'] as $k=>$label): ?><label><?php echo esc_html($label); ?><input name="<?php echo esc_attr($k); ?>" value="<?php echo esc_attr(Request::str('get',$k,10)); ?>" placeholder="۱۴۰۵/۰۱/۰۱" dir="ltr" data-jalali></label><?php endforeach; ?>
<label>حساب و زیرمجموعه<select name="account_id"><option value="0">همه</option><?php foreach($accounts as $a): ?><option value="<?php echo (int)$a['id']; ?>" <?php selected($f['account_id'],$a['id']); ?>><?php echo esc_html($a['code'].' — '.$a['name']); ?></option><?php endforeach; ?></select></label>
<label>تفصیلی<select name="detail_id"><option value="0">همه</option><?php foreach($details as $d): ?><option value="<?php echo (int)$d['id']; ?>" <?php selected($f['detail_id'],$d['id']); ?>><?php echo esc_html($d['code'].' — '.$d['name']); ?></option><?php endforeach; ?></select></label><button class="btn btn-primary" type="submit">تهیهٔ گزارش</button></form>
<p>بازه: <?php echo esc_html(($r['from']?Jalali::format($r['from']):'از ابتدا').' تا '.($r['to']?Jalali::format($r['to']):'آخرین ثبت')); ?> | مانده پیش از بازه: <?php echo esc_html(Money::fmt($r['opening'],Ctx::unit())); ?></p>
<div class="erp-scroll"><table class="erp-table"><thead><tr>
<?php if(!$summary): ?><th>تاریخ</th><th>شماره سند</th><?php endif; ?><th>کد</th><th>حساب</th><?php if(!$summary): ?><th>تفصیلی</th><th>شرح</th><?php elseif(!$trial2 && $f['mode']!=='trial4'): ?><th>مانده اول</th><?php endif; ?>
<?php if(!$trial2): ?><th>بدهکار بازه</th><th>بستانکار بازه</th><?php endif; ?>
<?php if($summary): ?><th>مانده بدهکار</th><th>مانده بستانکار</th><?php else: ?><th>مانده تجمعی</th><?php endif; ?></tr></thead><tbody>
<?php foreach($r['rows'] as $row): ?><tr>
<?php if(!$summary): ?><td><?php echo esc_html(Jalali::format($row['voucher_date'])); ?></td><td><a href="<?php echo esc_url(agah_erp_url(['c'=>$cid,'p'=>'voucher_view','id'=>$row['voucher_id']])); ?>"><?php echo esc_html(Money::toFa($row['number'])); ?></a></td><?php endif; ?>
<td><?php echo esc_html(Money::toFa($row['code'])); ?></td><td><?php echo esc_html($row['name']); ?></td>
<?php if(!$summary): ?><td><?php echo esc_html($row['detail_name']?:'—'); ?></td><td><?php echo esc_html($row['description']); ?></td><?php elseif(!$trial2 && $f['mode']!=='trial4'): ?><td><?php echo esc_html(Money::fmt($row['opening'],Ctx::unit())); ?></td><?php endif; ?>
<?php if(!$trial2): ?><td><?php echo esc_html(Money::fmt($row['debit'],Ctx::unit())); ?></td><td><?php echo esc_html(Money::fmt($row['credit'],Ctx::unit())); ?></td><?php endif; ?>
<?php if($summary): ?><td><?php echo esc_html(Money::fmt($row['balance_debit'],Ctx::unit())); ?></td><td><?php echo esc_html(Money::fmt($row['balance_credit'],Ctx::unit())); ?></td><?php else: ?><td><?php echo esc_html(Money::fmt($row['balance'],Ctx::unit())); ?></td><?php endif; ?></tr><?php endforeach; ?>
<?php if(!$r['rows']): ?><tr><td colspan="9">گردشی برای فیلتر انتخاب‌شده وجود ندارد.</td></tr><?php endif; ?></tbody></table></div>
<div class="erp-summary"><p>جمع بدهکار بازه: <?php echo esc_html(Money::fmt($r['total']['debit'],Ctx::unit())); ?></p><p>جمع بستانکار بازه: <?php echo esc_html(Money::fmt($r['total']['credit'],Ctx::unit())); ?></p><p>مانده نهایی با احتساب اول دوره: <?php echo esc_html(Money::fmt($r['closing'],Ctx::unit())); ?></p></div>
<?php if(!$f['account_id'] && !$f['detail_id']): ?><p class="<?php echo $r['closing']===0?'erp-ok':'erp-err'; ?>"><?php echo $r['closing']===0?'تراز اسناد متوازن است.':'هشدار: اختلاف تراز اسناد وجود دارد.'; ?></p><?php endif; ?>
<?php self::pages($r['pages'],$r['page']); ?>
<div class="erp-no-print"><button type="button" class="btn btn-outline" data-print>چاپ همین صفحه / ذخیره PDF</button>
<?php if(Ctx::can('report.export')): foreach(['csv'=>'CSV تمام ردیف‌ها','excel'=>'Excel XML تمام ردیف‌ها'] as $format=>$label): ?><a class="btn btn-outline" href="<?php echo esc_url(add_query_arg(['export'=>$format,'_n'=>wp_create_nonce('agah_report_export_'.$cid),'pg'=>false])); ?>"><?php echo esc_html($label); ?></a><?php endforeach; endif; ?>
<p>چاپ مربوط به صفحهٔ جاری است؛ خروجی CSV و Excel شامل تمام صفحات است.</p></div></section>
