<?php
/** تنظیمات شرکت جاری؛ شناسهٔ ملی فقط پوشیده و تغییر آن با ورودی تازه انجام می‌شود. */
namespace Agah\Erp\Http;
use Agah\Erp\Core\{Db,Ctx,Request,Money,Jalali,Crypto,Audit,Settings};
use Agah\Erp\Modules\Accounting\{AccountService,DetailService,FiscalService,VoucherService,ReportService,ChartSeed};
use Agah\Erp\Modules\Company\{CompanyService,MemberService};
if(!defined('ABSPATH')) exit;
$co=Ctx::company();$edit=Ctx::can('company_settings.edit');
?>
<section class="erp-card"><h2>مشخصات و تنظیمات شرکت</h2>
<p>شناسهٔ ذخیره‌شده: <span dir="ltr"><?php echo esc_html(Crypto::hint(Crypto::decrypt($co['national_id_enc']))?:'ثبت نشده'); ?></span></p>
<?php if($edit): ?><form method="post" class="erp-form"><?php self::form('module_company_save',$cid,'settings'); ?>
<?php
self::input('name','نام شرکت',$co['name'],'text','required maxlength="190"');
self::input('legal_name','نام حقوقی',$co['legal_name'],'text','maxlength="190"');
self::select('kind','نوع شرکت',['real'=>'حقیقی','legal'=>'حقوقی'],$co['kind']);
self::select('display_unit','واحد نمایش',['rial'=>'ریال','toman'=>'تومان'],$co['display_unit']);
self::input('national_id','شناسهٔ ملی جدید (خالی = حفظ قبلی)','','text','inputmode="numeric" maxlength="11" autocomplete="off"');
foreach(['economic_code'=>'شماره اقتصادی','registration_no'=>'شماره ثبت','phone'=>'تلفن','address'=>'نشانی','postal_code'=>'کد پستی'] as $key=>$label) self::input($key,$label,$co[$key],'text','maxlength="'.($key==='address'?500:40).'"');
self::input('default_due_days','مهلت پیش‌فرض سررسید (روز)',Settings::get('default_due_days',$cid),'number','min="0" max="3650" required');
self::input('voucher_prefix','پیشوند نمایشی شماره سند',Settings::get('voucher_prefix',$cid),'text','maxlength="20"');
self::input('invoice_prefix','پیشوند نمایشی شماره فاکتور',Settings::get('invoice_prefix',$cid),'text','maxlength="20"');
?>
<p class="muted">پیشوند روی شمارهٔ اصلی و ترتیب بدون فاصله اثر ندارد. فاکتورها و صورت‌های مالی از منوی سامانه در دسترس‌اند.</p>
<label><input type="checkbox" name="clear_national_id" value="1"> حذف شناسهٔ ملی ذخیره‌شده</label>
<label><input type="checkbox" name="require_2fa" value="1" <?php checked(self::value('require_2fa',Settings::get('require_2fa',$cid)),'1'); ?>> الزام تأیید دومرحله‌ای برای ورود اعضا به این شرکت</label>
<label><input type="checkbox" name="persian_digits" value="1" <?php checked(self::value('persian_digits',Settings::get('persian_digits',$cid)),'1'); ?>> نمایش ارقام فارسی</label>
<button type="submit" class="btn btn-primary">ذخیرهٔ تنظیمات</button></form>
<?php else: ?><dl><?php foreach(['name'=>'نام','legal_name'=>'نام حقوقی','phone'=>'تلفن','address'=>'نشانی','economic_code'=>'شماره اقتصادی'] as $key=>$label): ?><dt><?php echo esc_html($label); ?></dt><dd><?php echo esc_html($co[$key]?:'—'); ?></dd><?php endforeach; ?></dl><?php endif; ?>
</section>

<?php if(current_user_can('edit_theme_options')): ?><p class="erp-no-print"><a href="<?php echo esc_url(admin_url('customize.php?autofocus[section]=agah_erp_navigation')); ?>">انتخاب منوی بالا یا کناری در سفارشی‌ساز سایت</a></p><?php endif; ?>
