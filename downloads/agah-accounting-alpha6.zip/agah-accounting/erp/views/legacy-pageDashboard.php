<?php
/** نمای جداشدهٔ pageDashboard؛ زمینه و مجوز در Page بررسی می‌شوند. */
namespace Agah\Erp\Http;
use Agah\Erp\Core\{Db,Ctx,Request,Money,Jalali,Crypto,Audit,Settings};
use Agah\Erp\Modules\Accounting\{AccountService,DetailService,FiscalService,VoucherService,ReportService,ChartSeed};
use Agah\Erp\Modules\Company\{CompanyService,MemberService};
if(!defined('ABSPATH')) exit;
		$fy   = Db::row( 'SELECT * FROM ' . Db::t( 'fiscal_years' ) . ' WHERE company_id = %d ORDER BY start_date DESC LIMIT 1', $cid );
		$accN = (int) Db::val( 'SELECT COUNT(*) FROM ' . Db::t( 'accounts' ) . ' WHERE company_id = %d AND level = 3', $cid );
		echo '<div class="erp-grid">';
		echo '<div class="erp-card"><h3>سال مالی</h3><p class="big">' . esc_html( $fy ? $fy['title'] : '—' ) . '</p><p class="muted">' . esc_html( $fy ? Jalali::format( $fy['start_date'] ) . ' تا ' . Jalali::format( $fy['end_date'] ) : '' ) . '</p></div>';
		echo '<div class="erp-card"><h3>حساب‌های معین</h3><p class="big">' . esc_html( self::fa( $accN ) ) . '</p></div>';
		echo '<div class="erp-card"><h3>واحد پول</h3><p class="big">' . esc_html( 'rial' === Ctx::unit() ? 'ریال' : 'تومان' ) . '</p></div>';
		echo '</div>';
		echo '<div class="erp-card"><p>اسناد و دفاتر حسابداری فعال‌اند. اشخاص، فاکتور، خزانه و انبار در مراحل بعد تکمیل می‌شوند. این نسخهٔ آزمایشی پیش از استفادهٔ عملیاتی نیازمند بازبینی است.</p></div>';
