<?php
/** نمای مراحل۱۰–۱۲؛ داده واقعی از سرویس، فرم با PRG مشترک، خروجی escape و فونت محلی است. */
namespace Agah\Erp\Http;
use Agah\Erp\Core\{Business,Ctx,Db,Jalali,Money,Request,Settings};
use Agah\Erp\Modules\Expenses\ExpenseService;
use Agah\Erp\Modules\Accounting\{FinancialService,ClosingService,FiscalService};
use Agah\Erp\Modules\Dashboard\DashboardService;
if(!defined('ABSPATH'))exit;
[, $to]=FinanceController::dates();$data=FinancialService::parties($cid,$to,Request::int('get','pg',1));
?>
<section class="erp-card"><h2>بدهکاران و بستانکاران تجاری</h2><form method="get" class="erp-filter"><input type="hidden" name="page_id" value="<?php echo (int)get_option('agah_erp_page_id'); ?>"><input type="hidden" name="c" value="<?php echo $cid; ?>"><input type="hidden" name="p" value="financial_parties"><label>تا تاریخ شمسی<input name="to" value="<?php echo esc_attr(Jalali::format($to,false)); ?>" data-jalali></label><button type="submit" class="btn btn-outline">محاسبه</button></form><?php FinanceController::exportLink($cid,'parties'); ?><div class="erp-scroll"><table class="erp-table"><thead><tr><th>کد / شخص</th><th>دریافتنی (شامل اسناد)</th><th>پرداختنی (شامل اسناد)</th></tr></thead><tbody><?php foreach($data['rows'] as $r): ?><tr><td><?php echo esc_html($r['code'].' — '.$r['name']); ?></td><td><?php echo esc_html(Money::fmt((int)$r['receivable'],Ctx::unit())); ?></td><td><?php echo esc_html(Money::fmt((int)$r['payable'],Ctx::unit())); ?></td></tr><?php endforeach; ?></tbody></table></div><?php self::pages($data['pages'],$data['page']); ?></section>
