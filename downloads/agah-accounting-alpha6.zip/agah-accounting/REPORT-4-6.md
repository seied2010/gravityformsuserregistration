# گزارش تحویل مراحل ۴ تا ۶ — حسابداری آگاه 3.0.0-alpha3

تاریخ: ۱۴۰۵/۰۷/۲۷. مبنا: نسخهٔ alpha2 و گزارش تحویل ۱–۳؛ آن گزارش دست‌نخورده به‌عنوان سابقه باقی است. این تحویل **مراحل ۴، ۵ و ۶** را پوشش می‌دهد. برای گفتگوی تازه از HANDOFF-NEXT.md شروع کنید؛ نیازی به خواندن کل تاریخچه یا پیوست لاگ‌ها مگر برای خطایابی نیست.

## ۱. نتیجهٔ قابل بازبینی

- **اشخاص:** ایجاد/ویرایش/حذف بدون گردش و غیرفعال‌سازی، نقش مشتری/تأمین‌کننده، کد خودکار، تفصیلی همگام، اعتبارسنجی رقم کنترلی ۱۰/۱۱رقمی، رمزنگاری+ایندکس کور+نمایش پوشیدهٔ شناسه. افشای کامل فقط با مجوز مستقل، nonce، سقف درخواست و ممیزی؛ نه در URL/CSV/transient. صورت‌حساب از دفتر واقعی است؛ هشدار سقف اعتبار فقط بر دریافتنی و اسناد دریافتنی است و بدهی به همان شخص از سقف کسر نمی‌شود.
- **کالا/خدمت:** واحد و گروه، کد/بارکد، قیمت صحیح ریال، حساب‌های معین و نرخ انتخابی. نرخ اولیه NULL و تأییدنشده است؛ بازهٔ نرخ هم‌کد نباید هم‌پوشان باشد. تأیید نرخ مجوز مستقل دارد. قرارداد taxSnapshot، نرخ/نام/مبلغ خط را ثابت ذخیره می‌کند؛ تغییر نرخ روی snapshot قبلی اثر ندارد.
- **خزانه:** بانک/صندوق/تنخواه با تفصیلی مستقل؛ دریافت/پرداخت/انتقال چندقلمی با سند خودکار، شماره، ممیزی و تخصیص اتمیک. صندوقدار برای برگهٔ مجاز، مجوز عمومی سند دستی نمی‌گیرد. چک در جریان/وصول/برگشت/ابطال با نسخه و تاریخ و سند رویداد کنترل می‌شود. برگشت چک فقط تخصیص همان قلم را آزاد می‌کند. ابطال برگه، همهٔ اسناد رویداد و اصل برگه و تسویه‌ها را برمی‌گرداند یا یکجا شکست می‌خورد.
- **گزارش/رابط:** فهرست‌های صفحه‌بندی‌شده، فرم‌های واقعی فارسی/RTL، ردیف پویا، تقویم محلی، خطای سرور و حفظ ورودی امن؛ دفتر بانک از خطوط حسابداری، مغایرت‌گیری با انتخاب سطر واقعی و اختلاف بازحساب‌شده، پیش‌بینی بر پایهٔ چک و ماندهٔ فاکتور واقعی. CSV تمام صفحات با محافظت فرمول و بدون شناسهٔ کامل؛ چاپ مرورگر و نمایش موبایل.

## ۲. تصمیم‌های معماری و وابستگی‌ها

Schema 4 شامل **۳۴ جدول** است: ۱۹ جدول قبلی + ۱۵ جدول تجاری. تمام جداول جدید UUID/زمان/کلید یکتای company_id,id و FKهای تجاری مرکب دارند. BusinessSchema از Schema اصلی فراخوانی می‌شود؛ مهاجرت افزایشی است. همهٔ عملیات مالی زیر قفل شرکت، Access، تراکنش، شماره و ممیزی هستند و از کنترلر مشترک Idempotency/PRG استفاده می‌کنند.

برای جلوگیری از اجرای بی‌قاعدهٔ سند خودکار، منبع treasury_receipt/payment/transfer به مجوز create/delete همان برگه و cheque_event به cheque.approve متصل است؛ وجود مبدأ هم‌شرکت بررسی می‌شود. سایر منابع هنوز مجوز voucher.create/void می‌خواهند و مرحلهٔ فروش/خرید باید نگاشت خود را با کنترل مبدأ توسعه دهد.

**قرارداد invoices/invoice_lines در این مرحله زودتر تعریف شده تا تسویه قابل‌آزمون باشد؛ UI صدور فاکتور هنوز متعلق به مراحل ۷ و ۸ است.** fixture آزمایشی، فاکتور دارای سند مبدأ واقعی می‌سازد؛ نصب عادی هیچ فاکتور یا رقم نمونه نمی‌سازد. جزئیات دقیق در docs/CONTRACTS-4-6.md آمده است.

## ۳. آزمون و شاهد

محیط: WordPress 7.1.3، PHP 8.2.34، MariaDB 11.4.13، Playwright 1.62.1 و Chromium. آزمون‌ها روی سایت‌های دورریختنی مستقل بودند؛ هیچ دادهٔ عملیاتی در ZIP نیست.

| آزمون | اجرا | نتیجهٔ واقعی |
|---|---|---|
| واحد/یکپارچگی/مجوز، شامل گروه قبلی | `wp eval-file .../tests/run.php` | **۱۶۹ pass، صفر fail/skip** |
| FK مرکب هر رابطهٔ جدید | زیرگروه آزمون PHP؛ UPDATE والد بیگانه و بررسی خطای واقعی FK | تمام روابط مرکب تعریف‌شده، با fixture پرشده بررسی شدند؛ داخل عدد ۱۶۹ |
| هم‌زمانی زیرساخت قبلی | `python3 tests/integration/concurrency.py` | ۷ pass |
| رقابت تسویه/وصول/شناسه | `python3 tests/integration/business-concurrency.py` | ۵ pass؛ هر رقابت دقیقاً یک commit، مانده و شماره و ممیزی درست |
| مرورگر قبلی | browser.cjs | ۴۳ pass |
| مرورگر مراحل جدید | business-browser.cjs | ۲۸ pass؛ ثبت واقعی، افشای مجاز، نرخ، کالا، برگه/چک/تطبیق/CSV/IDOR/موبایل |
| smoke قبلی | smoke.php در run-all | ۲۷ pass |
| اجرای یک‌دستوری | `bash tests/run-all.sh` | همهٔ گروه‌ها اجرا و exit 0 |
| نصب روی WordPress مستقل | ZIP نصب/فعال و صفحهٔ HTTP واقعی ورود | موفق؛ ۱۶۹ آزمون PHP روی آن نیز pass |
| ارتقای alpha2→alpha3 | capture روی Schema 3، نصب ZIP، verify روی Schema 4 | ۱۹ جدول قبلی بررسی؛ همهٔ ردیف‌های قبلی حفظ شدند |
| نحو PHP | find + xargs php -l | ۹۶ فایل، بدون خطای نحوی |
| نحو JS | node --check فرم‌ها و commerce.js | exit 0 |
| پیامک/ایمیل واقعی، بار بزرگ، افزونه‌های ثالث و حسابرسی مستقل مالی | بستر/خدمت فراهم نشده یا خارج از این تحویل | **اجرا نشد** |

در migration فقط افزودن ردیف نسخهٔ ۴ به رجیستری و مجوزهای جدید برای نقش company_admin به‌عنوان تغییر مورد انتظار پذیرفته شد؛ ردیف‌های قبلی حذف/بازنویسی نشدند. تعداد اجراهای تکراری روی سایت تمیز به‌عنوان تست یکتای جدید جمع نشده است. لاگ کامل در docs/test-results/phase-4-6 است.

## ۴. نصب و ارتقا

از فایل‌ها، DB و کلید رمزنگاری backup بگیرید؛ ابتدا staging. ZIP پوسته با همان پوشهٔ agah-accounting نصب/جایگزین شود. Schema 3→4 خودکار و افزایشی است و ۱۵ جدول، کلید مرکب سطر سند و دادهٔ پایهٔ واحد/نرخ نامشخص را می‌سازد. اطلاعات شخص/سند/تنظیمات قبلی حفظ می‌شود؛ کلید قبلی را برای ارتقا عوض نکنید. راهنمای کامل در docs/INSTALL.md؛ downgrade خودکار نیست.

## ۵. محدودیت و باقی‌مانده

مراحل **۷ تا ۱۸** باقی‌اند؛ بستهٔ بعدی فروش/خرید/انبار است. نه UI صدور فاکتور و نه انبار یا صورت‌های مالی نهایی ادعا نمی‌شود. قرارداد اولیهٔ فاکتور باید در مرحلهٔ بعد با تخفیف/برگشت/stock و کنترل منبع تکمیل شود. پیش‌دریافت/پیش‌پرداخت فعلاً مستقل است و به فاکتور اعمال نمی‌شود؛ پیش‌بینی نیز آن را خودکار از مطالبات کسر نمی‌کند.

مغایرت‌گیری زنده است و دفتر را قطعی/غیرقابل‌تغییر نمی‌کند. برگشت returned→void صرفاً اداری است؛ برای آن سند صفر/ساختگی ساخته نشده است. گذار مالی روی حساب/تفصیلی غیرفعال نیاز به فعال‌سازی مجاز دارد. ماندهٔ منفی خزانه ممنوع نشده؛ سیاست اعتبار بانکی/صندوق در استقرار بازبینی شود. قفل شرکت throughput را محدود می‌کند و بار عملیاتی آزموده نیست.

امنیت کامل و آمادگی بهره‌برداری مالی نهایی ادعا نمی‌شود. HTTPS، کلید اختصاصی، cache exclusion و مجوز محدود DB همچنان ضروری‌اند. پیامک واقعی انتخاب نشده و ایمیل واقعی تنظیم نیست. Excel XML و PDF چاپ مرورگرِ بستهٔ قبل به قوت خود است. این پروژه به مخزن Gravity Forms محیط وابسته نیست و آن مخزن تغییر نکرده است.

## ۶. فایل‌های تغییرکرده/جدید

| مسیر | وضعیت | کار |
|---|---|---|
| `CHANGELOG.md` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `HANDOFF-NEXT.md` | جدید | خلاصهٔ قابل‌انتقال به گفتگوی تازه برای مصرف کمتر زمینه. |
| `README.md` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `REPORT-4-6.md` | جدید | سازگاری، نسخه یا مستندات تحویل جدید. |
| `docs/ARCHITECTURE.md` | تغییر | مستندات به‌روز، قرارداد داده یا نقشهٔ فایل. |
| `docs/CONTRACTS-4-6.md` | جدید | مستندات به‌روز، قرارداد داده یا نقشهٔ فایل. |
| `docs/DB-SCHEMA.md` | تغییر | مستندات به‌روز، قرارداد داده یا نقشهٔ فایل. |
| `docs/FILE-MAP.md` | تغییر | مستندات به‌روز، قرارداد داده یا نقشهٔ فایل. |
| `docs/INSTALL.md` | تغییر | مستندات به‌روز، قرارداد داده یا نقشهٔ فایل. |
| `docs/ROADMAP.md` | تغییر | مستندات به‌روز، قرارداد داده یا نقشهٔ فایل. |
| `docs/SECURITY.md` | تغییر | مستندات به‌روز، قرارداد داده یا نقشهٔ فایل. |
| `docs/TESTING.md` | تغییر | مستندات به‌روز، قرارداد داده یا نقشهٔ فایل. |
| `docs/test-results/phase-4-6/browser-base-final.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/browser-business-final.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/clean-final-install.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/clean-install.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/clean-integration.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/concurrency-base-final.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/concurrency-business-final.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/integration-final.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/migration-final.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/migration.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/php-lint.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/run-all.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `docs/test-results/phase-4-6/upgrade.log` | جدید | شاهد خام آزمون این تحویل؛ بدون credential. |
| `erp/assets/commerce.js` | جدید | ردیف‌های واقعی اقلام/تخصیص بدون innerHTML. |
| `erp/assets/forms.js` | تغییر | راه‌اندازی تقویم شمسی روی ردیف‌های پویا. |
| `erp/bootstrap.php` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `erp/src/Core/Business.php` | جدید | اعتبارسنجی دامنه و CRUD/صفحه‌بندی مشترک. |
| `erp/src/Core/BusinessSchema.php` | جدید | DDL و FK مرکب ۱۵ جدول جدید و seed دادهٔ پایهٔ نامشخص. |
| `erp/src/Core/Schema.php` | تغییر | مهاجرت افزایشی ۳→۴ و کلید مرکب voucher_lines. |
| `erp/src/Http/CommerceController.php` | جدید | آداپتور ورودی و خروجی CSV برای مراحل ۴–۶. |
| `erp/src/Http/ModuleController.php` | تغییر | اتصال به PRG/nonce/مجوز/idempotency مشترک. |
| `erp/src/Modules/Accounting/VoucherService.php` | تغییر | مجوز سند خودکار وابسته به منبع واقعی خزانه/چک. |
| `erp/src/Modules/Catalog/CatalogService.php` | جدید | واحد/گروه/کالا/نرخ زمانی و snapshot مالیات. |
| `erp/src/Modules/Company/CompanyService.php` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `erp/src/Modules/Parties/PartyService.php` | جدید | شخص/تفصیلی اتمیک، شناسهٔ رمز‌شده، افشای ممیزی‌شده و کنترل اعتبار. |
| `erp/src/Modules/Treasury/TreasuryService.php` | جدید | حساب خزانه، برگه، چک، تخصیص، ابطال، دفتر، تطبیق و پیش‌بینی. |
| `erp/src/Security/Caps.php` | تغییر | مجوز مستقل شناسهٔ حساس و تأیید نرخ مالیات. |
| `erp/views/business-cash.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-catalog.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-cheques.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-docs.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-parties.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-party.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-reconciliation.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-treasury-accounts.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-treasury-document.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-treasury-form.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/business-treasury-row.php` | جدید | نمای عملیاتی و escapeشدهٔ ماژول جدید با فرم/مجوز واقعی. |
| `erp/views/legacy-viewCompany.php` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `erp/views/roles.php` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `erp/views/voucher-view.php` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `functions.php` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `readme.txt` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `style.css` | تغییر | سازگاری، نسخه یا مستندات تحویل جدید. |
| `tests/integration/business-concurrency-setup.php` | جدید | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |
| `tests/integration/business-concurrency-worker.php` | جدید | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |
| `tests/integration/business-concurrency.py` | جدید | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |
| `tests/integration/business.php` | جدید | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |
| `tests/integration/core.php` | تغییر | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |
| `tests/migration.php` | تغییر | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |
| `tests/run-all.sh` | تغییر | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |
| `tests/run.php` | تغییر | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |
| `tests/security/business-browser.cjs` | جدید | آزمون واقعی یا ابزار بازتولید؛ فقط سایت دورریختنی. |

## ۷. خروجی خام اجرا (برای خطایابی؛ در گفتگوی تازه خواندن کامل آن لازم نیست)

### integration-final.log

```text
PASS RFC6238 SHA1 timestamp 59
PASS RFC6238 SHA1 timestamp 1111111109
PASS RFC6238 SHA1 timestamp 1111111111
PASS RFC6238 SHA1 timestamp 1234567890
PASS RFC6238 SHA1 timestamp 2000000000
PASS RFC6238 SHA1 timestamp 20000000000
PASS TOTP wrong format rejected
PASS TOTP current/adjacent steps and expiry
PASS Base32 random key uses 32 valid symbols
PASS Password short/no letter/no number rejected
PASS Money accepts Persian digits and exact toman fraction
PASS Money overflow and fractions rejected
PASS Encryption authentication detects tampering
PASS Jalali leap day and roundtrip
PASS Upgrade preserves baseline rows and installs business tables
PASS Schema upgrade repeatability preserves rows
PASS Idempotency claim complete and replay result
PASS Token payload substitution and company/user tampering rejected
PASS Token rollback releases claim and domain change
PASS Unsigned and expired form token rejected
PASS Idempotency requires transaction
PASS Rate limit exact cap and window expiry
PASS Login errors identical for invalid username/password
PASS Login IP+user throttle also covers email alias
PASS Login IP aggregate throttles many distinct usernames
PASS New session has no second factor marker
PASS Idle session destroys only expired token
PASS TOTP enrollment requires correct password
PASS Pending secret encrypted and bound to session
PASS Enable verifies first code and creates eight hashed backup codes
PASS TOTP initial code replay is rejected
PASS TOTP next step accepted once; replay rejected
PASS Backup code is consumed exactly once
PASS Other WP session cannot inherit verified factor
PASS Require2fa company policy applied
PASS TOTP brute force bounded
PASS TOTP disable requires password and invalidates marker
PASS SMS disabled without selected provider
PASS SMS code stored hashed and bound to session; one-time use
PASS SMS expires after two minutes
PASS SMS five failed attempts block correct code
PASS SMS hourly send cap enforced
PASS Cannot remove/downgrade last active company admin
PASS Member existing user added with scoped role
PASS Custom role matrix saves exact caps and audits
PASS System role editing/deleting rejected
PASS Removed member history retained; no WordPress user deleted
PASS Company edits encrypt national identifier and preserve metadata
PASS Detail create/update/read persists
PASS Duplicate detail code rejected
PASS Unused custom account structure can update
PASS Balanced draft saved without number and excluded from ledger
PASS Draft imbalance allowed; approval rejected
PASS Both debit and credit in one line rejected
PASS Non-leaf and incompatible details rejected
PASS Float money rejected and no partial voucher persists
PASS Approval allocates number and journals balance
PASS Approved voucher cannot become unbalanced by edit
PASS Optimistic revision rejects stale edit
PASS Finalize locks contents and physical deletion
PASS Reopen requires reason and keeps number
PASS Detail with turnover cannot delete
PASS Void retains number and excludes journal
PASS System post creates approved source-linked voucher
PASS System duplicate source/manual edit/void rejected
PASS System void returns effect from journal
PASS Account ledger opening and cumulative closing from real entries
PASS Trial balance two/four columns and general/subsidiary all balance
PASS Ledger pagination carries previous page running balance
PASS Closed period blocks create and edit of existing voucher
PASS Year with draft cannot close; no-draft closes and reopens
PASS Approval rechecks account activation after draft creation
PASS Audit intact after all operations; national id masked
PASS Foreign company context always NotFound
PASS Foreign account line rejected before DB mutation
PASS Company-scoped detail/report/member IDOR rejected
PASS Voucher foreign id get/edit/state/delete all NotFound
PASS Service company argument cannot override current context
PASS Viewer server denies company_settings.edit
PASS Viewer server denies member.create
PASS Viewer server denies member.edit
PASS Viewer server denies role.edit
PASS Viewer server denies detail.create
PASS Viewer server denies detail.delete
PASS Viewer server denies voucher.create
PASS Viewer server denies voucher.edit
PASS Viewer server denies voucher.approve
PASS Viewer server denies voucher.finalize
PASS Viewer server denies voucher.void
PASS Viewer server denies voucher.reopen
PASS Viewer server denies voucher.delete
PASS Viewer can read vouchers and real ledger
PASS Role matrix exact capabilities company_admin
PASS Role matrix exact capabilities accountant
PASS Role matrix exact capabilities cashier
PASS Role matrix exact capabilities storekeeper
PASS Role matrix exact capabilities salesperson
PASS Role matrix exact capabilities viewer
PASS DB rejects cross-company role assignment
PASS No new business foreign key bypass: voucher detail of foreign company rejected by DB
PASS Business schema all composite foreign keys installed
PASS National check digits reject repeated and invalid personal IDs
PASS Party encrypts national ID, blind index and public hint only
PASS Duplicate national ID rejected and counter rollback leaves no party
PASS Party name and active status update its linked detail atomically
PASS Sensitive reveal requires capability and creates masked audit
PASS Seeded tax is unknown and cannot issue taxable snapshot
PASS Tax snapshot uses date and half-up per-line integer rounding
PASS Overlapping tax dates and out-of-range percentage rejected
PASS Goods/service price fields persist as exact Rial integers
PASS Referenced unit deletion and duplicate barcode rejected
PASS IBAN rejects bad checksum and account has dedicated detail
PASS Receipt posts balanced automatic source voucher and bank balance
PASS Party with posted movement cannot delete; statement matches its ledger
PASS Transfer changes both accounts and preserves aggregate cash
PASS Same-account transfer and cash-to-bank method mismatch rejected
PASS Pending cheque affects notes receivable and forecast, not bank
PASS Collected cheque moves notes to bank
PASS Stale cheque revision and invalid backwards date rejected
PASS Returned collected cheque reverses bank and restores party claim
PASS Void document reverses all event vouchers and original with no residual effect
PASS Partial multi-item settlement sums to allocated invoice amount
PASS Over-settlement rolls back number, document and voucher atomically
PASS Returned cheque releases only its allocation and retains cash settlement
PASS Void settlement document releases all remaining allocations
PASS Changing tax rate does not mutate stored invoice-line snapshot
PASS Bank reconciliation uses matched real ledger lines and shows zero difference
PASS Cash account cannot be reconciled as a bank
PASS Cashier can post receipt without generic manual-voucher permission
PASS Cashier cannot reveal national identity or confirm tax rates
PASS Cross-company party/account/item/tax inputs rejected by services
PASS Outgoing payment cheque collection/return restores payable and cash
PASS Final source voucher blocks full void and rolls back earlier event reversals
PASS Credit limit warning equals the real receivable-detail ledger balance
PASS Bank reconciliation rejects a same-company line from another treasury account
PASS DB composite FK rejects foreign parent: fk_b_parties_detail_id
PASS DB composite FK rejects foreign parent: fk_b_items_unit_id
PASS DB composite FK rejects foreign parent: fk_b_items_group_id
PASS DB composite FK rejects foreign parent: fk_b_items_tax_rate_id
PASS DB composite FK rejects foreign parent: fk_b_items_sale_account_id
PASS DB composite FK rejects foreign parent: fk_b_items_purchase_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_accounts_detail_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_accounts_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_party_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_source_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_target_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_fiscal_year_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_doc_items_doc_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_doc_items_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_doc_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_doc_item_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_party_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_cheque_events_cheque_id
PASS DB composite FK rejects foreign parent: fk_b_cheque_events_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_party_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_fiscal_year_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_invoice_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_item_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_tax_rate_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_invoice_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_doc_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_doc_item_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliations_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliation_items_reconciliation_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliation_items_voucher_line_id
PASS Business audit chain intact and all approved vouchers balanced

RESULT: 169 passed; 0 failed; 0 skipped
```

### concurrency-business-final.log

```text
PASS simultaneous settle commits exactly once
PASS simultaneous collect commits exactly once
PASS simultaneous party commits exactly once
PASS invoice allocation and bank balance remain exact
PASS failed competing operation leaves gap-free numbers and valid audit
RESULT: 5 passed; 0 failed; 0 skipped
```

### browser-business-final.log

```text
PASS Render business page parties
PASS Render business page items
PASS Render business page units
PASS Render business page groups
PASS Render business page taxes
PASS Render business page treasury_accounts
PASS Render business page receipts
PASS Render business page payments
PASS Render business page transfers
PASS Render business page cheques
PASS Render business page bank_reconciliation
PASS Render business page cash_forecast
PASS Party form validates and persists encrypted identity and linked detail
PASS Sensitive identity is explicit POST and audit path, absent from normal profile
PASS Unit and group forms save real lookup records
PASS Tax UI stores explicit reviewed rate and date range
PASS Goods UI persists unit, group, price and chosen tax
PASS Treasury accounts create independent bank/cash details
PASS Cash receipt UI creates source-linked voucher and view
PASS Payment form remains payment after server validation error
PASS Dynamic treasury rows and cheque issue are real
PASS Cheque collection and return execute real server transitions
PASS Bank reconciliation UI matches actual ledger to statement
PASS Void treasury document reverses accounting and preserves number
PASS Business CSV exports all public rows without raw national identity
PASS Business CSV without nonce fails before output
PASS Business cross-company read is 404 before sensitive view
PASS Business mobile form remains bounded and RTL
RESULT: 28 passed; 0 failed; 0 skipped
```

### clean-final-install.log

```text
Unpacking the package...
Installing the theme...
Removing the old version of the theme...
Theme updated successfully.
Success: Installed 1 of 1 themes.
```

### migration-final.log

```text
PASS upgrade preserves companies (4 rows)
PASS upgrade preserves roles (25 rows)
PASS upgrade preserves role_caps (1318 rows)
PASS upgrade preserves company_members (6 rows)
PASS upgrade preserves settings (2 rows)
PASS upgrade preserves fiscal_years (4 rows)
PASS upgrade preserves fiscal_periods (48 rows)
PASS upgrade preserves accounts (349 rows)
PASS upgrade preserves details (3 rows)
PASS upgrade preserves vouchers (6 rows)
PASS upgrade preserves voucher_lines (9 rows)
PASS upgrade preserves sequences (2 rows)
PASS upgrade preserves audit_log (58 rows)
PASS upgrade preserves idempotency (1 rows)
PASS upgrade preserves auth_states (1 rows)
PASS upgrade preserves rate_limits (31 rows)
PASS upgrade preserves login_otp (1 rows)
PASS upgrade preserves audit_heads (5 rows)
PASS upgrade preserves schema_migrations (2 rows)
RESULT: 19 passed; 0 failed; 0 skipped
```

خروجی اجرای یک‌دستوری، رگرسیون مرورگر و lint کامل در docs/test-results/phase-4-6 باقی است. بستهٔ بازبینی شامل patch، تاریخچهٔ Git، فایل تحویل کوتاه، screenshotهای آزمایشی و SHA256SUMS است.
