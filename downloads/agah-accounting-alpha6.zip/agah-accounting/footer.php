</main>
<footer class="site-footer" id="site-footer">
	<div class="shell footer-grid">
		<div>
			<h4><?php
if(!defined('ABSPATH')) exit; bloginfo( 'name' ); ?></h4>
			<p data-agah="agah_footer_about"><?php echo esc_html( agah_mod( 'agah_footer_about', 'مجموعهٔ خدمات حسابداری و مشاورهٔ مالی' ) ); ?></p>
		</div>
		<div>
			<h4>دسترسی سریع</h4>
			<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'menu_class' => 'footer-menu', 'depth' => 1, 'fallback_cb' => false ) ); ?>
		</div>
		<div>
			<h4>تماس با ما</h4>
			<?php if ( $v = agah_mod( 'agah_address' ) ) echo '<p data-agah="agah_address">' . esc_html( $v ) . '</p>'; ?>
			<?php if ( $v = agah_mod( 'agah_phone' ) ) echo '<p data-agah="agah_phone" dir="ltr" style="text-align:right">' . esc_html( $v ) . '</p>'; ?>
			<?php if ( $v = agah_mod( 'agah_email' ) ) echo '<p data-agah="agah_email"><a href="mailto:' . esc_attr( $v ) . '">' . esc_html( $v ) . '</a></p>'; ?>
			<?php if ( $v = agah_mod( 'agah_hours' ) ) echo '<p data-agah="agah_hours">' . esc_html( $v ) . '</p>'; ?>
		</div>
	</div>
	<?php if ( $t = get_theme_mod( 'agah_trust_html', '' ) ) echo '<div class="shell trust">' . $t . '</div>'; // sanitized on save ?>
	<div class="footer-bottom"><div class="shell">
		© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?> — <span data-agah="agah_copyright"><?php echo esc_html( agah_mod( 'agah_copyright', 'تمامی حقوق این سایت محفوظ است.' ) ); ?></span>
	</div></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
