# گزارش تحویل مراحل ۱ تا ۳ — حسابداری آگاه 3.0.0-alpha2

تاریخ: ۱۴۰۵/۰۷/۲۶. مبنا: ZIP ارسالی `agah-accounting-3.0.0-alpha1.zip` و CODEX-HANDOFF.md؛ فایل طراحی نیز بررسی شد. مطابق درخواست تازهٔ کارفرما، سه مرحله در یک تحویل قرار گرفته‌اند. این بسته برای بازبینی کلاد و مهندسان، روی محیط آزمایشی آماده است؛ تأیید استفادهٔ عملیاتی/امنیت کامل نیست.

## ۱. امکانات پیاده‌سازی‌شده

### مرحلهٔ ۱

ورود WordPress با پیام خطای یکسان و nonce، سهمیهٔ اتمیک IP و IP+حساب، پایان بی‌فعالیتی، سیاست گذرواژه، TOTP استاندارد با کلید دستی و هشت کد بازیابی یکبارمصرف، محافظ replay و نشان MFA مخصوص هر نشست؛ الزام شرکت حتی بعد از ورود مستقیم wp-login. قرارداد SmsProvider و موتور OTP محدود/زمان‌دار پیاده است، ولی اتصال واقعی پیامک پیش‌فرض خاموش است و ادعای ارسال واقعی نداریم. توکن امضاشدهٔ فرم و ادعا/عملیات/نتیجه در یک تراکنش، برای تمام POSTهای دامنه برقرار است. هدرها و CSP محلی فعال‌اند.

### مرحلهٔ ۲

ویرایش مشخصات شرکت و شناسهٔ ملی رمزنگاری‌شده، ریال/تومان، پیشوند نمایشی شماره و الزام MFA؛ اعضای موجود/جدید، نقش سفارشی و کپی نقش سیستمی، ماتریس منبع×عمل، حذف منطقی عضو و حفظ آخرین مدیر؛ تفصیلی شناور، مرکز هزینه و پروژه؛ ویرایش کنترل‌شدهٔ حساب؛ وضعیت دوره/سال با منع بستن سال دارای پیش‌نویس؛ ممیزی فیلترشونده و سلامت زنجیره. فهرست اعضا/تفصیلی/کدینگ/اسناد/ممیزی و گزارش‌های مالی صفحه‌بندی سرور دارند.

### مرحلهٔ ۳

ثبت/ویرایش/حذف پیش‌نویس، تأیید و شمارهٔ بدون فاصله، قطعی‌کردن، بازگشایی با دلیل و ابطال با حفظ شماره؛ کنترل دوره و سال، حساب معین فعال، تفصیلی هم‌شرکت و سازگار، سمت بدهکار/بستانکار، محدودهٔ پول و توازن مجدد SQL. revision از ویرایش کهنه جلوگیری می‌کند. postSystem/voidSystem با منبع و rollback آزموده شده‌اند. فرم ردیف پویا، جست‌وجوی حساب، جمع BigInt، تقویم محلی و چاپ؛ دفاتر روزنامه/کل/معین، گردش و تراز دو/چهارستونی با ماندهٔ اول و جمع واقعی؛ CSV ضد فرمول و Excel XML تمام ردیف‌ها.

## ۲. آزمون‌های اجراشده

محیط: WordPress 7.1.3، PHP 8.2.34، MariaDB 11.4.13، Playwright 1.62.1 و Chromium واقعی. سه سایت مستقل برای توسعه، نصب تمیز و ارتقای alpha1 استفاده شدند. این‌ها دادهٔ آزمایشی‌اند و وارد ZIP نشده‌اند.

| آزمون | دستور/روش | نتیجهٔ واقعی |
|---|---|---|
| نسخهٔ اولیه | `wp eval-file tests/smoke.php` در مسیر theme | ۲۷ pass؛ پیش از تغییر کد |
| رگرسیون smoke | `wp eval-file wp-content/themes/agah-accounting/tests/smoke.php` | ۲۷ pass، exit 0 |
| واحد/یکپارچگی/دسترسی | `wp eval-file wp-content/themes/agah-accounting/tests/run.php` | ۱۰۰ pass، صفر fail/skip |
| چند فرایند DB | `python3 tests/integration/concurrency.py` | ۷ pass، صفر fail/skip |
| مرورگر/HTTP | `node tests/security/browser.cjs <private-fixture> <screenshots>` | ۴۳ pass، صفر fail/skip |
| اجرای یک‌دستوری | `bash tests/run-all.sh` | تمام چهار گروه بالا اجرا و exit 0 |
| نصب ZIP روی سایت تمیز | WP-CLI theme install + activate و HTTP واقعی صفحهٔ ورود | نصب/فعال‌سازی موفق؛ ۲۷ smoke و ۱۰۰ آزمون مجدداً pass |
| ارتقای واقعی alpha1→alpha2 | `tests/migration.php capture` روی alpha1، سپس install ZIP alpha2 و `verify` | هش تمام ستون‌های قبلی هر ۱۳ جدول عیناً حفظ شد؛ ۱۳ pass |
| نحو PHP | `find ... -name '*.php' -print0` و `xargs -0 -n1 php -l` | ۷۶ فایل PHP بدون خطای نحوی در اجرای ثبت‌شده |
| نحو JS | `node --check erp/assets/forms.js` و browser.cjs | exit 0 |
| ایمیل واقعی/پیامک واقعی | ارائه‌دهنده/SMTP تنظیم نشده | اجرا نشد؛ sendmail در کانتینر موجود نیست |
| آزمون نفوذ مستقل/بار عملیاتی/نسخه‌های دیگر PHP و افزونه‌های ثالث | خارج از بستر این اجرا | اجرا نشد |

اعداد گروه‌های تکرارشده را به‌عنوان «آزمون یکتای جدید» جمع نزده‌ایم. هر check می‌تواند شامل چند assertion باشد. کل خروجی اجرای فعلی در docs/test-results است؛ بخش ۷ این گزارش نیز خروجی خام اصلی را دارد.

## ۳. اصلاحات و تصمیم‌های معماری

- Page بزرگ به نماهای جدا و کنترلر مشترک POST تقسیم شد؛ رفتار سایت و سفارشی‌ساز مبنا حفظ شد.
- قفل ممیزی alpha1 پیش از commit آزاد می‌شد؛ اکنون audit_heads تا پایان تراکنش قفل است. آزمون موازی نخست بن‌بست تبدیل قفل را نشان داد؛ با upsert انحصاری و current read اصلاح و دوباره آزموده شد. در زیرساخت سهمیه/شمارنده نیز همین الگو رعایت شد.
- تراکنش تو در تو savepoint دارد؛ گرفتن استثنای داخلی در فراخواننده، دادهٔ نیمه‌تمام باقی نمی‌گذارد.
- فیلد HTML نام، `erp_name` شد؛ `name` رزروشدهٔ query وردپرس، POST را به مسیر ۴۰۴ منحرف می‌کرد.
- شمارندهٔ runner قدیمی در scope WP-CLI می‌توانست شکست را از exit status پنهان کند؛ اصلاح شد. گزارش فقط نتایج runner اصلاح‌شده را برای نسخهٔ جدید موفق معرفی می‌کند.
- نوشتن هر شرکت با قفل ردیف شرکت سری می‌شود؛ صحت بر throughput مقدم است و آزمون بار ادعا نشده.
- فعال‌سازی رمزساز با کلید دستی است؛ QR پیاده نشده. هیچ کلید به سرویس QR بیرونی فرستاده نمی‌شود.
- قالب و هسته هنوز تفکیک نشده‌اند؛ طرح در docs/PLUGIN-SPLIT.md است و انجام آن به مرحله/تأیید مربوط موکول شده.

## ۴. نصب/ارتقا و حفظ داده

راهنمای کامل در docs/INSTALL.md است. پیش از نصب، backup هماهنگ فایل+DB+کلید بگیرید؛ ابتدا روی staging نصب کنید. ZIP ساختار `agah-accounting/` دارد و از پنل پوسته‌های WordPress نصب می‌شود. ارتقا از Schema 1 به 3 افزایشی است: شش جدول زیرساخت، revision و ایندکس ممیزی؛ حذف جدول/اطلاعات ندارد. آزمون migration روی نسخهٔ اولیهٔ واقعی با مقایسهٔ هش تمام ستون‌های قدیمی انجام شد؛ جدول‌های خالی نیز جدا در خروجی مشخص‌اند. دادهٔ آزمایشی در زمان نصب خودکار تولید نمی‌شود. downgrade خودکار نداریم.

## ۵. محدودیت‌ها و باقی‌مانده

- مراحل ۴ تا ۱۸ (اشخاص، کالا، خزانه، فروش/خرید، انبار، صورت‌های مالی/بستن حساب‌ها، فایل، حقوق، دارایی، گزارش قانونی، backup و سفارشی‌سازی کامل ERP) باقی‌اند؛ docs/ROADMAP.md.
- وضعیت «بسته» سال در این تحویل، اختتامیه و انتقال ماندهٔ خودکار نیست.
- ارائه‌دهندهٔ پیامک و تأیید شمارهٔ کاربر هنوز انتخاب/پیاده‌سازی عملیاتی نشده؛ تست OTP با آداپتور حافظه‌ای است.
- Excel از نوع SpreadsheetML XML است، نه XLSX؛ PDF با چاپ صفحهٔ جاری مرورگر است، نه مولد PDF سرور. خروجی CSV/Excel تمام صفحات را دارد.
- API اسناد منبع فعلاً مجوز voucher.create/void می‌خواهد؛ اتصال ماژول‌های آینده با نقش‌های محدودتر نیاز به بازبینی مجوز منبع دارد.
- HTTPS، کلید اختصاصی پایدار، محدودیت DB و cache exclusion باید در استقرار واقعی تنظیم شوند؛ محیط آزمایشی HTTP محلی بود. ارسال ایمیل آزموده نیست.
- کلید QR، بازیابی مدیریتی MFA، سازگاری افزونه‌های ثالث، بار سنگین و حسابرسی رسمی مالی تأیید نشده‌اند. امنیت صددرصد ادعا نمی‌شود.

## ۶. فایل‌های جدید/تغییرکرده

| مسیر | وضعیت | توضیح |
|---|---|---|
| `404.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `CHANGELOG.md` | جدید | نسخه، راهنما یا گزارش این تحویل. |
| `README.md` | جدید | نسخه، راهنما یا گزارش این تحویل. |
| `REPORT-1-3.md` | جدید | نسخه، راهنما یا گزارش این تحویل. |
| `assets/fonts/OFL.txt` | جدید | مجوز رسمی فونت محلی حفظ‌شده از ورودی. |
| `changelog.txt` | تغییر | نسخه، راهنما یا گزارش این تحویل. |
| `docs/ARCHITECTURE.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/DB-SCHEMA.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/DEPENDENCIES.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/FILE-MAP.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/INSTALL.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/PLUGIN-SPLIT.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/README.md` | تغییر | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/ROADMAP.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/SECURITY.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/TESTING.md` | جدید | مستندات نصب، معماری، امنیت یا ادامهٔ توسعه. |
| `docs/test-results/baseline-smoke.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/browser.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/clean-install.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/clean-integration.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/clean-smoke.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/concurrency.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/integration.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/migration.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/php-lint.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/regression-smoke.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/run-all.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/upgrade-baseline.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `docs/test-results/upgrade-install.log` | جدید | خروجی خام آزمون؛ دادهٔ آزمایشی، بدون اطلاعات ورود. |
| `erp/assets/erp.css` | تغییر | RTL، فرم/جدول، امنیت، موبایل و چاپ. |
| `erp/assets/forms.js` | جدید | فرم واقعی، BigInt، ردیف پویا و تقویم شمسی محلی. |
| `erp/bootstrap.php` | تغییر | ثبت سرویس‌ها/هوک‌ها و cron زیرساخت. |
| `erp/src/Core/Access.php` | جدید | کنترل سرویس و بازخوانی مجوز زیر قفل شرکت. |
| `erp/src/Core/Audit.php` | تغییر | قفل سر ممیزی تا commit و current read آخرین هش. |
| `erp/src/Core/Ctx.php` | تغییر | عضویت و الزام MFA، current read مجوز. |
| `erp/src/Core/Db.php` | تغییر | تراکنش تو در تو با savepoint و بازگردانی cache تنظیمات در شکست. |
| `erp/src/Core/Idempotency.php` | جدید | امضای فرم، ادعای اتمیک، نتیجه و پاک‌سازی. |
| `erp/src/Core/Money.php` | تغییر | کنترل جمع صحیح و محدودهٔ Money بدون float. |
| `erp/src/Core/Request.php` | تغییر | جلوگیری از تداخل فیلد name با query var وردپرس. |
| `erp/src/Core/Schema.php` | تغییر | مهاجرت افزایشی Schema 3، جدول‌های زیرساخت و revision سند. |
| `erp/src/Core/Sequence.php` | تغییر | قفل انحصاری شمارنده بدون ارتقای قفل مشترک. |
| `erp/src/Core/Settings.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `erp/src/Http/ModuleController.php` | جدید | POST مشترک، nonce/مجوز/idempotency/PRG، فیلتر و فایل خروجی. |
| `erp/src/Http/Page.php` | تغییر | هماهنگی صفحه و dispatch سازگار؛ HTML جدا شده. |
| `erp/src/Http/SecurityController.php` | جدید | هدر، نشست، MFA و فرم‌های مالک حساب. |
| `erp/src/Modules/Accounting/AccountService.php` | تغییر | ویرایش کنترل‌شدهٔ حساب و قفل با ثبت سند. |
| `erp/src/Modules/Accounting/DetailService.php` | جدید | تفصیلی، CRUD محدود و صفحه‌بندی. |
| `erp/src/Modules/Accounting/FiscalService.php` | تغییر | وضعیت سال، پیش‌شرط نبود پیش‌نویس و قفل دوره. |
| `erp/src/Modules/Accounting/ReportService.php` | جدید | دفاتر، تراز، مانده و جمع روی دادهٔ واقعی. |
| `erp/src/Modules/Accounting/VoucherService.php` | جدید | چرخهٔ کامل سند، اعتبارسنجی، revision و API سند منبع. |
| `erp/src/Modules/Company/CompanyService.php` | تغییر | مشخصات رمزنگاری‌شده و تنظیمات whitelist شرکت. |
| `erp/src/Modules/Company/MemberService.php` | جدید | عضو و نقش، ماتریس مجوز و حفظ آخرین مدیر. |
| `erp/src/Security/Auth.php` | جدید | احراز هویت، عامل دوم یا محدودیت تلاش؛ توضیح قیود در فایل و SECURITY.md. |
| `erp/src/Security/RateLimiter.php` | جدید | احراز هویت، عامل دوم یا محدودیت تلاش؛ توضیح قیود در فایل و SECURITY.md. |
| `erp/src/Security/SmsOtp.php` | جدید | احراز هویت، عامل دوم یا محدودیت تلاش؛ توضیح قیود در فایل و SECURITY.md. |
| `erp/src/Security/SmsProvider.php` | جدید | احراز هویت، عامل دوم یا محدودیت تلاش؛ توضیح قیود در فایل و SECURITY.md. |
| `erp/src/Security/Totp.php` | جدید | احراز هویت، عامل دوم یا محدودیت تلاش؛ توضیح قیود در فایل و SECURITY.md. |
| `erp/src/Security/TwoFactor.php` | جدید | احراز هویت، عامل دوم یا محدودیت تلاش؛ توضیح قیود در فایل و SECURITY.md. |
| `erp/views/audit.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/details.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/legacy-pageAccounts.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/legacy-pageAudit.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/legacy-pageDashboard.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/legacy-pageFiscal.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/legacy-viewCompany.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/legacy-viewHome.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/legacy-viewLogin.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/members.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/reports.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/roles.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/security/account.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/settings.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/voucher-form.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/voucher-line.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/voucher-view.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `erp/views/vouchers.php` | جدید | نمای جداشده و escapeشدهٔ صفحه/فرم؛ زمینه و مجوز از کنترلر. |
| `footer.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `front-page.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `functions.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `header.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `index.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `page.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `readme.txt` | تغییر | نسخه، راهنما یا گزارش این تحویل. |
| `sidebar.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `single.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `style.css` | تغییر | نسخه، راهنما یا گزارش این تحویل. |
| `template-parts/card.php` | تغییر | حفظ رفتار قالب اولیه و افزودن محافظ دسترسی مستقیم PHP. |
| `tests/browser-control.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/browser-fixture.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/integration/concurrency-setup.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/integration/concurrency-worker.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/integration/concurrency.py` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/integration/core.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/migration.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/run-all.sh` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/run.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/security/access.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/security/browser.cjs` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/smoke.php` | تغییر | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |
| `tests/unit/security.php` | جدید | آزمون یا ابزار بازتولید روی WordPress دورریختنی؛ فاقد دادهٔ عملیاتی. |

## ۷. خروجی خام اجرا

### baseline-smoke.log

```text
PASS jalali 2026-10-18 = 1405/07/26
PASS jalali parse roundtrip
PASS jalali leap 1403
PASS money toman->rial
PASS money rounding
PASS money overflow throws
PASS companies created
PASS chart seeded (>50 moin)
PASS fiscal year has 12 periods
PASS admin role has all caps
PASS member boots own company
PASS other company => NotFound
PASS WP administrator is NOT auto-member
PASS foreign account id => NotFound
PASS account created
PASS duplicate code rejected
PASS wrong prefix rejected
PASS system account not deletable
PASS user account deletable
PASS date inside open year ok
PASS date outside year rejected
PASS closed period rejected
PASS audit chain intact
PASS audit tamper detected
PASS rollback leaves no row
PASS sequence gap-free after rollback
PASS DB blocks cross-company FK

ALL PASSED
```

### integration.log

```text
PASS RFC6238 SHA1 timestamp 59
PASS RFC6238 SHA1 timestamp 1111111109
PASS RFC6238 SHA1 timestamp 1111111111
PASS RFC6238 SHA1 timestamp 1234567890
PASS RFC6238 SHA1 timestamp 2000000000
PASS RFC6238 SHA1 timestamp 20000000000
PASS TOTP wrong format rejected
PASS TOTP current/adjacent steps and expiry
PASS Base32 random key uses 32 valid symbols
PASS Password short/no letter/no number rejected
PASS Money accepts Persian digits and exact toman fraction
PASS Money overflow and fractions rejected
PASS Encryption authentication detects tampering
PASS Jalali leap day and roundtrip
PASS Upgrade preserves baseline rows and installs six new tables
PASS Schema upgrade repeatability preserves rows
PASS Idempotency claim complete and replay result
PASS Token payload substitution and company/user tampering rejected
PASS Token rollback releases claim and domain change
PASS Unsigned and expired form token rejected
PASS Idempotency requires transaction
PASS Rate limit exact cap and window expiry
PASS Login errors identical for invalid username/password
PASS Login IP+user throttle also covers email alias
PASS Login IP aggregate throttles many distinct usernames
PASS New session has no second factor marker
PASS Idle session destroys only expired token
PASS TOTP enrollment requires correct password
PASS Pending secret encrypted and bound to session
PASS Enable verifies first code and creates eight hashed backup codes
PASS TOTP initial code replay is rejected
PASS TOTP next step accepted once; replay rejected
PASS Backup code is consumed exactly once
PASS Other WP session cannot inherit verified factor
PASS Require2fa company policy applied
PASS TOTP brute force bounded
PASS TOTP disable requires password and invalidates marker
PASS SMS disabled without selected provider
PASS SMS code stored hashed and bound to session; one-time use
PASS SMS expires after two minutes
PASS SMS five failed attempts block correct code
PASS SMS hourly send cap enforced
PASS Cannot remove/downgrade last active company admin
PASS Member existing user added with scoped role
PASS Custom role matrix saves exact caps and audits
PASS System role editing/deleting rejected
PASS Removed member history retained; no WordPress user deleted
PASS Company edits encrypt national identifier and preserve metadata
PASS Detail create/update/read persists
PASS Duplicate detail code rejected
PASS Unused custom account structure can update
PASS Balanced draft saved without number and excluded from ledger
PASS Draft imbalance allowed; approval rejected
PASS Both debit and credit in one line rejected
PASS Non-leaf and incompatible details rejected
PASS Float money rejected and no partial voucher persists
PASS Approval allocates number and journals balance
PASS Approved voucher cannot become unbalanced by edit
PASS Optimistic revision rejects stale edit
PASS Finalize locks contents and physical deletion
PASS Reopen requires reason and keeps number
PASS Detail with turnover cannot delete
PASS Void retains number and excludes journal
PASS System post creates approved source-linked voucher
PASS System duplicate source/manual edit/void rejected
PASS System void returns effect from journal
PASS Account ledger opening and cumulative closing from real entries
PASS Trial balance two/four columns and general/subsidiary all balance
PASS Ledger pagination carries previous page running balance
PASS Closed period blocks create and edit of existing voucher
PASS Year with draft cannot close; no-draft closes and reopens
PASS Approval rechecks account activation after draft creation
PASS Audit intact after all operations; national id masked
PASS Foreign company context always NotFound
PASS Foreign account line rejected before DB mutation
PASS Company-scoped detail/report/member IDOR rejected
PASS Voucher foreign id get/edit/state/delete all NotFound
PASS Service company argument cannot override current context
PASS Viewer server denies company_settings.edit
PASS Viewer server denies member.create
PASS Viewer server denies member.edit
PASS Viewer server denies role.edit
PASS Viewer server denies detail.create
PASS Viewer server denies detail.delete
PASS Viewer server denies voucher.create
PASS Viewer server denies voucher.edit
PASS Viewer server denies voucher.approve
PASS Viewer server denies voucher.finalize
PASS Viewer server denies voucher.void
PASS Viewer server denies voucher.reopen
PASS Viewer server denies voucher.delete
PASS Viewer can read vouchers and real ledger
PASS Role matrix exact capabilities company_admin
PASS Role matrix exact capabilities accountant
PASS Role matrix exact capabilities cashier
PASS Role matrix exact capabilities storekeeper
PASS Role matrix exact capabilities salesperson
PASS Role matrix exact capabilities viewer
PASS DB rejects cross-company role assignment
PASS No new business foreign key bypass: voucher detail of foreign company rejected by DB

RESULT: 100 passed; 0 failed; 0 skipped
Success: All selected tests executed.
```

### concurrency.log

```text
PASS Four concurrent approvals all commit
PASS Four simultaneous duplicate tokens create exactly one request
PASS Atomic rate limit allows exactly three of eight requests
PASS Eight concurrent audit commits complete
PASS Concurrent approvals use gap-free unique numbers
PASS Duplicate request has exactly one persisted draft
PASS Audit hash chain intact after all concurrent writes
RESULT: 7 passed; 0 failed; 0 skipped
```

### browser.log

```text
PASS Login POST without CSRF nonce is rejected
PASS HTTP ERP page security headers and generic login form
PASS Real WordPress login and ERP company list
PASS Render authenticated page dashboard
PASS Render authenticated page accounts
PASS Render authenticated page fiscal
PASS Render authenticated page audit
PASS Render authenticated page settings
PASS Render authenticated page members
PASS Render authenticated page roles
PASS Render authenticated page details
PASS Render authenticated page vouchers
PASS Render authenticated page reports
PASS Render authenticated page voucher_new
PASS Render authenticated page security
PASS Account edit and save through real company form
PASS Create custom role and member using real forms
PASS Legacy company creation uses shared CSRF/idempotency controller
PASS Legacy fiscal-year form creates twelve-month year
PASS Company IDOR returns HTTP 404 before financial HTML
PASS Local Jalali picker selects real Persian date
PASS Voucher rows add/remove and exact live totals
PASS Real form saves voucher and PRG loads persisted lines
PASS Approve then finalize through real POST forms
PASS CSV export is real attachment and matches ledger
PASS Excel export contains SpreadsheetML cells
PASS GET export without nonce rejected
PASS POST CSRF without nonce does not create detail
PASS Detail form saves once and duplicate POST replays result
PASS Form validation preserves entered values and shows error
PASS Desktop voucher/report screenshot renders with local font
PASS Mobile RTL and bounded layout
PASS ERP makes no external UI requests
PASS No JavaScript runtime exceptions
PASS TOTP enrollment with password, encrypted pending secret and eight backup codes via UI
PASS Direct wp-login session cannot bypass ERP second factor
PASS Recovery code authenticates only the current new session
PASS Consumed recovery code rejected in another login session
PASS Company require_2fa setting saves and enforces enrollment after disable
PASS Idle session is logged out before ERP data or POST access
PASS Viewer cannot request settings editor via GET role page
PASS Viewer financial POST denied even with valid own nonce/token
PASS WP administrator is not automatically company member
RESULT: 43 passed; 0 failed; 0 skipped
```

### clean-install.log

```text
sh: 1: /usr/sbin/sendmail: not found
Clean WordPress initialized
Success: Added the constant 'AGAH_TEST_MODE' to the 'wp-config.php' file with the raw value 'true'.
Unpacking the package...
Installing the theme...
Theme installed successfully.
Activating 'agah-accounting'...
Success: Switched to 'حسابداری آگاه (Agah Accounting)' theme.
Success: Installed 1 of 1 themes.
```

### clean-smoke.log

```text
PASS jalali 2026-10-18 = 1405/07/26
PASS jalali parse roundtrip
PASS jalali leap 1403
PASS money toman->rial
PASS money rounding
PASS money overflow throws
PASS companies created
PASS chart seeded (>50 moin)
PASS fiscal year has 12 periods
PASS admin role has all caps
PASS member boots own company
PASS other company => NotFound
PASS WP administrator is NOT auto-member
PASS foreign account id => NotFound
PASS account created
PASS duplicate code rejected
PASS wrong prefix rejected
PASS system account not deletable
PASS user account deletable
PASS date inside open year ok
PASS date outside year rejected
PASS closed period rejected
PASS audit chain intact
PASS audit tamper detected
PASS rollback leaves no row
PASS sequence gap-free after rollback
PASS DB blocks cross-company FK

ALL PASSED
```

### clean-integration.log

```text
PASS RFC6238 SHA1 timestamp 59
PASS RFC6238 SHA1 timestamp 1111111109
PASS RFC6238 SHA1 timestamp 1111111111
PASS RFC6238 SHA1 timestamp 1234567890
PASS RFC6238 SHA1 timestamp 2000000000
PASS RFC6238 SHA1 timestamp 20000000000
PASS TOTP wrong format rejected
PASS TOTP current/adjacent steps and expiry
PASS Base32 random key uses 32 valid symbols
PASS Password short/no letter/no number rejected
PASS Money accepts Persian digits and exact toman fraction
PASS Money overflow and fractions rejected
PASS Encryption authentication detects tampering
PASS Jalali leap day and roundtrip
PASS Upgrade preserves baseline rows and installs six new tables
PASS Schema upgrade repeatability preserves rows
PASS Idempotency claim complete and replay result
PASS Token payload substitution and company/user tampering rejected
PASS Token rollback releases claim and domain change
PASS Unsigned and expired form token rejected
PASS Idempotency requires transaction
PASS Rate limit exact cap and window expiry
PASS Login errors identical for invalid username/password
PASS Login IP+user throttle also covers email alias
PASS Login IP aggregate throttles many distinct usernames
PASS New session has no second factor marker
PASS Idle session destroys only expired token
PASS TOTP enrollment requires correct password
PASS Pending secret encrypted and bound to session
PASS Enable verifies first code and creates eight hashed backup codes
PASS TOTP initial code replay is rejected
PASS TOTP next step accepted once; replay rejected
PASS Backup code is consumed exactly once
PASS Other WP session cannot inherit verified factor
PASS Require2fa company policy applied
PASS TOTP brute force bounded
PASS TOTP disable requires password and invalidates marker
PASS SMS disabled without selected provider
PASS SMS code stored hashed and bound to session; one-time use
PASS SMS expires after two minutes
PASS SMS five failed attempts block correct code
PASS SMS hourly send cap enforced
PASS Cannot remove/downgrade last active company admin
PASS Member existing user added with scoped role
PASS Custom role matrix saves exact caps and audits
PASS System role editing/deleting rejected
PASS Removed member history retained; no WordPress user deleted
PASS Company edits encrypt national identifier and preserve metadata
PASS Detail create/update/read persists
PASS Duplicate detail code rejected
PASS Unused custom account structure can update
PASS Balanced draft saved without number and excluded from ledger
PASS Draft imbalance allowed; approval rejected
PASS Both debit and credit in one line rejected
PASS Non-leaf and incompatible details rejected
PASS Float money rejected and no partial voucher persists
PASS Approval allocates number and journals balance
PASS Approved voucher cannot become unbalanced by edit
PASS Optimistic revision rejects stale edit
PASS Finalize locks contents and physical deletion
PASS Reopen requires reason and keeps number
PASS Detail with turnover cannot delete
PASS Void retains number and excludes journal
PASS System post creates approved source-linked voucher
PASS System duplicate source/manual edit/void rejected
PASS System void returns effect from journal
PASS Account ledger opening and cumulative closing from real entries
PASS Trial balance two/four columns and general/subsidiary all balance
PASS Ledger pagination carries previous page running balance
PASS Closed period blocks create and edit of existing voucher
PASS Year with draft cannot close; no-draft closes and reopens
PASS Approval rechecks account activation after draft creation
PASS Audit intact after all operations; national id masked
PASS Foreign company context always NotFound
PASS Foreign account line rejected before DB mutation
PASS Company-scoped detail/report/member IDOR rejected
PASS Voucher foreign id get/edit/state/delete all NotFound
PASS Service company argument cannot override current context
PASS Viewer server denies company_settings.edit
PASS Viewer server denies member.create
PASS Viewer server denies member.edit
PASS Viewer server denies role.edit
PASS Viewer server denies detail.create
PASS Viewer server denies detail.delete
PASS Viewer server denies voucher.create
PASS Viewer server denies voucher.edit
PASS Viewer server denies voucher.approve
PASS Viewer server denies voucher.finalize
PASS Viewer server denies voucher.void
PASS Viewer server denies voucher.reopen
PASS Viewer server denies voucher.delete
PASS Viewer can read vouchers and real ledger
PASS Role matrix exact capabilities company_admin
PASS Role matrix exact capabilities accountant
PASS Role matrix exact capabilities cashier
PASS Role matrix exact capabilities storekeeper
PASS Role matrix exact capabilities salesperson
PASS Role matrix exact capabilities viewer
PASS DB rejects cross-company role assignment
PASS No new business foreign key bypass: voucher detail of foreign company rejected by DB

RESULT: 100 passed; 0 failed; 0 skipped
Success: All selected tests executed.
```

### migration.log

```text
Captured hashes of 13 alpha1 tables
PASS upgrade preserves companies (2 rows)
PASS upgrade preserves roles (12 rows)
PASS upgrade preserves role_caps (654 rows)
PASS upgrade preserves company_members (2 rows)
PASS upgrade preserves settings (0 rows)
PASS upgrade preserves fiscal_years (2 rows)
PASS upgrade preserves fiscal_periods (24 rows)
PASS upgrade preserves accounts (174 rows)
PASS upgrade preserves details (0 rows)
PASS upgrade preserves vouchers (1 rows)
PASS upgrade preserves voucher_lines (0 rows)
PASS upgrade preserves sequences (1 rows)
PASS upgrade preserves audit_log (7 rows)
RESULT: 13 passed; 0 failed; 0 skipped
```

باقی خروجی‌های کامل (از جمله اجرای یک‌دستوری و lint) در docs/test-results است. screenshotهای دسکتاپ و موبایل، patch، bundle تاریخچه و SHA256SUMS در بستهٔ تحویل بازبینی قرار دارند.
