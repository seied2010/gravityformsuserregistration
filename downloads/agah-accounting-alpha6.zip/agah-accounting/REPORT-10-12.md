# گزارش بستهٔ چهارم — مراحل۱۰ تا۱۲

نسخه **3.0.0-alpha5**؛ ERP **0.12.0-alpha**؛ Schema **6**؛ **۴۷ جدول**. مبنا v3.0.0-alpha4 و تاریخ اجرا ۱۹ اکتبر۲۰۲۶ است. این تحویل برای بازبینی فنی و حسابداری در محیط آزمایشی است؛ کامل‌شدن همه ERP یا تأیید رسمی صورت‌های مالی ادعا نمی‌شود.

## نتیجهٔ پیاده‌سازی

**مرحله۱۰:** سرفصل هزینه/درآمد متصل به معین فعال، ابعاد پروژه/شعبه/مرکز هزینه، شناسایی پرداخت‌نشده/دریافت‌نشده با شخص، پرداخت فوری یا بعدی با اقلام واقعی خزانه، تسویه جزئی نقد/بانک/کارت/چک، مانده زنده با برگشت قلم چک و ابطال اتمیک. سند خودکار از cap همان منبع ایجاد می‌شود. گزارش/CSV بر اساس نوع، شخص، سرفصل، ابعاد و دوره است. تصویر رسید با آپلود واقعی PHP در BLOB خصوصی ذخیره و تنها با نشست/عضویت/مجوز/nonce دریافت می‌شود.

**مرحله۱۱:** ترازنامه با اختلاف واقعی، صورت سود و زیان ناخالص/عملیاتی/خالص، جریان نقد غیرمستقیم با تطبیق نقد ابتدا/انتها، مقایسه دوره و بدهکار/بستانکار از دفتر approved/final. بستن با کنترل پیش‌نویس، دوره، سال پیشین، انبار و مقصد: تعدیل موجودی ادواری، موقت→خلاصه→سود انباشته، اختتامیه و افتتاحیه با مانده‌های تفصیلی برابر. تمام مراحل و شماره/سال بعد/ممیزی اتمیک‌اند. بازگشایی فقط پیش از گردش مقصد و با برگشت همه اسناد وابسته است؛ تغییر عمومی وضعیت سال این فرایند را دور نمی‌زند.

**مرحله۱۲:** کارت‌ها، شش‌ماه شمسی و SVG محلی از تجمیع واقعی؛ مانده نقد/مطالبات/بدهی و سود از دفتر. هر کارت cap مستقل دارد. جست‌وجو در سند/شخص/کالا/فاکتور با شرکت، مجوز و سهمیه؛ نام فاصله‌دار و شماره فارسی تک‌رقمی پشتیبانی می‌شود. اعلان داخلیِ فاکتور معوق، چک سررسیدشده، حداقل موجودی و نرخ تأییدنشده؛ منوی گروهی بالا/کناری با انتخاب مدیر سایت در سفارشی‌ساز و باز/بسته‌شدن موبایل/کیبورد.

## آزمون‌های واقعی

| بررسی | دستور/محیط | نتیجهٔ واقعی |
|---|---|---|
| اجرای یک‌دستوری | bash tests/run-all.sh، agah-test | **۲۷۲ PHP + ۲۴ بررسی هم‌زمانی + ۱۳۲ مرورگر، صفر شکست** در زمان اجرا |
| PHP پس از آخرین دو سناریوی جست‌وجو/تاریخ و سناریوی استهلاک | wp eval-file tests/run.php | **۲۷۵ pass، صفر fail/skipped**؛ integration-final.log |
| مرورگر نهایی بسته مالی | node tests/security/finance-browser.cjs | **۲۷ pass، صفر fail/skipped**؛ browser-finance-final.log؛ با ۴۳+۲۸+۳۴ قبلی مجموع۱۳۲ |
| هم‌زمانی مالی | python3 tests/integration/finance-concurrency.py | **۵ pass**؛ با۷+۵+۷ قبلی، مجموع۲۴ بررسی |
| نصب WordPress مستقل از ZIP | wp theme install /tmp/alpha5.zip --activate | pass؛ theme=3.0.0-alpha5 schema=6 tables=47 companies=0 قبل از fixture |
| PHP از ZIP نصب مستقل با کد نهایی | wp eval-file tests/run.php در agah-fresh-10-12 | **۲۷۵ pass، صفر fail/skipped**؛ clean-integration.log |
| smoke نصب مستقل | wp eval-file tests/smoke.php | **۲۷ PASS، ALL PASSED** |
| حفظ داده در ارتقای واقعی | upgrade-finance.php capture روی Schema5، نصب ZIP، verify روی Schema6 | **حفظ هر۴۱ جدول و تمام ستون‌های قبلی** با هش سطر؛ فقط migration جدید مجاز؛ صفر داده حذف/تبدیل‌شده |
| PHP syntax | find -print0 و xargs -0 -n1 php -l | **۱۴۰ فایل pass** |
| JS syntax | node --check روی assets و چهار runner | **۶ فایل pass** |
| آرشیو | CRC/Checksum، تطبیق با Git، نصب ZIP نهایی | نتیجه در بستهٔ تحویل و SHA256SUMS.txt؛ فقط بستهٔ تأییدشده منتشر می‌شود |

به ۲۲۶ بررسی PHP قبلی، ۴۹ بررسی مالی/دسترسی/FK/سناریو اضافه شد. پوشش برجسته: هزینه تعهدی/پرداخت جزئی/چک برگشتی، تصویر خصوصی و ردSVG/بزرگی، ابعاد نوع اشتباه، تراز خراب با هشدار واقعی، سرمایه نقدی و دارایی کاملاً غیرنقدی، استهلاک و عدم ایجاد نقد ساختگی، پیش‌نویس مانع بستن، حمل حساب/تفصیلی با DR/CR معکوس دقیق، حفظ گزارش سال بسته و عدم دوباره‌شماری carry، بازگشایی و گردش مقصد، تعدیل موجودی ادواری، سند قطعی، شکست دیرهنگام با rollback همه مراحل و سال جدید، همه FKهای مرکب تازه، نقش محدودِ فقط داشبورد/اشخاص، جست‌وجوی نام فاصله‌دار و شماره فارسی و شرکت بدون سال جاری.

در مرورگر، upload واقعی multipart و دانلود bytes همان PNG و هدر attachment، nonce فایل/CSV، GET/POST بیگانه، فرم تسویه/ابطال، مقایسه و جریان نقد، بستن/بازگشایی و sidebar/top و موبایل اجرا شد. در رقابت، دو تسویه۱۵۰ روی هزینه۲۰۰ فقط یکی commit شد؛ دو بستن هم‌زمان فقط یک run فعال و افتتاحیه ساختند. حمل تفصیلی/ممیزی و شماره‌های بدون فاصله پس از رقابت بررسی شد.

محیط: WordPress7.1.3، PHP8.2.34، MariaDB11.4.13، Playwright1.62.1 و Chromium محلی. تست‌ها داده خصوصیِ دورریختنی می‌سازند؛ JSON حاوی رمز fixture، .env یا DB وارد بسته نشده‌اند. تصویرها/عکس‌های تحویل فقط fixture هستند. یک اجرای هم‌پوشان PHP و fixture مرورگر روی DB مشترک، آزمون قدیمی throttle را به‌علت reset سهمیه‌ها مختل کرد؛ اجرای سری نهایی روی همان DB و نصب مستقل، هر دو۲۷۵/صفر شکست شدند. runner مشترک مراحل را سری اجرا می‌کند. هشدار sendmail نصب WordPress ناشی از نبود mail transport است و ایمیل واقعی آزموده نشده است.

## فرض‌ها و محدودیت‌های همین بسته

1. جریان نقد بر اساس طبقه حساب و حساب‌های سیستمی cash/bank است؛ بهره/مالیات در عملیاتی قرار می‌گیرند. اسناد نقدی با چند نوع فعالیت با review_count نیازمند بازبینی‌اند؛ الگوریتم از سند به‌تنهایی ماهیت حقوقی معامله مختلط را حدس نمی‌زند. این خروجی تأیید حسابدار رسمی یا گزارش قانونی تضمین‌شده نیست؛ اختلاف تطبیق را پنهان نمی‌کند.
2. مبلغ هزینه/درآمد، ناخالص شناسایی‌شده است؛ VAT جداگانه خط در این ماژول ندارد. تخصیص کل برگه به یک پروژه/شعبه/مرکز است، نه تسهیم درصدی چندمرکزی. سرفصلِ بدون تفصیلی، بُعد را در برگه نگه می‌دارد؛ حساب سازگار مرکز هزینه تفصیلی می‌گیرد.
3. مانده هزینه فقط از پرداختِ مرتبط محاسبه می‌شود؛ پرداخت عمومی تخصیص‌نیافته خودکار به برگه چسبانده نمی‌شود. شخص با نقش متناسب الزامی است. کنترل منفی‌بودن نقد/بانک نسخه‌های قبل تغییر نکرده است.
4. تصویر خصوصی تا۲MiB/۲۰MP و۱۰تصویر برای برگه، با header شناسایی‌شده PNG/JPEG/WebP ذخیره می‌شود؛ آنتی‌ویروس، بازکدگذاری، پیش‌نمایش عمومی یا سامانه عمومی فایل‌ها پیاده نشده‌اند. BLOB باید در backup آینده binary-safe حفظ شود؛ نگهداری بلندمدت و quota گسترده متعلق به مرحله۱۳/۱۷ است.
5. بازگشایی وقتی سال بعد گردش دارد، سند وابسته قطعی است یا دوره مقصد بسته است، رد می‌شود. باید وابستگی‌ها طبق مجوز و ترتیب تعیین تکلیف شوند؛ این نسخه گردش سال بعد را خودکار بازنویسی نمی‌کند. سقف سند خودکار۵۰۰۰ و دستی۲۰۰ خط است؛ UI سابقه بستن۵۰مورد آخر را نشان می‌دهد.
6. اعلان‌ها مشتق‌شده و تا۲۵مورد هرگروه‌اند؛ خوانده‌شدن، آرشیو، push/ایمیل/پیامک ندارند. جست‌وجو تا۱۲مورد هرنوع و۶۰درخواست/دقیقه است. نمودار فروش/خرید با مالیات و سود از دفتر است؛ این دو رقم عمداً معنای یکسان ندارند.
7. محدودیت‌های alpha4 حفظ شده‌اند: موجودی منفی/تغییر روش پس از گردش/recost تاریخی نیست، aging فعلی است، هزینه جانبی خرید یک طلبکار دارد و فاکتور خارجی قدیمی بدون snapshot نیازمند مهاجرت اختصاصی است. اکنون بستن موجودی ادواری با مرحله۱۱ اضافه شد.
8. پیامک/ایمیل واقعی، HTTPS عملیاتی، سازگاری افزونه‌های ثالث، بار سنگین، گزارش قانونی رسمی و تفکیک نهایی theme/plugin آزموده/اجرا نشده‌اند. حقوق و دارایی ثابت هنوز ماژول ندارند؛ ثبت دستی استهلاک در تست، به‌معنی وجود موتور دارایی نیست.

## تصمیم‌های معماری

بازنویسی عمومی انجام نشد؛ FinanceController در کنترلر تراکنشی موجود ادغام و مدل‌های جدید افزایشی شدند. ذخیره BLOB برای تصویر محدود هزینه، وابستگی به فایل عمومی و تنظیم وب‌سرور را حذف می‌کند؛ انتقال احتمالی در ماژول عمومی فایل‌ها باید داده را حفظ کند. بستن با run مستقل، snapshot و sourceهای واقعی طراحی شد تا بازگشایی، حمل تفصیلی و rollback قابل اثبات باشد. مبدأهای خودکار اجازه سند دستی اضافه نمی‌کنند؛ dashboard.view نیز مجوز خواندن مالی را گسترش نمی‌دهد.

## نصب و ارتقا

فایل agah-accounting-3.0.0-alpha5.zip **قالب قابل نصب** است؛ review ZIP قالب نیست. از نمایش←پوسته‌ها←افزودن←بارگذاری پوسته نصب شود. ارتقا همان پوشه agah-accounting را جایگزین می‌کند؛ ابتدا backup هماهنگ فایل/DB/کلید بگیرید و در سایت آزمایشی بررسی کنید. کلید رمزنگاری و salt قبلی تغییر نکنند. Schema6 شش جدول و یک ایندکس افزایشی می‌افزاید؛ هیچ شرکت یا عدد مالی seed نمی‌شود. داده قبلی حفظ و نسخه DB فقط پس از موفقیت ثبت می‌شود؛ downgrade خودکار نداریم.

سرفصل و طبقه حساب/ابعاد/شخص را با حسابدار بازبینی کنید. بستن از صفحه مخصوص با آخرین دوره باز و نبود پیش‌نویس/مغایرت انجام شود؛ از تغییر وضعیت عمومی برای دورزدن بازگشایی استفاده نکنید. چیدمان منو در سفارشی‌ساز بخش «منوی سامانه حسابداری» و با حق مدیر سایت انتخاب می‌شود.

## ادامه پروژه

**شش مرحله باقی است:۱۳ تا۱۸.** بسته بعدی۱۳–۱۵: پیوست عمومی، حقوق و دستمزد، دارایی ثابت. سپس۱۶–۱۸: گزارش قانونی، پشتیبان/پایش/انتشار و ظاهر نهایی. HANDOFF-NEXT مبنای گفتگوی تازه و کم‌مصرف است؛ انتخاب پیامک و روش ذخیره backup در مرحله مربوط، و قابلیت خارج طرح با تأیید جداگانه باشد. تمام تصاویر خصوصی/اسناد و قیود مالی حفظ شوند.

## فایل‌های جدید/تغییرکرده

- `CHANGELOG.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `HANDOFF-NEXT.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `README.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `REPORT-10-12.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `changelog.txt` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/ARCHITECTURE.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/CONTRACTS-10-12.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/DB-SCHEMA.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/FILE-MAP.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/INSTALL.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/PLUGIN-SPLIT.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/README.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/ROADMAP.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/SECURITY.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/TESTING.md` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `docs/test-results/phase-10-12/browser-finance-final.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/clean-final-code-install.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/clean-install.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/clean-integration.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/clean-smoke.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/concurrency-finance.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/integration-final.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/js-syntax.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/php-lint.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/run-all.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/upgrade-install.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `docs/test-results/phase-10-12/upgrade-preservation.log` — خروجی خام واقعی آزمون یا نصب/ارتقا
- `erp/assets/erp.css` — CSS محلی داشبورد، نمودار و منوی ریسپانسیو
- `erp/bootstrap.php` — اتصال ماژول جدید به بارگذار/کنترلر مشترک
- `erp/src/Core/BusinessSchema.php` — ایندکس شرکت/وضعیت/تاریخ/نوع فاکتور
- `erp/src/Core/FinanceSchema.php` — شش جدول جدید و FKهای مرکب مالی/تصویر/بستن
- `erp/src/Core/Schema.php` — Schema6 و اتصال DDL/FK افزایشی
- `erp/src/Http/FinanceController.php` — HTTP، فایل خصوصی، خروجی و اتصال PRG
- `erp/src/Http/ModuleController.php` — اتصال ماژول جدید به بارگذار/کنترلر مشترک
- `erp/src/Http/Navigation.php` — منوی گروهی مجاز و چیدمان top/sidebar
- `erp/src/Http/TradeController.php` — اتصال ماژول جدید به بارگذار/کنترلر مشترک
- `erp/src/Modules/Accounting/ClosingService.php` — تعدیل ادواری، بستن حساب موقت، حمل تفصیلی و بازگشایی
- `erp/src/Modules/Accounting/FinancialService.php` — صورت‌های مالی واقعی، تطبیق و گزارش مانده اشخاص
- `erp/src/Modules/Accounting/FiscalService.php` — جلوگیری از دورزدن بستن مالی با تغییر ساده سال/دوره
- `erp/src/Modules/Accounting/VoucherService.php` — کنترل منبع و مجوز هزینه/بستن؛ سقف سند خودکار۵۰۰۰
- `erp/src/Modules/Dashboard/DashboardService.php` — تجمیع ماهانه، اعلان و جست‌وجوی مجوزمحور
- `erp/src/Modules/Expenses/ExpenseService.php` — سرفصل، ابعاد، شناسایی/تسویه/ابطال و تصویر خصوصی
- `erp/views/finance-closing.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-dashboard.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-expense-document.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-expenses.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-lookups.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-notifications.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-parties.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-payment-fields.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-search.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/finance-statements.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/legacy-viewCompany.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `erp/views/settings.php` — نمای مستقل فارسی با فرم/داده واقعی و escape
- `functions.php` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `inc/customizer.php` — تنظیم چیدمان منو با مجوز مدیر سایت
- `readme.txt` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `style.css` — مستندات، نسخه، قرارداد و محدودیت/ادامه
- `tests/finance-browser-fixture.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/finance-control.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/integration/business.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/integration/core.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/integration/finance-concurrency-setup.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/integration/finance-concurrency-worker.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/integration/finance-concurrency.py` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/integration/finance.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/run-all.sh` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/run.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/security/finance-browser.cjs` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی
- `tests/upgrade-finance.php` — آزمون سناریو، fixture خصوصیِ کدنویسی‌شده یا runner؛ بدون رمز واقعی

## خروجی خام نهایی

لاگ اجرای یک‌دستوری با تعداد زمان خودش، نصب مستقل، smoke، ارتقا و syntax به‌صورت فایل جدا در docs/test-results/phase-10-12 هستند. در ادامه خروجی آخرین مجموعه PHP، مرورگر مالی، رقابت مالی و حفظ دادهٔ ارتقا آمده است. تعدادهای قدیمی با نهایی جایگزین یا مخفی نشده‌اند.

### integration-final.log

```text
PASS RFC6238 SHA1 timestamp 59
PASS RFC6238 SHA1 timestamp 1111111109
PASS RFC6238 SHA1 timestamp 1111111111
PASS RFC6238 SHA1 timestamp 1234567890
PASS RFC6238 SHA1 timestamp 2000000000
PASS RFC6238 SHA1 timestamp 20000000000
PASS TOTP wrong format rejected
PASS TOTP current/adjacent steps and expiry
PASS Base32 random key uses 32 valid symbols
PASS Password short/no letter/no number rejected
PASS Money accepts Persian digits and exact toman fraction
PASS Money overflow and fractions rejected
PASS Encryption authentication detects tampering
PASS Jalali leap day and roundtrip
PASS Upgrade preserves baseline rows and installs business tables
PASS Schema upgrade repeatability preserves rows
PASS Idempotency claim complete and replay result
PASS Token payload substitution and company/user tampering rejected
PASS Token rollback releases claim and domain change
PASS Unsigned and expired form token rejected
PASS Idempotency requires transaction
PASS Rate limit exact cap and window expiry
PASS Login errors identical for invalid username/password
PASS Login IP+user throttle also covers email alias
PASS Login IP aggregate throttles many distinct usernames
PASS New session has no second factor marker
PASS Idle session destroys only expired token
PASS TOTP enrollment requires correct password
PASS Pending secret encrypted and bound to session
PASS Enable verifies first code and creates eight hashed backup codes
PASS TOTP initial code replay is rejected
PASS TOTP next step accepted once; replay rejected
PASS Backup code is consumed exactly once
PASS Other WP session cannot inherit verified factor
PASS Require2fa company policy applied
PASS TOTP brute force bounded
PASS TOTP disable requires password and invalidates marker
PASS SMS disabled without selected provider
PASS SMS code stored hashed and bound to session; one-time use
PASS SMS expires after two minutes
PASS SMS five failed attempts block correct code
PASS SMS hourly send cap enforced
PASS Cannot remove/downgrade last active company admin
PASS Member existing user added with scoped role
PASS Custom role matrix saves exact caps and audits
PASS System role editing/deleting rejected
PASS Removed member history retained; no WordPress user deleted
PASS Company edits encrypt national identifier and preserve metadata
PASS Detail create/update/read persists
PASS Duplicate detail code rejected
PASS Unused custom account structure can update
PASS Balanced draft saved without number and excluded from ledger
PASS Draft imbalance allowed; approval rejected
PASS Both debit and credit in one line rejected
PASS Non-leaf and incompatible details rejected
PASS Float money rejected and no partial voucher persists
PASS Approval allocates number and journals balance
PASS Approved voucher cannot become unbalanced by edit
PASS Optimistic revision rejects stale edit
PASS Finalize locks contents and physical deletion
PASS Reopen requires reason and keeps number
PASS Detail with turnover cannot delete
PASS Void retains number and excludes journal
PASS System post creates approved source-linked voucher
PASS System duplicate source/manual edit/void rejected
PASS System void returns effect from journal
PASS Account ledger opening and cumulative closing from real entries
PASS Trial balance two/four columns and general/subsidiary all balance
PASS Ledger pagination carries previous page running balance
PASS Closed period blocks create and edit of existing voucher
PASS Year with draft cannot close; no-draft closes and reopens
PASS Approval rechecks account activation after draft creation
PASS Audit intact after all operations; national id masked
PASS Foreign company context always NotFound
PASS Foreign account line rejected before DB mutation
PASS Company-scoped detail/report/member IDOR rejected
PASS Voucher foreign id get/edit/state/delete all NotFound
PASS Service company argument cannot override current context
PASS Viewer server denies company_settings.edit
PASS Viewer server denies member.create
PASS Viewer server denies member.edit
PASS Viewer server denies role.edit
PASS Viewer server denies detail.create
PASS Viewer server denies detail.delete
PASS Viewer server denies voucher.create
PASS Viewer server denies voucher.edit
PASS Viewer server denies voucher.approve
PASS Viewer server denies voucher.finalize
PASS Viewer server denies voucher.void
PASS Viewer server denies voucher.reopen
PASS Viewer server denies voucher.delete
PASS Viewer can read vouchers and real ledger
PASS Role matrix exact capabilities company_admin
PASS Role matrix exact capabilities accountant
PASS Role matrix exact capabilities cashier
PASS Role matrix exact capabilities storekeeper
PASS Role matrix exact capabilities salesperson
PASS Role matrix exact capabilities viewer
PASS DB rejects cross-company role assignment
PASS No new business foreign key bypass: voucher detail of foreign company rejected by DB
PASS Business schema all composite foreign keys installed
PASS National check digits reject repeated and invalid personal IDs
PASS Party encrypts national ID, blind index and public hint only
PASS Duplicate national ID rejected and counter rollback leaves no party
PASS Party name and active status update its linked detail atomically
PASS Sensitive reveal requires capability and creates masked audit
PASS Seeded tax is unknown and cannot issue taxable snapshot
PASS Tax snapshot uses date and half-up per-line integer rounding
PASS Overlapping tax dates and out-of-range percentage rejected
PASS Goods/service price fields persist as exact Rial integers
PASS Referenced unit deletion and duplicate barcode rejected
PASS IBAN rejects bad checksum and account has dedicated detail
PASS Receipt posts balanced automatic source voucher and bank balance
PASS Party with posted movement cannot delete; statement matches its ledger
PASS Transfer changes both accounts and preserves aggregate cash
PASS Same-account transfer and cash-to-bank method mismatch rejected
PASS Pending cheque affects notes receivable and forecast, not bank
PASS Collected cheque moves notes to bank
PASS Stale cheque revision and invalid backwards date rejected
PASS Returned collected cheque reverses bank and restores party claim
PASS Void document reverses all event vouchers and original with no residual effect
PASS Partial multi-item settlement sums to allocated invoice amount
PASS Over-settlement rolls back number, document and voucher atomically
PASS Returned cheque releases only its allocation and retains cash settlement
PASS Void settlement document releases all remaining allocations
PASS Changing tax rate does not mutate stored invoice-line snapshot
PASS Bank reconciliation uses matched real ledger lines and shows zero difference
PASS Cash account cannot be reconciled as a bank
PASS Cashier can post receipt without generic manual-voucher permission
PASS Cashier cannot reveal national identity or confirm tax rates
PASS Cross-company party/account/item/tax inputs rejected by services
PASS Outgoing payment cheque collection/return restores payable and cash
PASS Final source voucher blocks full void and rolls back earlier event reversals
PASS Credit limit warning equals the real receivable-detail ledger balance
PASS Bank reconciliation rejects a same-company line from another treasury account
PASS DB composite FK rejects foreign parent: fk_b_parties_detail_id
PASS DB composite FK rejects foreign parent: fk_b_items_unit_id
PASS DB composite FK rejects foreign parent: fk_b_items_group_id
PASS DB composite FK rejects foreign parent: fk_b_items_tax_rate_id
PASS DB composite FK rejects foreign parent: fk_b_items_sale_account_id
PASS DB composite FK rejects foreign parent: fk_b_items_purchase_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_accounts_detail_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_accounts_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_party_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_source_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_target_account_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_fiscal_year_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_docs_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_doc_items_doc_id
PASS DB composite FK rejects foreign parent: fk_b_treasury_doc_items_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_doc_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_doc_item_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_party_id
PASS DB composite FK rejects foreign parent: fk_b_cheques_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_cheque_events_cheque_id
PASS DB composite FK rejects foreign parent: fk_b_cheque_events_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_party_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_fiscal_year_id
PASS DB composite FK rejects foreign parent: fk_b_invoices_voucher_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_invoice_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_item_id
PASS DB composite FK rejects foreign parent: fk_b_invoice_lines_tax_rate_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_invoice_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_doc_id
PASS DB composite FK rejects foreign parent: fk_b_settlements_doc_item_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliations_treasury_account_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliation_items_reconciliation_id
PASS DB composite FK rejects foreign parent: fk_b_bank_reconciliation_items_voucher_line_id
PASS Business audit chain intact and all approved vouchers balanced
PASS Trade allocation preserves every Rial including zero weights and rounding
PASS Proforma and sales order issue without accounting or inventory movement
PASS Repeated conversion and stale draft revisions rejected
PASS Purchase capitalizes net plus allocated freight and keeps input VAT separate
PASS Costing method and goods accounting mode cannot change after movement
PASS Sale uses four decimals, per-line rounding, exact discounts and cost-of-sales
PASS Issued invoice keeps tax snapshot when rate changes
PASS Insufficient stock rolls back vouchers, invoice number and every stock move
PASS Purchase cannot be voided after dependent inventory movement
PASS Full linked sale return restores original cost and original tax, capped by source qty
PASS Return void restores remaining return entitlement and exact inventory value
PASS Treasury allocation sees actual invoice balance and disallows overpayment
PASS Invoice void reverses its treasury settlement, source voucher and inventory atomically
PASS Warehouse transfer preserves exact company value and destination cost
PASS Stocktake treats input as counted stock and posts shortage adjustment
PASS Minimum alert and kardex use real counted quantities and running values
PASS Purchase return removes inventory and input VAT with balanced supplier reversal
PASS FIFO consumes oldest layer then partial next layer at exact cost
PASS FIFO void restores layer quantities and values without deleting picks
PASS Backdated stock entry rejected instead of silently recosting history
PASS Invoice issue applies advance and immediate cash in one transaction
PASS Paid sale return refunds through receivables rather than supplier payables
PASS Void frees advance and reverses its allocation voucher but preserves original advance
PASS Unconfirmed tax prevents draft pricing and leaves no invoice or lines
PASS Foreign warehouse item invoice and company are rejected at public services
PASS Salesperson issues own automatic invoice without manual voucher permission
PASS Salesperson cannot issue purchase or stock document or void issued sale
PASS Sales and purchase reports group actual net rows and aging uses real balance
PASS Trade audit chains and all approved documents remain balanced
PASS Three partial returns sum exactly to original rounded amount and discount
PASS Changing catalog kind or deleting item with stock-only history is forbidden
PASS Trade DB composite FK rejects foreign parent: fk_t_invoices_parent_id
PASS Trade DB composite FK rejects foreign parent: fk_t_invoice_lines_source_line_id
PASS Trade DB composite FK rejects foreign parent: fk_t_invoice_lines_warehouse_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_docs_fiscal_year_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_docs_voucher_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_warehouse_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_item_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_invoice_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_invoice_line_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_moves_stock_doc_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_layers_move_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_layers_warehouse_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_layers_item_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_picks_move_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_picks_layer_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_minimums_warehouse_id
PASS Trade DB composite FK rejects foreign parent: fk_t_stock_minimums_item_id
PASS Trade DB composite FK rejects foreign parent: fk_t_invoice_advances_invoice_id
PASS Trade DB composite FK rejects foreign parent: fk_t_invoice_advances_doc_id
PASS Periodic purchase posts purchases and maintains physical value without perpetual COGS
PASS Final invoice source prevents void and rolls back related settlement changes
PASS Cross-company invoice reads and wrong system-voucher source are rejected
PASS Invalid immediate settlement rolls back issued invoice, voucher and stock
PASS Changed tax requires draft review before issue instead of silently changing amount
PASS Issued print snapshot preserves party name without encrypted or plaintext identity
PASS Reversing original receipt after return refund restores full debt including cash refunded
PASS Accrued expense posts payable and cost center without cash movement
PASS Partial expense payment creates treasury linkage and exact unpaid remainder
PASS Returned expense cheque restores only its own settlement balance
PASS Overpayment and mismatched organizational dimension roll back atomically
PASS Income posts receivable and partial receipt without changing recognition
PASS Private image bytes persist exactly and are absent from audit payload
PASS SVG, false MIME and oversized image rejected before storage
PASS Expense report filters actual category, party, project and sums
PASS Indirect cashflow separates capital cash and excludes entirely noncash asset purchase
PASS Real dashboard and scoped search derive ledger and documents, without template sample values
PASS Draft voucher prevents closing before any financial changes
PASS Closing posts temporary/result/closing/opening and keeps every carried detail exact
PASS Closed-year statements retain profit and next-year balance includes carry once
PASS Manual reopening or period edit cannot bypass financial year closure
PASS Controlled reopening voids every dependent closing voucher and preserves original income
PASS Next-year business activity blocks reopening with original year still closed
PASS Periodic close adjusts inventory and COGS from real stock value before profit transfer
PASS Foreign category dimension receipt image and financial company are inaccessible
PASS Viewer cannot create expense, attach image or close year despite read permission
PASS Finance audit chain remains intact after closing/reopening and image operations
PASS Balance sheet shows actual discrepancy when ledger rows are corrupted
PASS Finance composite FK rejects foreign parent: fk_f_cost_dimensions_detail_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_categories_account_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_docs_category_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_docs_fiscal_year_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_docs_party_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_docs_treasury_account_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_docs_project_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_docs_branch_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_docs_center_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_docs_voucher_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_images_expense_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_settlements_expense_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_settlements_doc_id
PASS Finance composite FK rejects foreign parent: fk_f_expense_settlements_doc_item_id
PASS Finance composite FK rejects foreign parent: fk_f_year_closings_fiscal_year_id
PASS Finance composite FK rejects foreign parent: fk_f_year_closings_next_year_id
PASS Finance composite FK rejects foreign parent: fk_f_year_closings_inventory_voucher_id
PASS Finance composite FK rejects foreign parent: fk_f_year_closings_profit_voucher_id
PASS Finance composite FK rejects foreign parent: fk_f_year_closings_result_voucher_id
PASS Finance composite FK rejects foreign parent: fk_f_year_closings_closing_voucher_id
PASS Finance composite FK rejects foreign parent: fk_f_year_closings_opening_voucher_id
PASS Failure at permanent-account closing rolls back prior profit vouchers and new year
PASS Final closing voucher blocks reopening and rolls back opening reversal
PASS Search preserves spaces and never crosses company or leaks unavailable resources
PASS Dashboard and global search do not infer financial read permission from dashboard access
PASS Indirect cashflow adds back actual depreciation without inventing cash movement
PASS Global search accepts a single Persian invoice number
PASS Financial page defaults to defined previous year when no current fiscal year exists

RESULT: 275 passed; 0 failed; 0 skipped
Success: All selected tests executed.
```

### browser-finance-final.log

```text
PASS Render finance route dashboard
PASS Render finance route expenses
PASS Render finance route expense_categories
PASS Render finance route cost_dimensions
PASS Render finance route financials
PASS Render finance route financial_parties
PASS Render finance route year_closing
PASS Render finance route notifications
PASS Render finance route global_search
PASS Navigation is grouped and permission-filtered
PASS Dashboard contains real cards and local SVG charts
PASS Notifications show overdue cheque invoice stock shortage and tax review
PASS Global search preserves spaces and returns only own company
PASS Organizational dimension form creates real project
PASS Expense category form validates and saves actual ledger account
PASS Expense UI issues partial-paid document and links source voucher
PASS Expense remaining payment records real treasury effect
PASS Receipt image upload is private and downloads exact PNG bytes
PASS Receipt download without nonce and foreign expense GET are rejected
PASS Financial comparison calculates actual equal periods and zero discrepancy
PASS Finance CSV endpoints download and require separate export nonce
PASS Expense void reverses original and both payment records atomically
PASS Foreign expense POST cannot reuse an otherwise valid own-company form
PASS Year closing UI posts carry and controlled reopening restores year
PASS Viewer cannot reach closing or mutate expense and cannot see upload form
PASS Site menu preference switches top and sidebar while preserving role groups
PASS Dashboard mobile is RTL bounded and menu opens and closes
RESULT: 27 passed; 0 failed; 0 skipped
```

### concurrency-finance.log

```text
PASS concurrent finance pay commits exactly once
PASS concurrent finance close commits exactly once
PASS no overpayment or duplicate active year closing
PASS carried details equal closing balances and audit is valid
PASS failed competing finance operations leave gap-free numbers
RESULT: 5 passed; 0 failed; 0 skipped
```

### upgrade-preservation.log

```text
PASS upgrade preserves warehouses (4 rows)
PASS upgrade preserves stock_docs (5 rows)
PASS upgrade preserves stock_moves (12 rows)
PASS upgrade preserves stock_layers (3 rows)
PASS upgrade preserves stock_picks (2 rows)
PASS upgrade preserves stock_minimums (1 rows)
PASS upgrade preserves invoice_advances (1 rows)
PASS upgrade preserves parties (7 rows)
PASS upgrade preserves units (9 rows)
PASS upgrade preserves item_groups (2 rows)
PASS upgrade preserves tax_rates (12 rows)
PASS upgrade preserves items (7 rows)
PASS upgrade preserves treasury_accounts (6 rows)
PASS upgrade preserves treasury_docs (22 rows)
PASS upgrade preserves treasury_doc_items (24 rows)
PASS upgrade preserves cheques (8 rows)
PASS upgrade preserves cheque_events (26 rows)
PASS upgrade preserves invoices (25 rows)
PASS upgrade preserves invoice_lines (27 rows)
PASS upgrade preserves settlements (10 rows)
PASS upgrade preserves bank_reconciliations (2 rows)
PASS upgrade preserves bank_reconciliation_items (4 rows)
PASS upgrade preserves companies (9 rows)
PASS upgrade preserves roles (55 rows)
PASS upgrade preserves role_caps (3143 rows)
PASS upgrade preserves company_members (13 rows)
PASS upgrade preserves settings (8 rows)
PASS upgrade preserves fiscal_years (9 rows)
PASS upgrade preserves fiscal_periods (108 rows)
PASS upgrade preserves accounts (784 rows)
PASS upgrade preserves details (16 rows)
PASS upgrade preserves vouchers (66 rows)
PASS upgrade preserves voucher_lines (144 rows)
PASS upgrade preserves sequences (31 rows)
PASS upgrade preserves audit_log (294 rows)
PASS upgrade preserves idempotency (1 rows)
PASS upgrade preserves auth_states (1 rows)
PASS upgrade preserves rate_limits (31 rows)
PASS upgrade preserves login_otp (1 rows)
PASS upgrade preserves audit_heads (10 rows)
PASS upgrade preserves schema_migrations (2 rows)
RESULT: 41 preserved tables; 0 failed
```
