<?php
if(!defined('ABSPATH')) exit; $cat = agah_primary_category(); ?>
<article <?php post_class( 'card' ); ?>>
	<a class="thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php if ( has_post_thumbnail() ) the_post_thumbnail( 'agah-card', array( 'loading' => 'lazy' ) ); ?></a>
	<div class="body">
		<?php if ( $cat ) : ?><a class="chip-cat" href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a><?php endif; ?>
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<p><?php echo esc_html( get_the_excerpt() ); ?></p>
		<div class="meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time> <span aria-hidden="true">•</span> <?php echo esc_html( agah_reading_time() ); ?></div>
	</div>
</article>
