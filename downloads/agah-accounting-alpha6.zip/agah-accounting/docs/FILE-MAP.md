# نقشهٔ فایل‌ها — alpha3

برای ادامهٔ کم‌حجم از HANDOFF-NEXT.md و قراردادهای ۴–۶ آغاز کنید.

## erp/src/Core

- `erp/src/Core/Access.php`
- `erp/src/Core/Audit.php`
- `erp/src/Core/Business.php`
- `erp/src/Core/BusinessSchema.php`
- `erp/src/Core/Crypto.php`
- `erp/src/Core/Ctx.php`
- `erp/src/Core/Db.php`
- `erp/src/Core/Errors.php`
- `erp/src/Core/Idempotency.php`
- `erp/src/Core/Jalali.php`
- `erp/src/Core/Money.php`
- `erp/src/Core/Request.php`
- `erp/src/Core/Schema.php`
- `erp/src/Core/Sequence.php`
- `erp/src/Core/Settings.php`

## erp/src/Security

- `erp/src/Security/Auth.php`
- `erp/src/Security/Caps.php`
- `erp/src/Security/RateLimiter.php`
- `erp/src/Security/SmsOtp.php`
- `erp/src/Security/SmsProvider.php`
- `erp/src/Security/Totp.php`
- `erp/src/Security/TwoFactor.php`

## erp/src/Modules

- `erp/src/Modules/Accounting/AccountService.php`
- `erp/src/Modules/Accounting/ChartSeed.php`
- `erp/src/Modules/Accounting/DetailService.php`
- `erp/src/Modules/Accounting/FiscalService.php`
- `erp/src/Modules/Accounting/ReportService.php`
- `erp/src/Modules/Accounting/VoucherService.php`
- `erp/src/Modules/Catalog/CatalogService.php`
- `erp/src/Modules/Company/CompanyService.php`
- `erp/src/Modules/Company/MemberService.php`
- `erp/src/Modules/Parties/PartyService.php`
- `erp/src/Modules/Treasury/TreasuryService.php`

## erp/src/Http

- `erp/src/Http/CommerceController.php`
- `erp/src/Http/ModuleController.php`
- `erp/src/Http/Page.php`
- `erp/src/Http/SecurityController.php`

## erp/views

- `erp/views/audit.php`
- `erp/views/business-cash.php`
- `erp/views/business-catalog.php`
- `erp/views/business-cheques.php`
- `erp/views/business-docs.php`
- `erp/views/business-parties.php`
- `erp/views/business-party.php`
- `erp/views/business-reconciliation.php`
- `erp/views/business-treasury-accounts.php`
- `erp/views/business-treasury-document.php`
- `erp/views/business-treasury-form.php`
- `erp/views/business-treasury-row.php`
- `erp/views/details.php`
- `erp/views/legacy-pageAccounts.php`
- `erp/views/legacy-pageAudit.php`
- `erp/views/legacy-pageDashboard.php`
- `erp/views/legacy-pageFiscal.php`
- `erp/views/legacy-viewCompany.php`
- `erp/views/legacy-viewHome.php`
- `erp/views/legacy-viewLogin.php`
- `erp/views/members.php`
- `erp/views/reports.php`
- `erp/views/roles.php`
- `erp/views/security/account.php`
- `erp/views/settings.php`
- `erp/views/voucher-form.php`
- `erp/views/voucher-line.php`
- `erp/views/voucher-view.php`
- `erp/views/vouchers.php`

## erp/assets

- `erp/assets/commerce.js`
- `erp/assets/erp.css`
- `erp/assets/forms.js`

## tests

- `tests/browser-control.php`
- `tests/browser-fixture.php`
- `tests/integration/business-concurrency-setup.php`
- `tests/integration/business-concurrency-worker.php`
- `tests/integration/business-concurrency.py`
- `tests/integration/business.php`
- `tests/integration/concurrency-setup.php`
- `tests/integration/concurrency-worker.php`
- `tests/integration/concurrency.py`
- `tests/integration/core.php`
- `tests/migration.php`
- `tests/run-all.sh`
- `tests/run.php`
- `tests/security/access.php`
- `tests/security/browser.cjs`
- `tests/security/business-browser.cjs`
- `tests/smoke.php`
- `tests/unit/security.php`

## docs

- `docs/ARCHITECTURE.md`
- `docs/CONTRACTS-4-6.md`
- `docs/DB-SCHEMA.md`
- `docs/DEPENDENCIES.md`
- `docs/FILE-MAP.md`
- `docs/INSTALL.md`
- `docs/PLUGIN-SPLIT.md`
- `docs/README.md`
- `docs/ROADMAP.md`
- `docs/SECURITY.md`
- `docs/TESTING.md`

## افزوده‌های alpha4

- erp/src/Core/TradeSchema.php: هفت جدول جدید، FKها و grants افزایشی.
- erp/src/Core/TradeMath.php: تخصیص ریال و برگشت تجمعی بدون float.
- erp/src/Modules/Trade/InvoiceService.php: فاکتور/تبدیل/صدور/برگشت/ابطال/پیش‌پرداخت/گزارش.
- erp/src/Modules/Inventory/StockService.php: انبار، FIFO/میانگین، انتقال/شمارش/کاردکس و تطبیق.
- erp/src/Http/TradeController.php: ورودی‌های HTTP، مجوز، PRG و CSV.
- erp/views/trade-*.php: لیست/فرم/خط/سند چاپی/فیلتر/aging/گزارش.
- erp/views/stock-*.php: انبار/گردش/خط/موجودی و کاردکس.
- tests/integration/trade.php و trade-concurrency*: آزمون دامنه/مجوز/FK و چندفرایندی.
- tests/trade-browser-fixture.php و tests/security/trade-browser.cjs: رابط واقعی و فایل PDF آزمایشی.
- tests/upgrade-trade.php: حفظ هش ستون‌های قدیمی در ارتقای Schema 4→5.
- REPORT-7-9.md و HANDOFF-NEXT.md: گزارش جاری و مبنای ادامهٔ کم‌حجم.

## فایل‌های alpha5

- Core/FinanceSchema.php: شش جدول، قیود و روابط افزایشی.
- Modules/Expenses/ExpenseService.php: دسته/ابعاد، شناسایی و تسویه، تصویر خصوصی و گزارش.
- Modules/Accounting/FinancialService.php: P&L، ترازنامه، جریان نقد غیرمستقیم و بدهکار/بستانکار.
- Modules/Accounting/ClosingService.php: تعدیل ادواری، بستن حساب‌ها، حمل و بازگشایی.
- Modules/Dashboard/DashboardService.php: تجمیع ماهانه، هشدارهای مشتق‌شده و جست‌وجوی مجوزمحور.
- Http/FinanceController.php و Navigation.php: HTTP/خروجی خصوصی و منوی گروهی.
- views/finance-*.php: ده نمای مستقل فرم/گزارش/داشبورد/منو/اعلان.
- inc/customizer.php: انتخاب سراسری منوی بالا/کناری با مجوز مدیر سایت.
- tests/integration/finance.php و finance-concurrency*: آزمون‌های مالی و رقابت.
- tests/finance-browser-fixture.php، finance-control.php و security/finance-browser.cjs: آزمون رابط و چیدمان.
- tests/upgrade-finance.php: حفظ داده در ارتقای واقعی Schema5→6.
- REPORT-10-12.md و HANDOFF-NEXT.md: گزارش و مبنای ادامه.

## فایل‌های alpha6

- Core/OperationsSchema.php:۹جدول وFK/seedافزایشی.
- Modules/Files/FileService.php: ذخیرهخصوصی،اعتبارسنجیMIME/GD/PDF،capمبدأ،جستجو/حذف.
- Modules/Payroll/PayrollMath.php وPayrollService.php:محاسبهصحیح،پرسنل/قرارداد/کارکرد/پارامتر/فیش/سند/ابطال/گزارش.
- Modules/Assets/AssetMath.php وAssetService.php:روشماهانه/خرید/استهلاک/واگذاری/دفتر/ابطال.
- Http/OperationsController.php وviews/operations-*.php:دهصفحه،PRG/آپلود/خروجیخصوصی/CSV/چاپ.
- VoucherService.php:مبدأpayroll/asset_*؛ ClosingService.php:گردشدارایی/FYمقصدحتیرویدادصفر.
- tests/integration/operations.php وoperations-concurrency*؛ operations-browser-fixture.php، security/operations-browser.cjs وupgrade-operations.php:آزمون دامنه/HTTP/رقابت/حفظداده.
- REPORT-13-15.md،HANDOFF-NEXT.md،CONTRACTS-13-15.md وtest-results/phase-13-15:تحویلجاری.
