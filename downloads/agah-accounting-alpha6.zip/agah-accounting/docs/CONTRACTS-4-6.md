# قراردادهای مراحل ۴ تا ۶

## سرویس‌ها

همهٔ `cid`ها باید با Ctx جاری برابر باشند. ورودی سرویس، مبلغ **int ریال** و تاریخ ISO میلادی است؛ مرز HTTP تومان/شمسی را تبدیل می‌کند. تغییرات زیر Access::write، قفل شرکت و ممیزی‌اند. خواندن‌های عمومی به cap منبع نیاز دارند.

- `PartyService::save(cid,id,in)` شخص و تفصیلی kind=party را هم‌زمان نگه می‌دارد. id=0 کد P000001 و ... می‌دهد. کلیدهای in: name,kind(real/legal),is_customer,is_supplier,is_active,national_id,clear_national_id,economic_code,phone,email,address,credit_limit. شناسهٔ خالی قبلی را حفظ می‌کند؛ حذف صریح لازم است. `get/page` هرگز ciphertext/index را بازنمی‌گردانند. `reveal` مجوز party.sensitive و ممیزی دارد و پاسخ نه در URL، نه transient قرار می‌گیرد. `statement(cid,id,from,to,page)` ماندهٔ کل تفصیلی را می‌دهد؛ کنترل سقف فقط مجموع دریافتنی و اسناد دریافتنی است و بدهی به همان شخص از آن کسر نمی‌شود.
- `CatalogService::save(cid,type,id,in)` type=unit/group/item/tax. کالا kind=goods/service، قیمت int، واحد و حساب‌های معین فعال دارد. نرخ bp بین ۰ و ۱۰۰۰۰، تاریخ valid_from/to و confirmed دارد؛ هم‌پوشانی همان code رد می‌شود. تأیید tax_rate.confirm مستقل است. نرخ اولیه bp=NULL/تأییدنشده است. `taxSnapshot(cid,rateId,date,net)` نرخ هم‌کد مؤثر در تاریخ را resolve و id/name/bp/amount خط را برمی‌گرداند؛ caller باید خروجی را روی خط ذخیره کند. ویرایش نرخ، snapshot ذخیره‌شده را تغییر نمی‌دهد.
- `TreasuryService::saveAccount(cid,id,in)` بانک/صندوق/تنخواه و تفصیلی انحصاری آن را می‌سازد؛ ماندهٔ اولیهٔ مستقل ندارد. `ledger(cid,account,to,page)` از دفتر کل می‌خواند، شامل سند دستی/افتتاحیهٔ مجاز.
- `issue(cid,header,items,allocations)` مستقیم issued است؛ kind.create مجوز صدور این برگه و **فقط سند خودکار منبع خودش** است. header: kind(receipt/payment/transfer), doc_date,party_id,advance,description؛ انتقال: source_account_id,target_account_id,amount. هر item: method(cash/card/transfer/cheque),treasury_account_id,amount,reference؛ چک: cheque_no,due_date,bank_name. انتقال بین دو حساب متفاوت است؛ نقد به صندوق/تنخواه و کارت/حواله/چک به بانک محدود است.
- allocations آرایهٔ invoice_id,amount است؛ بر حسب ترتیب اقلام به قطعات قابل برگشت تقسیم می‌شود. فقط فاکتور issued هم‌شخص و هم‌نوع با سند approved/final و source_type=`invoice_sale/purchase` و source_id خود فاکتور پذیرفته می‌شود. سقف مانده و جمع برگه زیر قفل کنترل می‌شوند. پیش‌دریافت/پیش‌پرداخت هنوز به فاکتور تخصیص نمی‌گیرد؛ مرحلهٔ فروش/خرید باید فرایند اعمال آن را با سند مناسب اضافه کند.
- `chequeTransition(cid,id,status,date,reason,revision)` مجوز cheque.approve دارد. pending→collected/returned/void؛ collected→returned/void؛ returned→void. تاریخ قبل از برگه/آخرین رویداد ممنوع است؛ دوره باید باز باشد. هر گذار مالی سند منبع cheque_event دارد؛ returned→void صرفاً اداری و بدون سند صفر/ساختگی است. برگشت فقط allocations قلم چک خودش را آزاد می‌کند.
- `voidDocument(cid,id,reason)` مجوز kind.delete؛ اسناد رویدادها، سند برگه، همهٔ تسویه‌ها و وضعیت چک‌ها اتمیک برمی‌گردند. وجود هر سند قطعی مرتبط کل ابطال را رد می‌کند. بعد از ابطال، شماره نگه داشته می‌شود؛ حذف فیزیکی برگه نداریم.
- `reconcile(cid,id,in,matched,revision)` مجوز treasury_account.edit؛ فقط خطوط همان بانک و تا تاریخ صورتحساب قابل تطبیق‌اند. `reconciliation` اختلاف را زنده بازحساب می‌کند: جمع خالص اقلام تطبیق‌شده − ماندهٔ واقعی صورتحساب. صفر بودنِ اختلاف، تضمین صحت انتخاب کاربر یا قفل دفتر نیست.

## قرارداد فاکتور زودتر از UI فروش/خرید

جدول‌های invoices/invoice_lines برای آزمون و اتصال تسویه تعریف شده‌اند. این به‌معنی آماده‌بودن صدور فاکتور نیست؛ UI آن مراحل ۷–۸ است. مدل اولیه دارای kind,status,party,fiscal_year,number,invoice_date,due_date,amount,voucher_id و خطِ item,qty_scaled,unit_price,net_amount,tax snapshot است. تخفیف‌ها، برگشت مرتبط، source stock و قیمت‌گذاری/انبار در مرحلهٔ بعد با migration افزایشی تکمیل شوند. هیچ invoice fixture در نصب عادی ساخته نمی‌شود.

## قفل و حدود

قفل شرکت پیش از شماره/اقلام/تسویه گرفته می‌شود. idempotency HTTP و تمام اثرها در تراکنش مشترک‌اند؛ API داخلی caller نیز باید در تراکنش منبع خودش استفاده شود. گذار روی حساب/تفصیلی غیرفعال ممکن نیست؛ برای تکمیل تعهد قبلی باید رکورد مربوط را با مجوز مناسب فعال کرد. تراز منفی بانک/صندوق در این نسخه ممنوع نشده و باید بازبینی شود؛ سیاست موجودی منفیِ انبار مربوط به مرحلهٔ ۹ است. پیش‌بینی وجه نقد فقط سررسیدهای ثبت‌شده را حساب می‌کند و پیش‌دریافت تخصیص‌نیافته خودکار از فاکتور کسر نمی‌شود.
