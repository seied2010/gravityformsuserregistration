<?php
if(!defined('ABSPATH')) exit; get_header(); ?>
<div class="page-hero"><div class="shell">
	<h1><?php
	if ( is_search() ) echo 'نتایج جستجو برای: ' . esc_html( get_search_query() );
	elseif ( is_archive() ) the_archive_title();
	else echo 'مطالب';
	?></h1>
</div></div>
<div class="shell content-wrap">
	<div>
	<?php if ( have_posts() ) : ?>
		<div class="grid grid-2" style="grid-template-columns:repeat(auto-fill,minmax(260px,1fr))">
			<?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/card' ); endwhile; ?>
		</div>
		<?php agah_pagination(); ?>
	<?php else : ?>
		<div class="entry"><p>مطلبی پیدا نشد.</p><?php get_search_form(); ?></div>
	<?php endif; ?>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
