<?php
/** آزمون ارتقای واقعی Schema 4→5 با هش تمام ستون‌های قدیمی؛ فقط سایت دورریختنی. */
if(!defined('ABSPATH')||!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
use Agah\Erp\Core\{Db,Schema};
$mode=$args[0]??'verify';$path='/tmp/agah-alpha3-snapshot.json';
if($mode==='capture'){
    if(Schema::VERSION!=='4')throw new RuntimeException('Expected alpha3 schema 4');$out=[];
    foreach(Schema::tables() as $table){$cols=Db::col('SHOW COLUMNS FROM '.Db::t($table));$select=implode(',',array_map(function($c){return '`'.str_replace('`','``',$c).'`';},$cols));$rows=Db::rows('SELECT '.$select.' FROM '.Db::t($table));$hashes=[];foreach($rows as $r)$hashes[]=hash('sha256',wp_json_encode($r));sort($hashes);$out[$table]=['columns'=>$cols,'hashes'=>$hashes];}
    file_put_contents($path,wp_json_encode($out));chmod($path,0600);echo 'Captured '.count($out)." alpha3 tables\n";return;
}
if(Schema::VERSION!=='5')throw new RuntimeException('Expected alpha4 schema 5');$data=json_decode(file_get_contents($path),true);$count=0;
foreach($data as $table=>$snapshot){
    if(!in_array($table,Schema::tables(),true))throw new RuntimeException('Unknown table');
    $select=implode(',',array_map(function($c){return '`'.str_replace('`','``',$c).'`';},$snapshot['columns']));$hashes=[];
    foreach(Db::rows('SELECT '.$select.' FROM '.Db::t($table)) as $r)$hashes[]=hash('sha256',wp_json_encode($r));sort($hashes);
    if(in_array($table,['role_caps','schema_migrations'],true)){foreach($snapshot['hashes'] as $h)if(!in_array($h,$hashes,true))throw new RuntimeException('Old row lost '.$table);}elseif($hashes!==$snapshot['hashes'])throw new RuntimeException('Data changed '.$table);
    echo 'PASS upgrade preserves '.$table.' ('.count($hashes)." rows)\n";$count++;
}
if(count(Schema::tables())!==41||Schema::missingForeignKeys())throw new RuntimeException('Missing schema constraints');
echo 'RESULT: '.$count." preserved tables; 0 failed\n";
