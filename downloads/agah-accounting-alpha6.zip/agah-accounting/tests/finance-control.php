<?php
/** کنترل چیدمان فقط برای آزمون CLI محیط دورریختنی؛ هیچ endpoint HTTP نیست. */
if(!defined('ABSPATH')||!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
$mode=$args[0]??'top';if(!in_array($mode,['top','sidebar'],true))throw new RuntimeException('Invalid test mode');set_theme_mod('agah_erp_menu_layout',$mode);echo 'mode='.$mode;
