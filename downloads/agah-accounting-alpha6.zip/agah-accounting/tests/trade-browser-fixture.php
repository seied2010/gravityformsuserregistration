<?php
/** fixture خصوصیِ رابط تجارت؛ فقط سایت تست، بدون انتشار گذرواژه در گزارش. */
if(!defined('ABSPATH')||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
ob_start();require __DIR__.'/browser-fixture.php';$f=json_decode(ob_get_clean(),true);
use Agah\Erp\Core\{Ctx,Db};
use Agah\Erp\Modules\Accounting\AccountService;
use Agah\Erp\Modules\Inventory\StockService;
use Agah\Erp\Modules\Trade\InvoiceService;
use Agah\Erp\Modules\Catalog\CatalogService;
use Agah\Erp\Modules\Parties\PartyService;
use Agah\Erp\Modules\Treasury\TreasuryService;
Ctx::boot($f['uid'],$f['c1']);$cid=$f['c1'];
StockService::configure($cid,'average','inventory');$f['warehouse']=StockService::saveWarehouse($cid,0,['code'=>'W','name'=>'انبار مرورگر','is_active'=>1]);$f['warehouse2']=StockService::saveWarehouse($cid,0,['code'=>'W2','name'=>'انبار دوم مرورگر','is_active'=>1]);
$f['party']=PartyService::save($cid,0,['name'=>'طرف حساب مرورگر تجارت','kind'=>'real','is_active'=>1,'is_customer'=>1,'is_supplier'=>1]);
$unit=(int)Db::val('SELECT id FROM '.Db::t('units').' WHERE company_id=%d LIMIT 1',$cid);
$f['item']=CatalogService::save($cid,'item',0,['name'=>'کالای تجارت مرورگر','code'=>'WEB-TRADE','kind'=>'goods','unit_id'=>$unit,'sale_account_id'=>(int)AccountService::bySysKey($cid,'sales_goods')['id'],'purchase_account_id'=>(int)AccountService::bySysKey($cid,'purchases')['id'],'is_active'=>1]);
$f['bank']=TreasuryService::saveAccount($cid,0,['code'=>'B','name'=>'بانک تجارت مرورگر','kind'=>'bank','is_active'=>1]);
StockService::issue($cid,['kind'=>'receipt','doc_date'=>'2026-10-19'],[['warehouse_id'=>$f['warehouse'],'item_id'=>$f['item'],'qty_scaled'=>1000000,'cost'=>10000]]);
Ctx::boot($f['oid'],$f['c2']);$f['foreign_warehouse']=StockService::saveWarehouse($f['c2'],0,['code'=>'FW','name'=>'انبار بیگانه','is_active'=>1]);$fp=PartyService::save($f['c2'],0,['name'=>'شخص بیگانه تجارت','kind'=>'real','is_customer'=>1,'is_active'=>1]);$fu=(int)Db::val('SELECT id FROM '.Db::t('units').' WHERE company_id=%d LIMIT 1',$f['c2']);$fi=CatalogService::save($f['c2'],'item',0,['code'=>'F','name'=>'خدمت بیگانه','kind'=>'service','unit_id'=>$fu,'sale_account_id'=>(int)AccountService::bySysKey($f['c2'],'sales_services')['id'],'purchase_account_id'=>(int)AccountService::bySysKey($f['c2'],'purchases')['id'],'is_active'=>1]);$f['foreign_invoice']=InvoiceService::save($f['c2'],0,['kind'=>'sale','party_id'=>$fp,'invoice_date'=>'2026-10-19','due_date'=>'2026-10-19'],[['item_id'=>$fi,'qty_scaled'=>10000,'unit_price'=>100]]);
echo wp_json_encode($f);
