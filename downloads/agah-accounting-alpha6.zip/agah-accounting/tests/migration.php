<?php
/** آزمون حفظ تمام ستون‌های قدیمی در ارتقای واقعی alpha1→alpha2؛ snapshot فقط هش سطرها دارد. */
if(!defined('ABSPATH')) exit;
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)throw new RuntimeException('Disposable site required');
use Agah\Erp\Core\{Db,Schema};
$path='/tmp/agah-migration-snapshot.json';$mode=$args[0]??'verify';
if($mode==='capture') {
    if(Schema::VERSION!=='3')throw new RuntimeException('Expected alpha2 schema');
    $data=[];
    foreach(Schema::tables() as $table){
        $cols=Db::col('SHOW COLUMNS FROM '.Db::t($table));
        $select=implode(',',array_map(function($c){return '`'.str_replace('`','``',$c).'`';},$cols));
        $rows=Db::rows('SELECT '.$select.' FROM '.Db::t($table));$hashes=[];
        foreach($rows as $r)$hashes[]=hash('sha256',wp_json_encode($r));sort($hashes);
        $data[$table]=['columns'=>$cols,'hashes'=>$hashes];
    }
    file_put_contents($path,wp_json_encode($data));chmod($path,0600);echo "Captured hashes of 19 alpha2 tables\n";
}else{
    if(Schema::VERSION!=='4')throw new RuntimeException('Expected alpha3 schema 4');
    $data=json_decode(file_get_contents($path),true);$n=0;
    foreach($data as $table=>$snapshot){
        // نام‌ها از snapshot محلی ایجادشده توسط capture می‌آیند، نه endpoint وب.
        if(!in_array($table,Schema::tables(),true))throw new RuntimeException('Unknown table');
        $select=implode(',',array_map(function($c){return '`'.str_replace('`','``',$c).'`';},$snapshot['columns']));
        $rows=Db::rows('SELECT '.$select.' FROM '.Db::t($table));$hashes=[];
        foreach($rows as $r)$hashes[]=hash('sha256',wp_json_encode($r));sort($hashes);
        if(in_array($table,['role_caps','schema_migrations'],true)){foreach($snapshot['hashes'] as $h)if(!in_array($h,$hashes,true))throw new RuntimeException('Old row lost: '.$table);}elseif($hashes!==$snapshot['hashes'])throw new RuntimeException('Data changed: '.$table);
        echo 'PASS upgrade preserves '.$table.' ('.count($rows)." rows)\n";$n++;
    }
    foreach(Db::rows('SELECT rc.cap,r.role_key FROM '.Db::t('role_caps').' rc JOIN '.Db::t('roles')." r ON r.id=rc.role_id WHERE rc.cap IN ('party.sensitive','tax_rate.confirm')") as $grant)if($grant['role_key']!=='company_admin')throw new RuntimeException('Unexpected automatic sensitive permission');
    echo 'RESULT: '.$n." passed; 0 failed; 0 skipped\n";
}
