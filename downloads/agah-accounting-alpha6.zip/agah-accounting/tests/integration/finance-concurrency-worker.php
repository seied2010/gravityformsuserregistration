<?php
/** هر اجرا فرایند/اتصال جداست؛ خطای ناشناخته به‌جای نتیجه موفق، runner را شکست می‌دهد. */
if(!defined('ABSPATH')||!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
use Agah\Erp\Core\{Ctx,Db,Audit,Business,ConflictException,ValidationException};
use Agah\Erp\Modules\Expenses\ExpenseService;
use Agah\Erp\Modules\Accounting\{ClosingService,VoucherService,FiscalService};
$j=json_decode($args[0],true);Ctx::boot($j['uid'],$j['cid']);
if($j['kind']==='check'){$r=Db::row('SELECT * FROM '.Db::t('year_closings').' WHERE company_id=%d AND active_slot=1',$j['cid']);$old=VoucherService::get($j['cid'],(int)$r['closing_voucher_id']);$new=VoucherService::get($j['cid'],(int)$r['opening_voucher_id']);$equal=count($old['lines'])===count($new['lines']);foreach($old['lines'] as $i=>$l){$n=$new['lines'][$i];$equal=$equal&&$l['account_id']===$n['account_id']&&$l['detail_id']===$n['detail_id']&&$l['debit']===$n['credit']&&$l['credit']===$n['debit'];}echo wp_json_encode(['paid'=>ExpenseService::get($j['cid'],$j['expense'])['paid'],'runs'=>(int)Db::val('SELECT COUNT(*) FROM '.Db::t('year_closings').' WHERE company_id=%d AND active_slot=1',$j['cid']),'status'=>FiscalService::get($j['cid'],$j['year'])['status'],'equal'=>$equal,'audit_bad'=>Audit::verify($j['cid']),'numbers'=>array_map('intval',Db::col('SELECT number FROM '.Db::t('vouchers')." WHERE company_id=%d AND fiscal_year_id=%d AND status='approved' ORDER BY number",$j['cid'],$j['year']))]);return;}
try{if($j['kind']==='pay')ExpenseService::pay($j['cid'],$j['expense'],'2026-10-19',[['method'=>'transfer','treasury_account_id'=>$j['bank'],'amount'=>150]]);else ClosingService::close($j['cid'],$j['year'],'بستن هم‌زمان آزمایش');echo 'created';}catch(ConflictException|ValidationException $e){echo 'rejected';}
