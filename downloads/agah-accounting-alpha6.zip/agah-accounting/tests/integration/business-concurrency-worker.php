<?php
/** اتصال مستقل DB برای رقابت تسویه/رویداد چک/شناسهٔ یکتا. */
if(!defined('ABSPATH'))exit;
if(!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE||!defined('WP_CLI'))throw new RuntimeException('Test mode required');
use Agah\Erp\Core\{Ctx,Db,ValidationException,ConflictException,Audit};
use Agah\Erp\Modules\Treasury\TreasuryService;
use Agah\Erp\Modules\Parties\PartyService;
$j=json_decode($args[0]??'',true);if(!$j)throw new RuntimeException('Missing job');Ctx::boot($j['uid'],$j['cid']);wp_set_current_user($j['uid']);
try{switch($j['kind']){
case 'settle':TreasuryService::issue($j['cid'],['kind'=>'receipt','party_id'=>$j['party'],'doc_date'=>'2026-10-19'],[['method'=>'transfer','treasury_account_id'=>$j['bank'],'amount'=>300]],[['invoice_id'=>$j['invoice'],'amount'=>300]]);echo 'created';break;
case 'collect':TreasuryService::chequeTransition($j['cid'],$j['cheque'],'collected','2026-10-19','وصول هم‌زمان آزمایشی',1);echo 'created';break;
case 'party':PartyService::save($j['cid'],0,['name'=>'شناسه موازی','kind'=>'real','national_id'=>'1234567891','is_active'=>1,'is_customer'=>1]);echo 'created';break;
case 'check':echo wp_json_encode(['balance'=>TreasuryService::ledger($j['cid'],$j['bank'],'2026-12-31')['balance'],'settled'=>(int)Db::val('SELECT SUM(amount) FROM '.Db::t('settlements')." WHERE company_id=%d AND invoice_id=%d AND status='active'",$j['cid'],$j['invoice']),'numbers'=>array_map('intval',Db::col('SELECT number FROM '.Db::t('treasury_docs').' WHERE company_id=%d ORDER BY number',$j['cid'])),'audit_bad'=>Audit::verify($j['cid'])]);break;
}}catch(ValidationException|ConflictException $e){echo 'rejected';}
