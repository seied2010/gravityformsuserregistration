"""رقابت واقعی فرایندهای مستقل بر سر فاکتور، موجودی، سقف برگشت و پیش‌پرداخت."""
import os,json,subprocess,concurrent.futures
compose=os.environ.get('AGAH_TEST_COMPOSE','/workspace/agah-test/compose.yaml')
base=['docker','compose','-f',compose,'exec','-T','wordpress','php','/tmp/wp','--allow-root','eval-file']
def call(name,job=None):
    p=subprocess.run(base+['wp-content/themes/agah-accounting/tests/integration/'+name]+([json.dumps(job,separators=(',',':'))] if job else []),text=True,capture_output=True)
    if p.returncode:raise RuntimeError(p.stderr)
    return p.stdout.strip()
f=json.loads(call('trade-concurrency-setup.php'))
for kind in ['same','stock','return','advance']:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        r=list(pool.map(lambda id:call('trade-concurrency-worker.php',f|{'kind':kind,'invoice_id':id}),f[kind]))
    assert sorted(r)==['created','rejected'],(kind,r)
    print('PASS simultaneous '+kind+' commits exactly once',flush=True)
r=json.loads(call('trade-concurrency-worker.php',f|{'kind':'check'}))
assert r['stock']=={'qty':400000,'value':4000} and r['difference']==0,r
print('PASS competing sale preserves positive stock and ledger reconciliation')
assert r['advance']==100 and r['audit_bad'] is None,r
print('PASS advance consumed once and audit hash chain remains valid')
assert r['numbers']==list(range(1,len(r['numbers'])+1)),r
print('PASS rollback leaves gap-free accounting numbers')
print('RESULT: 7 passed; 0 failed; 0 skipped')
