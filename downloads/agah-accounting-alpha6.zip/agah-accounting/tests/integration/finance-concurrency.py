"""رقابت فرایندهای واقعی برای سقف هزینه و یکپارچگی بستن سال."""
import os,json,subprocess,concurrent.futures
compose=os.environ.get('AGAH_TEST_COMPOSE','/workspace/agah-test/compose.yaml')
base=['docker','compose','-f',compose,'exec','-T','wordpress','php','/tmp/wp','--allow-root','eval-file']
def call(file,job=None):
 p=subprocess.run(base+['wp-content/themes/agah-accounting/tests/integration/'+file]+([json.dumps(job,separators=(',',':'))] if job else []),text=True,capture_output=True)
 if p.returncode:raise RuntimeError(p.stderr)
 return p.stdout.strip()
f=json.loads(call('finance-concurrency-setup.php'))
for kind in ['pay','close']:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:r=list(pool.map(lambda _:call('finance-concurrency-worker.php',f|{'kind':kind}),range(2)))
 assert sorted(r)==['created','rejected'],(kind,r)
 print('PASS concurrent finance '+kind+' commits exactly once',flush=True)
r=json.loads(call('finance-concurrency-worker.php',f|{'kind':'check'}))
assert r['paid']==150 and r['runs']==1 and r['status']=='closed',r
print('PASS no overpayment or duplicate active year closing')
assert r['equal'] and r['audit_bad'] is None,r
print('PASS carried details equal closing balances and audit is valid')
assert r['numbers']==list(range(1,len(r['numbers'])+1)),r
print('PASS failed competing finance operations leave gap-free numbers')
print('RESULT: 5 passed; 0 failed; 0 skipped')
