<?php
if(!defined('ABSPATH')) exit;
/** کارگر چندفرایندی؛ هر اجرا اتصال مستقل DB دارد و نتیجه را JSON برمی‌گرداند. */
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE) throw new RuntimeException('Disposable test site required');
use Agah\Erp\Core\{Ctx,Db,Idempotency,Audit,Money};
use Agah\Erp\Modules\Accounting\VoucherService;
use Agah\Erp\Security\RateLimiter;
$job=json_decode($args[0]??'',true);if(!$job)throw new RuntimeException('Missing job');
Ctx::boot($job['uid'],$job['cid']);wp_set_current_user($job['uid']);
switch($job['kind']) {
    case 'approve':VoucherService::transition($job['cid'],$job['id'],'approve','',1);echo 'ok';break;
    case 'duplicate':
        $url=agah_erp_url(['c'=>$job['cid']]);
        Db::tx(function()use($job,$url){
            $old=Idempotency::claim($job['token'],$job['uid'],$job['cid'],'parallel','same');
            if($old!==null){echo 'replay';return;}
            VoucherService::save($job['cid'],0,$job['head']+['type'=>'normal'],$job['lines']);Idempotency::complete($job['token'],$url);echo 'created';
        });break;
    case 'rate':echo RateLimiter::consume('parallel-'.$job['rate_key'],3,300)?'allowed':'denied';break;
    case 'audit':Db::tx(function()use($job){Audit::log('parallel.test','test',0,null,['worker'=>$job['worker']],$job['cid'],$job['uid']);usleep(40000);});echo 'logged';break;
    case 'check':
        $numbers=Db::col('SELECT number FROM '.Db::t('vouchers')." WHERE company_id=%d AND status='approved' ORDER BY number",$job['cid']);
        echo wp_json_encode(['numbers'=>array_map('intval',$numbers),'drafts'=>(int)Db::val('SELECT COUNT(*) FROM '.Db::t('vouchers')." WHERE company_id=%d AND status='draft'",$job['cid']),'audit_bad'=>Audit::verify($job['cid'])]);break;
}
