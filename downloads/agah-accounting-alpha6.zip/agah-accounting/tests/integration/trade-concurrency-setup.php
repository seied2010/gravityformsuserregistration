<?php
/** fixture خصوصی رقابت‌های صدور/انبار/برگشت/پیش‌پرداخت؛ فقط محیط دورریختنی. */
if(!defined('ABSPATH')||!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
use Agah\Erp\Core\{Db,Ctx,Crypto};
use Agah\Erp\Modules\Company\CompanyService;
use Agah\Erp\Modules\Catalog\CatalogService;
use Agah\Erp\Modules\Parties\PartyService;
use Agah\Erp\Modules\Accounting\AccountService;
use Agah\Erp\Modules\Trade\InvoiceService;
use Agah\Erp\Modules\Inventory\StockService;
use Agah\Erp\Modules\Treasury\TreasuryService;
$s=Crypto::token(5);$u=wp_insert_user(['user_login'=>'trade_parallel_'.$s,'user_email'=>$s.'@example.test','user_pass'=>wp_generate_password(24)]);$c=CompanyService::create($u,['name'=>'رقابت تجارت '.$s,'jy'=>1405]);Ctx::boot($u,$c);StockService::configure($c,'average','inventory');$w=StockService::saveWarehouse($c,0,['name'=>'انبار رقابت','code'=>'W','is_active'=>1]);$p=PartyService::save($c,0,['name'=>'طرف رقابت','kind'=>'real','is_customer'=>1,'is_supplier'=>1,'is_active'=>1]);$unit=(int)Db::val('SELECT id FROM '.Db::t('units').' WHERE company_id=%d LIMIT 1',$c);
$b=['name'=>'کالای رقابت','code'=>'I','kind'=>'goods','unit_id'=>$unit,'sale_account_id'=>(int)AccountService::bySysKey($c,'sales_goods')['id'],'purchase_account_id'=>(int)AccountService::bySysKey($c,'purchases')['id'],'is_active'=>1];$i=CatalogService::save($c,'item',0,$b);$svc=CatalogService::save($c,'item',0,array_merge($b,['code'=>'S','name'=>'خدمت رقابت','kind'=>'service','sale_account_id'=>(int)AccountService::bySysKey($c,'sales_services')['id']]));$bank=TreasuryService::saveAccount($c,0,['code'=>'B','name'=>'بانک رقابت','kind'=>'bank','is_active'=>1]);
StockService::issue($c,['kind'=>'receipt','doc_date'=>'2026-10-19'],[['warehouse_id'=>$w,'item_id'=>$i,'qty_scaled'=>1000000,'cost'=>10000]]);
$head=['kind'=>'sale','party_id'=>$p,'invoice_date'=>'2026-10-19','due_date'=>'2026-10-19'];$same=InvoiceService::save($c,0,$head,[['item_id'=>$svc,'qty_scaled'=>10000,'unit_price'=>100]]);
$stock=[];for($n=0;$n<2;$n++)$stock[]=InvoiceService::save($c,0,$head,[['item_id'=>$i,'warehouse_id'=>$w,'qty_scaled'=>600000,'unit_price'=>200]]);
$original=InvoiceService::save($c,0,$head,[['item_id'=>$svc,'qty_scaled'=>20000,'unit_price'=>100]]);InvoiceService::issue($c,$original,1);$line=(int)InvoiceService::get($c,$original)['lines'][0]['id'];$returns=[];for($n=0;$n<2;$n++)$returns[]=InvoiceService::save($c,0,array_merge($head,['kind'=>'sale_return','parent_id'=>$original]),[['source_line_id'=>$line,'qty_scaled'=>15000]]);
$advance=TreasuryService::issue($c,['kind'=>'receipt','party_id'=>$p,'advance'=>1,'doc_date'=>'2026-10-19'],[['method'=>'transfer','treasury_account_id'=>$bank,'amount'=>100]]);$adv=[];for($n=0;$n<2;$n++)$adv[]=InvoiceService::save($c,0,$head,[['item_id'=>$svc,'qty_scaled'=>10000,'unit_price'=>100]]);
echo wp_json_encode(['uid'=>$u,'cid'=>$c,'warehouse'=>$w,'item'=>$i,'same'=>[$same,$same],'stock'=>$stock,'return'=>$returns,'advance'=>$adv,'advance_doc'=>$advance]);
