<?php
/** آزمون مراحل ۴ تا ۶ با commit/rollback واقعی، FK مرکب و سند حسابداری مرجع. */
if(!defined('ABSPATH'))exit;
use Agah\Erp\Core\{Db,Ctx,Money,Jalali,Business,Crypto,Audit,Settings,ConflictException,ValidationException,NotFoundException,ForbiddenException};
use Agah\Erp\Modules\Company\{CompanyService,MemberService};
use Agah\Erp\Modules\Parties\PartyService;
use Agah\Erp\Modules\Catalog\CatalogService;
use Agah\Erp\Modules\Treasury\TreasuryService;
use Agah\Erp\Modules\Accounting\{AccountService,VoucherService,FiscalService};
$bs=Crypto::token(5);$bu=wp_insert_user(['user_login'=>'business_'.$bs,'user_email'=>$bs.'@example.test','user_pass'=>wp_generate_password(24),'role'=>'subscriber']);$bc=CompanyService::create($bu,['name'=>'آزمون کسب‌وکار '.$bs,'jy'=>1405]);wp_set_current_user($bu);Ctx::boot($bu,$bc);
function agah_business_national($first='123456789'){$s=0;for($i=0;$i<9;$i++)$s+=(int)$first[$i]*(10-$i);$r=$s%11;return $first.($r<2?$r:11-$r);}
$bn=agah_business_national();$pi=['name'=>'مشتری و تأمین‌کننده آزمون','kind'=>'real','national_id'=>$bn,'is_customer'=>1,'is_supplier'=>1,'is_active'=>1,'credit_limit'=>100];$bp=PartyService::save($bc,0,$pi);
agah_test('Business schema all composite foreign keys installed',function(){agah_assert(count(\Agah\Erp\Core\Schema::tables())===56);agah_assert(!\Agah\Erp\Core\Schema::missingForeignKeys());});
agah_test('National check digits reject repeated and invalid personal IDs',function()use($bn){agah_assert(PartyService::validNational($bn,'real'));agah_assert(!PartyService::validNational('1111111111','real'));agah_assert(!PartyService::validNational(substr($bn,0,9).(((int)$bn[9]+1)%10),'real'));agah_assert(!PartyService::validNational('123','legal'));});
agah_test('Party encrypts national ID, blind index and public hint only',function()use($bc,$bp,$bn){$raw=Business::row('parties',$bc,$bp);$safe=PartyService::get($bc,$bp);agah_assert(Crypto::decrypt($raw['national_id_enc'])===$bn);agah_assert(!isset($safe['national_id_enc'],$safe['national_id_idx']));agah_assert(strpos($raw['national_id_hint'],'*')!==false);});
agah_test('Duplicate national ID rejected and counter rollback leaves no party',function()use($bc,$pi){$before=Db::val('SELECT COUNT(*) FROM '.Db::t('parties').' WHERE company_id=%d',$bc);agah_throws(ValidationException::class,function()use($bc,$pi){PartyService::save($bc,0,$pi);});agah_assert(Db::val('SELECT COUNT(*) FROM '.Db::t('parties').' WHERE company_id=%d',$bc)===$before);});
agah_test('Party name and active status update its linked detail atomically',function()use($bc,$bp,$pi){PartyService::save($bc,$bp,array_merge($pi,['name'=>'نام همگام','national_id'=>'']));$p=PartyService::get($bc,$bp);agah_assert(Business::row('details',$bc,$p['detail_id'])['name']==='نام همگام');});
agah_test('Sensitive reveal requires capability and creates masked audit',function()use($bc,$bp,$bn){agah_assert(PartyService::reveal($bc,$bp)===$bn);$audit=Db::row('SELECT * FROM '.Db::t('audit_log')." WHERE company_id=%d AND event='party.sensitive.read' ORDER BY id DESC LIMIT 1",$bc);agah_assert($audit&&strpos($audit['new_json'],$bn)===false);});
$unit=(int)Db::val('SELECT id FROM '.Db::t('units').' WHERE company_id=%d LIMIT 1',$bc);$defaultTax=(int)Db::val('SELECT id FROM '.Db::t('tax_rates')." WHERE company_id=%d AND code='unconfirmed'",$bc);
agah_test('Seeded tax is unknown and cannot issue taxable snapshot',function()use($bc,$defaultTax){agah_throws(ConflictException::class,function()use($bc,$defaultTax){CatalogService::taxSnapshot($bc,$defaultTax,'2026-10-19',1000);});});
$tax=CatalogService::save($bc,'tax',0,['code'=>'vat_test','name'=>'نرخ آزمایشی نه نرخ قانونی','bp'=>975,'valid_from'=>'2026-01-01','valid_to'=>'2026-12-31','confirmed'=>1]);
agah_test('Tax snapshot uses date and half-up per-line integer rounding',function()use($bc,$tax){$s=CatalogService::taxSnapshot($bc,$tax,'2026-10-19',1005);agah_assert($s['tax_amount']===98&&$s['tax_bp']===975);agah_throws(ConflictException::class,function()use($bc,$tax){CatalogService::taxSnapshot($bc,$tax,'2027-01-01',100);});});
agah_test('Overlapping tax dates and out-of-range percentage rejected',function()use($bc){agah_throws(ValidationException::class,function()use($bc){CatalogService::save($bc,'tax',0,['code'=>'vat_test','name'=>'همپوشان','bp'=>100,'valid_from'=>'2026-11-01','valid_to'=>'2027-01-01']);});agah_throws(ValidationException::class,function()use($bc){CatalogService::save($bc,'tax',0,['code'=>'bad','name'=>'نامعتبر','bp'=>10001,'valid_from'=>'2026-01-01','valid_to'=>'2026-12-31']);});});
$group=CatalogService::save($bc,'group',0,['code'=>'GROUP','name'=>'گروه آزمون','is_active'=>1]);
$item=CatalogService::save($bc,'item',0,['name'=>'کالای تست','code'=>'GOOD-1','kind'=>'goods','group_id'=>$group,'unit_id'=>$unit,'tax_rate_id'=>$tax,'sale_account_id'=>(int)AccountService::bySysKey($bc,'sales_goods')['id'],'purchase_account_id'=>(int)AccountService::bySysKey($bc,'purchases')['id'],'sale_price'=>12345,'purchase_price'=>12000,'is_active'=>1,'barcode'=>'1234567']);
agah_test('Goods/service price fields persist as exact Rial integers',function()use($bc,$item){$r=CatalogService::get($bc,'item',$item);agah_assert((int)$r['sale_price']===12345);agah_assert($r['kind']==='goods');});
agah_test('Referenced unit deletion and duplicate barcode rejected',function()use($bc,$unit,$item){agah_throws(ConflictException::class,function()use($bc,$unit){CatalogService::delete($bc,'unit',$unit);});$r=CatalogService::get($bc,'item',$item);unset($r['id']);$r['code']='OTHER';$r['sale_price']=(int)$r['sale_price'];$r['purchase_price']=(int)$r['purchase_price'];agah_throws(ValidationException::class,function()use($bc,$r){CatalogService::save($bc,'item',0,$r);});});
$bank=TreasuryService::saveAccount($bc,0,['code'=>'BANK','name'=>'بانک آزمایش','kind'=>'bank','is_active'=>1]);$cash=TreasuryService::saveAccount($bc,0,['code'=>'CASH','name'=>'صندوق آزمایش','kind'=>'cash','is_active'=>1]);
agah_test('IBAN rejects bad checksum and account has dedicated detail',function()use($bc,$bank){agah_assert(!TreasuryService::validIban('IR00000000000000000000000000'));$a=TreasuryService::account($bc,$bank);agah_assert(Business::row('details',$bc,$a['detail_id'])['kind']==='bank');});
$base=['kind'=>'receipt','doc_date'=>'2026-10-19','party_id'=>$bp,'description'=>'دریافت آزمایشی'];$receipt=TreasuryService::issue($bc,$base,[['method'=>'transfer','treasury_account_id'=>$bank,'amount'=>1000]]);
agah_test('Receipt posts balanced automatic source voucher and bank balance',function()use($bc,$receipt,$bank){$d=TreasuryService::get($bc,$receipt);$v=VoucherService::get($bc,$d['voucher_id']);agah_assert($v['status']==='approved'&&(int)$v['total_debit']===1000&&(int)$v['total_credit']===1000);agah_assert(TreasuryService::ledger($bc,$bank)['balance']===1000);});
agah_test('Party with posted movement cannot delete; statement matches its ledger',function()use($bc,$bp){agah_throws(ConflictException::class,function()use($bc,$bp){PartyService::delete($bc,$bp);});agah_assert(PartyService::statement($bc,$bp)['balance']===-1000);});
$transfer=TreasuryService::issue($bc,['kind'=>'transfer','doc_date'=>'2026-10-19','source_account_id'=>$bank,'target_account_id'=>$cash,'amount'=>300],[]);
agah_test('Transfer changes both accounts and preserves aggregate cash',function()use($bc,$bank,$cash){agah_assert(TreasuryService::ledger($bc,$bank)['balance']===700);agah_assert(TreasuryService::ledger($bc,$cash)['balance']===300);});
agah_test('Same-account transfer and cash-to-bank method mismatch rejected',function()use($bc,$bank,$base){agah_throws(ValidationException::class,function()use($bc,$bank){TreasuryService::issue($bc,['kind'=>'transfer','doc_date'=>'2026-10-19','source_account_id'=>$bank,'target_account_id'=>$bank,'amount'=>1],[]);});agah_throws(ValidationException::class,function()use($bc,$bank,$base){TreasuryService::issue($bc,$base,[['method'=>'cash','treasury_account_id'=>$bank,'amount'=>1]]);});});
$chequeDoc=TreasuryService::issue($bc,$base,[['method'=>'cheque','treasury_account_id'=>$bank,'amount'=>500,'cheque_no'=>'CH-1','due_date'=>'2026-11-01']]);$ch=TreasuryService::get($bc,$chequeDoc)['cheques'][0];
agah_test('Pending cheque affects notes receivable and forecast, not bank',function()use($bc,$bank){agah_assert(TreasuryService::ledger($bc,$bank)['balance']===700);$f=TreasuryService::forecast($bc,'2026-12-01');agah_assert($f['current']===1000&&$f['expected']===1500);});
TreasuryService::chequeTransition($bc,$ch['id'],'collected','2026-11-01','وصول واقعی آزمایش',1);
agah_test('Collected cheque moves notes to bank',function()use($bc,$bank){agah_assert(TreasuryService::ledger($bc,$bank,'2026-12-01')['balance']===1200);});
agah_test('Stale cheque revision and invalid backwards date rejected',function()use($bc,$ch){agah_throws(ConflictException::class,function()use($bc,$ch){TreasuryService::chequeTransition($bc,$ch['id'],'returned','2026-11-02','تلاش کهنه',1);});agah_throws(ValidationException::class,function()use($bc,$ch){TreasuryService::chequeTransition($bc,$ch['id'],'returned','2026-10-20','تاریخ عقب',2);});});
TreasuryService::chequeTransition($bc,$ch['id'],'returned','2026-11-02','برگشت چک پس از وصول',2);
agah_test('Returned collected cheque reverses bank and restores party claim',function()use($bc,$bank,$bp){agah_assert(TreasuryService::ledger($bc,$bank,'2026-12-01')['balance']===700);agah_assert(PartyService::statement($bc,$bp,'','2026-12-01')['balance']===-1000);});
TreasuryService::voidDocument($bc,$chequeDoc,'ابطال کامل برگه چک آزمایشی');
agah_test('Void document reverses all event vouchers and original with no residual effect',function()use($bc,$chequeDoc,$bank){agah_assert(TreasuryService::get($bc,$chequeDoc)['status']==='void');agah_assert(TreasuryService::ledger($bc,$bank,'2026-12-01')['balance']===700);});
// فاکتور واقعی fixture با سند مبدأ؛ صفحهٔ صدور فاکتور هنوز متعلق به مرحلهٔ ۷ است.
$fy=FiscalService::all($bc)[0];$invoice=Business::save('invoices',$bc,0,['kind'=>'sale','status'=>'issued','party_id'=>$bp,'fiscal_year_id'=>$fy['id'],'number'=>1,'invoice_date'=>'2026-10-19','due_date'=>'2026-11-10','amount'=>800]);$party=PartyService::get($bc,$bp);
$iv=VoucherService::postSystem(['voucher_date'=>'2026-10-19','source_type'=>'invoice_sale','source_id'=>$invoice],[['account_id'=>(int)AccountService::bySysKey($bc,'receivable')['id'],'detail_id'=>(int)$party['detail_id'],'debit'=>800],['account_id'=>(int)AccountService::bySysKey($bc,'sales_goods')['id'],'credit'=>800]]);Db::update('invoices',['voucher_id'=>$iv],['company_id'=>$bc,'id'=>$invoice]);
$settle=TreasuryService::issue($bc,$base,[['method'=>'transfer','treasury_account_id'=>$bank,'amount'=>300],['method'=>'cheque','treasury_account_id'=>$bank,'amount'=>200,'cheque_no'=>'SET-1','due_date'=>'2026-11-05']],[['invoice_id'=>$invoice,'amount'=>500]]);
agah_test('Partial multi-item settlement sums to allocated invoice amount',function()use($bc,$invoice){agah_assert((int)Db::val('SELECT SUM(amount) FROM '.Db::t('settlements')." WHERE company_id=%d AND invoice_id=%d AND status='active'",$bc,$invoice)===500);});
agah_test('Over-settlement rolls back number, document and voucher atomically',function()use($bc,$base,$bank,$invoice){$before=Db::val('SELECT COUNT(*) FROM '.Db::t('treasury_docs').' WHERE company_id=%d',$bc);agah_throws(ValidationException::class,function()use($bc,$base,$bank,$invoice){TreasuryService::issue($bc,$base,[['method'=>'transfer','treasury_account_id'=>$bank,'amount'=>301]],[['invoice_id'=>$invoice,'amount'=>301]]);});agah_assert(Db::val('SELECT COUNT(*) FROM '.Db::t('treasury_docs').' WHERE company_id=%d',$bc)===$before);});
$sc=TreasuryService::get($bc,$settle)['cheques'][0];TreasuryService::chequeTransition($bc,$sc['id'],'returned','2026-11-05','برگشت قلم چک تخصیص‌یافته',1);
agah_test('Returned cheque releases only its allocation and retains cash settlement',function()use($bc,$invoice){agah_assert((int)Db::val('SELECT SUM(amount) FROM '.Db::t('settlements')." WHERE company_id=%d AND invoice_id=%d AND status='active'",$bc,$invoice)===300);});
TreasuryService::voidDocument($bc,$settle,'ابطال برگه تسویه ترکیبی');
agah_test('Void settlement document releases all remaining allocations',function()use($bc,$invoice){agah_assert((int)Db::val('SELECT COALESCE(SUM(amount),0) FROM '.Db::t('settlements')." WHERE company_id=%d AND invoice_id=%d AND status='active'",$bc,$invoice)===0);});
// snapshot نرخ در خط فاکتور باید با تغییر نرخ مبدأ ثابت بماند.
$snap=CatalogService::taxSnapshot($bc,$tax,'2026-10-19',1005);$il=Business::save('invoice_lines',$bc,0,['invoice_id'=>$invoice,'item_id'=>$item,'line_no'=>1,'qty_scaled'=>10000,'unit_price'=>1005,'net_amount'=>1005]+$snap);
CatalogService::save($bc,'tax',$tax,['code'=>'vat_test','name'=>'نرخ ویرایش آزمایشی','bp'=>1000,'valid_from'=>'2026-01-01','valid_to'=>'2026-12-31','confirmed'=>1]);
agah_test('Changing tax rate does not mutate stored invoice-line snapshot',function()use($bc,$il){$r=Business::row('invoice_lines',$bc,$il);agah_assert((int)$r['tax_bp']===975&&(int)$r['tax_amount']===98);});
$l=TreasuryService::ledger($bc,$bank,'2026-12-01');$matched=array_map('intval',array_column($l['rows'],'id'));$recon=TreasuryService::reconcile($bc,0,['treasury_account_id'=>$bank,'as_of_date'=>'2026-12-01','statement_balance'=>$l['balance']],$matched);
agah_test('Bank reconciliation uses matched real ledger lines and shows zero difference',function()use($bc,$recon){$r=TreasuryService::reconciliation($bc,$recon);agah_assert($r['difference']===0&&$r['unmatched']===0);});
agah_test('Cash account cannot be reconciled as a bank',function()use($bc,$cash){agah_throws(ValidationException::class,function()use($bc,$cash){TreasuryService::reconcile($bc,0,['treasury_account_id'=>$cash,'as_of_date'=>'2026-12-01','statement_balance'=>0],[]);});});
$cu=wp_insert_user(['user_login'=>'cashier_'.$bs,'user_email'=>'cash'.$bs.'@example.test','user_pass'=>wp_generate_password(24),'role'=>'subscriber']);$role=(int)Db::val('SELECT id FROM '.Db::t('roles')." WHERE company_id=%d AND role_key='cashier'",$bc);MemberService::add($bc,['login'=>get_userdata($cu)->user_login,'role_id'=>$role]);Ctx::boot($cu,$bc);
agah_test('Cashier can post receipt without generic manual-voucher permission',function()use($bc,$base,$cash){agah_assert(!Ctx::can('voucher.create'));$d=TreasuryService::issue($bc,$base,[['method'=>'cash','treasury_account_id'=>$cash,'amount'=>10]]);agah_assert($d>0);});
agah_test('Cashier cannot reveal national identity or confirm tax rates',function()use($bc,$bp,$tax){agah_throws(ForbiddenException::class,function()use($bc,$bp){PartyService::reveal($bc,$bp);});agah_throws(ForbiddenException::class,function()use($bc,$tax){CatalogService::save($bc,'tax',$tax,[]);});});
Ctx::boot($bu,$bc);wp_set_current_user($bu);
$fu=wp_insert_user(['user_login'=>'foreign_'.$bs,'user_email'=>'foreign'.$bs.'@example.test','user_pass'=>wp_generate_password(24)]);$fc=CompanyService::create($fu,['name'=>'بیگانه تجاری','jy'=>1405]);Ctx::boot($fu,$fc);$fp=PartyService::save($fc,0,array_merge($pi,['national_id'=>'']));$fa=TreasuryService::saveAccount($fc,0,['name'=>'بانک بیگانه','code'=>'FOREIGN','kind'=>'bank','is_active'=>1]);Ctx::boot($bu,$bc);
agah_test('Cross-company party/account/item/tax inputs rejected by services',function()use($bc,$fp,$fa,$base,$tax,$fc){agah_throws(NotFoundException::class,function()use($bc,$base,$fa){TreasuryService::issue($bc,$base,[['method'=>'transfer','treasury_account_id'=>$fa,'amount'=>1]]);});agah_throws(NotFoundException::class,function()use($bc,$base,$fp,$fa){TreasuryService::issue($bc,array_merge($base,['party_id'=>$fp]),[['method'=>'transfer','treasury_account_id'=>$fa,'amount'=>1]]);});agah_throws(NotFoundException::class,function()use($fc,$tax){CatalogService::taxSnapshot($fc,$tax,'2026-10-19',10);});});

agah_test('Outgoing payment cheque collection/return restores payable and cash',function()use($bc,$bp,$bank){
    $before=TreasuryService::ledger($bc,$bank,'2026-12-31')['balance'];$doc=TreasuryService::issue($bc,['kind'=>'payment','party_id'=>$bp,'doc_date'=>'2026-10-19'],[['method'=>'cheque','treasury_account_id'=>$bank,'amount'=>70,'cheque_no'=>'OUT','due_date'=>'2026-11-01']]);$c=TreasuryService::get($bc,$doc)['cheques'][0];
    TreasuryService::chequeTransition($bc,$c['id'],'collected','2026-11-01','وصول چک پرداختی',1);agah_assert(TreasuryService::ledger($bc,$bank,'2026-12-31')['balance']===$before-70);
    TreasuryService::chequeTransition($bc,$c['id'],'returned','2026-11-02','برگشت چک پرداختی',2);agah_assert(TreasuryService::ledger($bc,$bank,'2026-12-31')['balance']===$before);
});
agah_test('Final source voucher blocks full void and rolls back earlier event reversals',function()use($bc,$bp,$bank){
    $doc=TreasuryService::issue($bc,['kind'=>'receipt','party_id'=>$bp,'doc_date'=>'2026-10-19'],[['method'=>'cheque','treasury_account_id'=>$bank,'amount'=>40,'cheque_no'=>'FINAL','due_date'=>'2026-11-01']]);$d=TreasuryService::get($bc,$doc);$ch=$d['cheques'][0];TreasuryService::chequeTransition($bc,$ch['id'],'collected','2026-11-01','وصول قبل از قفل',1);
    $event=Db::row('SELECT * FROM '.Db::t('cheque_events').' WHERE company_id=%d AND cheque_id=%d AND voucher_id IS NOT NULL',$bc,$ch['id']);Db::update('vouchers',['status'=>'final'],['company_id'=>$bc,'id'=>$d['voucher_id']]);
    agah_throws(ConflictException::class,function()use($bc,$doc){TreasuryService::voidDocument($bc,$doc,'ابطال باید کامل رد شود');});
    agah_assert(TreasuryService::get($bc,$doc)['status']==='issued');agah_assert(Business::row('vouchers',$bc,$event['voucher_id'])['status']==='approved');Db::update('vouchers',['status'=>'approved'],['company_id'=>$bc,'id'=>$d['voucher_id']]);TreasuryService::voidDocument($bc,$doc,'ابطال پس از بازگشایی مجاز');
});
agah_test('Credit limit warning equals the real receivable-detail ledger balance',function()use($bc){
    $pid=PartyService::save($bc,0,['name'=>'مشتری سقف اعتبار','kind'=>'real','is_customer'=>1,'is_active'=>1,'credit_limit'=>50]);$p=PartyService::get($bc,$pid);
    $v=VoucherService::save($bc,0,['voucher_date'=>'2026-10-19'],[['account_id'=>(int)AccountService::bySysKey($bc,'receivable')['id'],'detail_id'=>(int)$p['detail_id'],'debit'=>100],['account_id'=>(int)AccountService::bySysKey($bc,'sales_goods')['id'],'credit'=>100]]);VoucherService::transition($bc,$v,'approve','',1);
    $r=PartyService::statement($bc,$pid);agah_assert($r['over_limit']&&$r['balance']===100);
});
agah_test('Bank reconciliation rejects a same-company line from another treasury account',function()use($bc,$bank,$cash){
    $line=TreasuryService::ledger($bc,$cash,'2026-12-31')['rows'][0]['id'];
    agah_throws(NotFoundException::class,function()use($bc,$bank,$line){TreasuryService::reconcile($bc,0,['treasury_account_id'=>$bank,'as_of_date'=>'2026-12-30','statement_balance'=>0],[$line]);});
});
// ساخت کپی FK-only از گراف fixture؛ این داده صرفاً برای آزمون قیود DB است، نه سناریوی گردش مالی.
Db::update('treasury_accounts',['code'=>'BANK'],['company_id'=>$fc,'id'=>$fa]);
$fkMap=[];
foreach(['accounts'=>'code','fiscal_years'=>'jy'] as $table=>$key)foreach(Db::rows('SELECT * FROM '.Db::t($table).' WHERE company_id=%d',$bc) as $r)$fkMap[$table][$r['id']]=(int)Db::val('SELECT id FROM '.Db::t($table).' WHERE company_id=%d AND '.$key.'=%s',$fc,$r[$key]);
$relations=[];foreach(\Agah\Erp\Core\BusinessSchema::fks() as $fk)if(count($fk[2])===2)$relations[$fk[0]][$fk[2][1]]=$fk[3];
$relations['vouchers']=['fiscal_year_id'=>'fiscal_years'];$relations['voucher_lines']=['voucher_id'=>'vouchers','account_id'=>'accounts','detail_id'=>'details'];
foreach(array_merge(['details','vouchers','voucher_lines'],\Agah\Erp\Core\BusinessSchema::tables()) as $table){
    foreach(Db::rows('SELECT * FROM '.Db::t($table).' WHERE company_id=%d ORDER BY id',$bc) as $r){
        $original=$r['id'];$existing=null;
        if(isset($r['code']))$existing=Db::val('SELECT id FROM '.Db::t($table).' WHERE company_id=%d AND code=%s'.($table==='tax_rates'?' AND valid_from=%s':''),...($table==='tax_rates'?[$fc,$r['code'],$r['valid_from']]:[$fc,$r['code']]));
        if($existing){$fkMap[$table][$original]=(int)$existing;continue;}
        unset($r['id']);$r['company_id']=$fc;if(isset($r['uuid']))$r['uuid']=Crypto::uuid();
        foreach($relations[$table]??[] as $col=>$parent)if($r[$col]!==null){if(!isset($fkMap[$parent][$r[$col]]))throw new RuntimeException('Missing FK fixture mapping '.$table.'.'.$col);$r[$col]=$fkMap[$parent][$r[$col]];}
        $fkMap[$table][$original]=Db::insert($table,$r);
    }
}
foreach(\Agah\Erp\Core\BusinessSchema::fks() as $fk){
    if(count($fk[2])!==2)continue;
    [$table,$name,$cols,$parent]=$fk;
    agah_test('DB composite FK rejects foreign parent: '.$name,function()use($bc,$fc,$table,$name,$cols,$parent){global $wpdb;
        $parentId=Db::val('SELECT id FROM '.Db::t($parent).' WHERE company_id=%d LIMIT 1',$fc);$child=Db::val('SELECT id FROM '.Db::t($table).' WHERE company_id=%d LIMIT 1',$bc);
        agah_assert($parentId&&$child,'Fixture missing for '.$name);
        $prior=$wpdb->suppress_errors(true);$ok=$wpdb->update(Db::t($table),[$cols[1]=>$parentId],['id'=>$child,'company_id'=>$bc]);$error=$wpdb->last_error;$wpdb->suppress_errors($prior);$wpdb->last_error='';
        agah_assert($ok===false && stripos($error,'foreign key constraint fails')!==false,$name);
    });
}
agah_test('Business audit chain intact and all approved vouchers balanced',function()use($bc){agah_assert(Audit::verify($bc)===null);$bad=Db::val('SELECT COUNT(*) FROM (SELECT v.id FROM '.Db::t('vouchers').' v JOIN '.Db::t('voucher_lines')." l ON l.company_id=v.company_id AND l.voucher_id=v.id WHERE v.company_id=%d AND v.status IN ('approved','final') GROUP BY v.id HAVING SUM(l.debit)<>SUM(l.credit) OR SUM(l.debit)<=0) x",$bc);agah_assert((int)$bad===0);});
