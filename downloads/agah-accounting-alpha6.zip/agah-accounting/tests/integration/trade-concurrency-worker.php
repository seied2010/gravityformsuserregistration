<?php
/** اتصال مستقل DB برای هر کارگر؛ رد دامنه نتیجهٔ مورد انتظار است و خطای ناشناخته شکست runner است. */
if(!defined('ABSPATH')||!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
use Agah\Erp\Core\{Ctx,Db,Audit,ValidationException,ConflictException};
use Agah\Erp\Modules\Trade\InvoiceService;
use Agah\Erp\Modules\Inventory\StockService;
$j=json_decode($args[0],true);Ctx::boot($j['uid'],$j['cid']);
if($j['kind']==='check') {
    echo wp_json_encode(['stock'=>StockService::balanceInternal($j['cid'],$j['warehouse'],$j['item']),'audit_bad'=>Audit::verify($j['cid']),'difference'=>StockService::reconcile($j['cid'])['difference'],'advance'=>(int)Db::val('SELECT SUM(amount) FROM '.Db::t('invoice_advances')." WHERE company_id=%d AND status='active'",$j['cid']),'numbers'=>array_map('intval',Db::col('SELECT number FROM '.Db::t('vouchers')." WHERE company_id=%d AND status='approved' ORDER BY number",$j['cid']))]);return;
}
try { InvoiceService::issue($j['cid'],$j['invoice_id'],1,[],$j['kind']==='advance'?[['doc_id'=>$j['advance_doc'],'amount'=>100]]:[]);echo 'created'; }
catch(ConflictException|ValidationException $e) { echo 'rejected'; }
