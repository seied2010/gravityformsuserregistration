"""Two real processes race against each new financial source under company locking."""
import os,json,subprocess,concurrent.futures
base=['docker','compose','-f',os.environ.get('AGAH_TEST_COMPOSE','/workspace/agah-test/compose.yaml'),'exec','-T','wordpress','php','/tmp/wp','--allow-root','eval-file']
def call(file,job=None):
 p=subprocess.run(base+['wp-content/themes/agah-accounting/tests/integration/'+file]+([json.dumps(job,separators=(',',':'))] if job else []),text=True,capture_output=True)
 if p.returncode:raise RuntimeError(p.stderr)
 return p.stdout.strip()
f=json.loads(call('operations-concurrency-setup.php'))
for kind in ['payroll','depreciation']:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:r=list(pool.map(lambda _:call('operations-concurrency-worker.php',f|{'kind':kind}),range(2)))
 assert sorted(r)==['created','rejected'],(kind,r)
 print('PASS concurrent '+kind+' commits exactly once',flush=True)
r=json.loads(call('operations-concurrency-worker.php',f|{'kind':'check'}))
assert r['slips']==1 and r['depreciations']==1 and r['book']==11000,r
print('PASS no duplicate payroll or depreciation changes book value twice')
assert r['numbers']==list(range(1,len(r['numbers'])+1)),r
print('PASS rejected races leave gap-free voucher numbers')
assert r['audit_bad'] is None,r
print('PASS concurrent financial writes preserve audit hash chain')
print('RESULT: 5 passed; 0 failed; 0 skipped')
