<?php
if(!defined('ABSPATH')) exit;
/** fixture مستقل برای چند فرایند واقعی؛ خروجی فقط شناسه و توکن فرم آزمایشی است. */
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE) throw new RuntimeException('Disposable test site required');
use Agah\Erp\Core\{Ctx,Db,Crypto,Idempotency};
use Agah\Erp\Modules\Company\CompanyService;
use Agah\Erp\Modules\Accounting\{AccountService,DetailService,VoucherService};
$s=Crypto::token(5);$u=wp_insert_user(['user_login'=>'parallel_'.$s,'user_email'=>$s.'@example.test','user_pass'=>wp_generate_password(24),'role'=>'subscriber']);
$c=CompanyService::create($u,['name'=>'شرکت آزمون هم‌زمانی','jy'=>1405]);Ctx::boot($u,$c);
$d=DetailService::save($c,0,['code'=>'CASH','name'=>'صندوق','kind'=>'cash','is_active'=>1]);$cash=AccountService::bySysKey($c,'cash');$cap=AccountService::bySysKey($c,'capital');
$lines=[['account_id'=>(int)$cash['id'],'detail_id'=>$d,'debit'=>100],['account_id'=>(int)$cap['id'],'credit'=>100]];$head=['voucher_date'=>'2026-10-18','description'=>'parallel'];
$ids=[];for($i=0;$i<4;$i++)$ids[]=VoucherService::save($c,0,$head,$lines);
echo wp_json_encode(['uid'=>$u,'cid'=>$c,'ids'=>$ids,'token'=>Idempotency::issue($u,$c,'parallel'),'lines'=>$lines,'head'=>$head,'rate_key'=>$s]);
