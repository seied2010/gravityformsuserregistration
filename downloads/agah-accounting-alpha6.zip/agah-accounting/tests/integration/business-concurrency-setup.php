<?php
/** fixture چندفرایندی مرحلهٔ ۶، فقط روی سایت دورریختنی. */
if(!defined('ABSPATH'))exit;
if(!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE||!defined('WP_CLI'))throw new RuntimeException('Test mode required');
use Agah\Erp\Core\{Ctx,Crypto,Db,Business};
use Agah\Erp\Modules\Company\CompanyService;
use Agah\Erp\Modules\Parties\PartyService;
use Agah\Erp\Modules\Treasury\TreasuryService;
use Agah\Erp\Modules\Accounting\{AccountService,FiscalService,VoucherService};
$s=Crypto::token(5);$u=wp_insert_user(['user_login'=>'bparallel_'.$s,'user_email'=>$s.'@example.test','user_pass'=>wp_generate_password(24)]);$c=CompanyService::create($u,['name'=>'تست هم‌زمانی خزانه','jy'=>1405]);Ctx::boot($u,$c);
$p=PartyService::save($c,0,['name'=>'شخص موازی','kind'=>'real','is_active'=>1,'is_customer'=>1]);$bank=TreasuryService::saveAccount($c,0,['name'=>'بانک موازی','kind'=>'bank','code'=>'BANK','is_active'=>1]);$fy=FiscalService::all($c)[0];
$i=Business::save('invoices',$c,0,['kind'=>'sale','status'=>'issued','party_id'=>$p,'fiscal_year_id'=>$fy['id'],'number'=>1,'invoice_date'=>'2026-10-19','due_date'=>'2026-11-01','amount'=>300]);$pr=PartyService::get($c,$p);
$v=VoucherService::postSystem(['voucher_date'=>'2026-10-19','source_type'=>'invoice_sale','source_id'=>$i],[['account_id'=>(int)AccountService::bySysKey($c,'receivable')['id'],'detail_id'=>(int)$pr['detail_id'],'debit'=>300],['account_id'=>(int)AccountService::bySysKey($c,'sales_goods')['id'],'credit'=>300]]);Db::update('invoices',['voucher_id'=>$v],['company_id'=>$c,'id'=>$i]);
$d=TreasuryService::issue($c,['kind'=>'receipt','party_id'=>$p,'doc_date'=>'2026-10-19'],[['method'=>'cheque','treasury_account_id'=>$bank,'amount'=>100,'cheque_no'=>'PARALLEL','due_date'=>'2026-10-19']]);$ch=TreasuryService::get($c,$d)['cheques'][0];echo wp_json_encode(['uid'=>$u,'cid'=>$c,'party'=>$p,'bank'=>$bank,'invoice'=>$i,'cheque'=>$ch['id']]);
