<?php
/** رقابت تسویه هزینه و بستن سال با اتصال‌های مستقل؛ فقط تست دورریختنی. */
if(!defined('ABSPATH')||!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
use Agah\Erp\Core\{Crypto,Ctx,Db};
use Agah\Erp\Modules\Company\CompanyService;
use Agah\Erp\Modules\Accounting\AccountService;
use Agah\Erp\Modules\Expenses\ExpenseService;
use Agah\Erp\Modules\Parties\PartyService;
use Agah\Erp\Modules\Treasury\TreasuryService;
$s=Crypto::token(5);$u=wp_insert_user(['user_login'=>'finance_race_'.$s,'user_email'=>$s.'@example.test','user_pass'=>wp_generate_password(24)]);$c=CompanyService::create($u,['name'=>'رقابت بستن '.$s,'jy'=>1405]);Ctx::boot($u,$c);$p=PartyService::save($c,0,['name'=>'طرف رقابت مالی','kind'=>'real','is_supplier'=>1,'is_customer'=>1,'is_active'=>1]);$b=TreasuryService::saveAccount($c,0,['code'=>'B','name'=>'بانک رقابت مالی','kind'=>'bank','is_active'=>1]);$cat=ExpenseService::saveLookup($c,'category',0,['code'=>'E','name'=>'هزینه رقابت','kind'=>'expense','account_id'=>(int)AccountService::bySysKey($c,'other_expense')['id'],'is_active'=>1]);$e=ExpenseService::issue($c,['category_id'=>$cat,'party_id'=>$p,'doc_date'=>'2026-10-19','due_date'=>'2026-10-19','amount'=>200]);echo wp_json_encode(['uid'=>$u,'cid'=>$c,'expense'=>$e,'bank'=>$b,'year'=>(int)Db::val('SELECT id FROM '.Db::t('fiscal_years').' WHERE company_id=%d LIMIT 1',$c)]);
