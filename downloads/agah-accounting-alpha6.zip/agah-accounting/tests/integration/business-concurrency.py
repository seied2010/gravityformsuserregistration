"""فرایندهای مستقل برای رقابت روی منابع مالی؛ همهٔ شکست‌های غیرمنتظره exit غیرصفر دارند."""
import os,json,subprocess,concurrent.futures
compose=os.environ.get('AGAH_TEST_COMPOSE','/workspace/agah-test/compose.yaml')
base=['docker','compose','-f',compose,'exec','-T','wordpress','php','/tmp/wp','--allow-root','eval-file']
def call(name,job=None):
    command=base+['wp-content/themes/agah-accounting/tests/integration/'+name]
    if job is not None:command.append(json.dumps(job,separators=(',',':')))
    p=subprocess.run(command,text=True,capture_output=True)
    if p.returncode:raise RuntimeError(p.stderr)
    return p.stdout.strip()
f=json.loads(call('business-concurrency-setup.php'))
for kind in ['settle','collect','party']:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:r=list(pool.map(lambda _:call('business-concurrency-worker.php',f|{'kind':kind}),range(2)))
    assert sorted(r)==['created','rejected'],(kind,r)
    print('PASS simultaneous '+kind+' commits exactly once',flush=True)
s=json.loads(call('business-concurrency-worker.php',f|{'kind':'check'}))
assert s['settled']==300 and s['balance']==400
print('PASS invoice allocation and bank balance remain exact')
assert s['numbers']==[1,2] and s['audit_bad'] is None
print('PASS failed competing operation leaves gap-free numbers and valid audit')
print('RESULT: 5 passed; 0 failed; 0 skipped')
