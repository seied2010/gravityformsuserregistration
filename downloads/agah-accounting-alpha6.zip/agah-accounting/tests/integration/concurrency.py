"""دو/چند فرایند واقعی WordPress+DB؛ هیچ shell interpolation یا خروجی credential وجود ندارد."""
import concurrent.futures,json,os,subprocess,sys
compose=os.environ.get('AGAH_TEST_COMPOSE','/workspace/agah-test/compose.yaml')
base=['docker','compose','-f',compose,'exec','-T','wordpress','php','/tmp/wp','--allow-root','eval-file','wp-content/themes/agah-accounting/tests/integration/']
def call(file,args=None):
    cmd=base[:-1]+[base[-1]+file]
    if args is not None:cmd.append(json.dumps(args,separators=(',',':')))
    p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode:raise RuntimeError(file+' failed: '+p.stderr)
    return p.stdout.strip()
fixture=json.loads(call('concurrency-setup.php'))
def parallel(kind,n,**extra):
    jobs=[]
    for i in range(n):
        job=fixture|{'kind':kind,'worker':i}|extra
        if kind=='approve':job['id']=fixture['ids'][i]
        jobs.append(job)
    with concurrent.futures.ThreadPoolExecutor(max_workers=n) as pool:return list(pool.map(lambda j:call('concurrency-worker.php',j),jobs))
passed=0
def check(name,ok):
    global passed
    if not ok:raise RuntimeError(name)
    passed+=1;print('PASS '+name,flush=True)
check('Four concurrent approvals all commit',parallel('approve',4)==['ok']*4)
result=parallel('duplicate',4)
check('Four simultaneous duplicate tokens create exactly one request',result.count('created')==1 and result.count('replay')==3)
r=parallel('rate',8)
check('Atomic rate limit allows exactly three of eight requests',r.count('allowed')==3 and r.count('denied')==5)
check('Eight concurrent audit commits complete',parallel('audit',8)==['logged']*8)
state=json.loads(call('concurrency-worker.php',fixture|{'kind':'check'}))
check('Concurrent approvals use gap-free unique numbers',state['numbers']==[1,2,3,4])
check('Duplicate request has exactly one persisted draft',state['drafts']==1)
check('Audit hash chain intact after all concurrent writes',state['audit_bad'] is None)
print(f'RESULT: {passed} passed; 0 failed; 0 skipped')
