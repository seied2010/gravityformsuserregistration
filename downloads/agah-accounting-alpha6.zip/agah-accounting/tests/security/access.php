<?php
if(!defined('ABSPATH')) exit;
/** ماتریس مجوزها و IDOR در سرویس‌های جدید؛ c1/c2 فقط fixture اجرای جاری‌اند. */
use Agah\Erp\Core\{Db,Ctx,ValidationException,ConflictException,NotFoundException,ForbiddenException};
use Agah\Erp\Modules\Company\{CompanyService,MemberService};
use Agah\Erp\Modules\Accounting\{DetailService,VoucherService,ReportService,AccountService};
$foreignAccount=(int)Db::val('SELECT id FROM '.Db::t('accounts').' WHERE company_id=%d AND level=3 LIMIT 1',$c2);
agah_test('Foreign company context always NotFound',function()use($u1,$c2){agah_throws(NotFoundException::class,function()use($u1,$c2){Ctx::boot($u1,$c2);});});
Ctx::boot($u1,$c1);
agah_test('Foreign account line rejected before DB mutation',function()use($c1,$header,$lines,$foreignAccount){$bad=$lines;$bad[0]['account_id']=$foreignAccount;agah_throws(NotFoundException::class,function()use($c1,$header,$bad){VoucherService::save($c1,0,$header,$bad);});});
agah_test('Company-scoped detail/report/member IDOR rejected',function()use($c1,$c2,$detail,$u2,$viewer,$foreignAccount){agah_throws(NotFoundException::class,function()use($c2,$detail){DetailService::get($c2,$detail);});agah_throws(NotFoundException::class,function()use($c1,$foreignAccount){ReportService::ledger($c1,['account_id'=>$foreignAccount]);});$role=(int)Db::val('SELECT id FROM '.Db::t('roles').' WHERE company_id=%d LIMIT 1',$c2);agah_throws(NotFoundException::class,function()use($c1,$u2,$role){MemberService::change($c1,$u2,$role,'active');});});
Ctx::boot($u2,$c2);$foreignV=VoucherService::save($c2,0,$header,[['account_id'=>(int)AccountService::bySysKey($c2,'capital')['id'],'debit'=>1]]);Ctx::boot($u1,$c1);
agah_test('Voucher foreign id get/edit/state/delete all NotFound',function()use($c1,$foreignV,$header,$lines){foreach([function()use($c1,$foreignV){VoucherService::get($c1,$foreignV);},function()use($c1,$foreignV,$header,$lines){VoucherService::save($c1,$foreignV,$header,$lines,1);},function()use($c1,$foreignV){VoucherService::transition($c1,$foreignV,'approve','',1);},function()use($c1,$foreignV){VoucherService::delete($c1,$foreignV,1);}] as $call)agah_throws(NotFoundException::class,$call);});
agah_test('Service company argument cannot override current context',function()use($c2,$header,$lines){agah_throws(NotFoundException::class,function()use($c2,$header,$lines){VoucherService::save($c2,0,$header,$lines);});});
$viewerUser=wp_insert_user(['user_login'=>'viewer_'.$suffix,'user_email'=>'viewer'.$suffix.'@example.test','user_pass'=>$password,'role'=>'subscriber']);
MemberService::add($c1,['login'=>get_userdata($viewerUser)->user_login,'role_id'=>$viewer]);
$matrix=[
'company_settings.edit'=>function()use($c1){CompanyService::update($c1,['name'=>'غیرمجاز']);},
'member.create'=>function()use($c1,$u2,$viewer){MemberService::add($c1,['login'=>get_userdata($u2)->user_login,'role_id'=>$viewer]);},
'member.edit'=>function()use($c1,$u1,$viewer){MemberService::change($c1,$u1,$viewer,'inactive');},
'role.edit'=>function()use($c1){MemberService::saveRole($c1,0,'غیرمجاز',[]);},
'detail.create'=>function()use($c1){DetailService::save($c1,0,['name'=>'غیرمجاز']);},
'detail.delete'=>function()use($c1,$detail){DetailService::delete($c1,$detail);},
'voucher.create'=>function()use($c1,$header,$lines){VoucherService::save($c1,0,$header,$lines);},
'voucher.edit'=>function()use($c1,$b,$header,$lines){VoucherService::save($c1,$b,$header,$lines,2);},
'voucher.approve'=>function()use($c1,$b){VoucherService::transition($c1,$b,'approve','',2);},
'voucher.finalize'=>function()use($c1,$b){VoucherService::transition($c1,$b,'finalize','',2);},
'voucher.void'=>function()use($c1,$b){VoucherService::transition($c1,$b,'void','آزمون دسترسی',2);},
'voucher.reopen'=>function()use($c1,$b){VoucherService::transition($c1,$b,'reopen','آزمون دسترسی',2);},
'voucher.delete'=>function()use($c1,$b){VoucherService::delete($c1,$b,2);},
];
Ctx::boot($viewerUser,$c1);wp_set_current_user($viewerUser);
foreach($matrix as $cap=>$call) agah_test('Viewer server denies '.$cap,function()use($call){agah_throws(ForbiddenException::class,$call);});
agah_test('Viewer can read vouchers and real ledger',function()use($c1,$b){agah_assert(VoucherService::get($c1,$b)['status']==='approved');agah_assert(ReportService::ledger($c1,['mode'=>'journal'])['count']>0);});
Ctx::boot($u1,$c1);wp_set_current_user($u1);
foreach(\Agah\Erp\Security\Caps::builtinRoles() as $key=>$definition) {
    $roleId=(int)Db::val('SELECT id FROM '.Db::t('roles').' WHERE company_id=%d AND role_key=%s',$c1,$key);
    MemberService::change($c1,$viewerUser,$roleId,'active');Ctx::boot($viewerUser,$c1);
    agah_test('Role matrix exact capabilities '.$key,function()use($definition){foreach(\Agah\Erp\Security\Caps::all() as $cap) agah_assert(Ctx::can($cap)===in_array($cap,$definition[1],true),$cap);});
    Ctx::boot($u1,$c1);
}
agah_test('DB rejects cross-company role assignment',function()use($c1,$c2,$viewerUser){global $wpdb;$old=$wpdb->suppress_errors(true);$role=Db::val('SELECT id FROM '.Db::t('roles').' WHERE company_id=%d LIMIT 1',$c2);$r=$wpdb->update(Db::t('company_members'),['role_id'=>$role],['company_id'=>$c1,'user_id'=>$viewerUser]);$wpdb->suppress_errors($old);$wpdb->last_error='';agah_assert($r===false);});
agah_test('No new business foreign key bypass: voucher detail of foreign company rejected by DB',function()use($c1,$c2,$b,$cash,$u1,$u2){global $wpdb;Ctx::boot($u2,$c2);$d=DetailService::save($c2,0,['code'=>'FOREIGN','name'=>'تفصیلی بیگانه','kind'=>'cash','is_active'=>1]);Ctx::boot($u1,$c1);$old=$wpdb->suppress_errors(true);$r=$wpdb->insert(Db::t('voucher_lines'),['company_id'=>$c1,'voucher_id'=>$b,'line_no'=>99,'account_id'=>$cash['id'],'detail_id'=>$d,'debit'=>1]);$wpdb->suppress_errors($old);$wpdb->last_error='';agah_assert($r===false);});
