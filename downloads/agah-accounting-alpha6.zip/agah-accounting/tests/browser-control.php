<?php
if(!defined('ABSPATH')) exit;
/** کنترل نشست فقط برای آزمون مرورگر؛ در HTTP قابل اجرا نیست و خروجی شامل credential نیست. */
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE) throw new RuntimeException('Disposable test site required');
$job=json_decode($args[0]??'',true);if(!$job)throw new RuntimeException('Missing job');
if($job['kind']==='idle') {
    $uid=(int)$job['uid'];$sessions=get_user_meta($uid,'session_tokens',true);
    foreach($sessions as &$s)$s['agah_last']=time()-1900;unset($s);update_user_meta($uid,'session_tokens',$sessions);echo 'expired';
}
