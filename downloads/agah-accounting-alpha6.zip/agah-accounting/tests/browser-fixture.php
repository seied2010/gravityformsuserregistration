<?php
if(!defined('ABSPATH')) exit;
/** فقط سایت دورریختنی: کاربران و شرکت‌های لازم برای آزمون واقعی HTTP؛ خروجی JSON محرمانهٔ محلی است. */
if(!defined('WP_CLI') || !WP_CLI || !defined('AGAH_TEST_MODE') || !AGAH_TEST_MODE) throw new RuntimeException('Disposable test site required');
use Agah\Erp\Core\{Db,Crypto,Ctx};
use Agah\Erp\Modules\Company\{CompanyService,MemberService};
use Agah\Erp\Modules\Accounting\{AccountService,DetailService};
// فقط DB دورریختنیِ دارای پرچم تست: سهمیه‌های اجرای قبلی نباید آزمون تازه را به خطا بیندازند.
Db::exec('DELETE FROM '.Db::t('rate_limits'));
$s=Crypto::token(4);$pass='Agah-'.Crypto::token(16).'-2026';
$login='browser_'.$s;$uid=wp_insert_user(['user_login'=>$login,'user_pass'=>$pass,'user_email'=>$login.'@example.test','role'=>'administrator']);
$other='outsider_'.$s;$oid=wp_insert_user(['user_login'=>$other,'user_pass'=>$pass,'user_email'=>$other.'@example.test','role'=>'administrator']);
$viewer='browser_viewer_'.$s;$vid=wp_insert_user(['user_login'=>$viewer,'user_pass'=>$pass,'user_email'=>$viewer.'@example.test','role'=>'subscriber']);
$c1=CompanyService::create($uid,['name'=>'شرکت آزمون مرورگر','jy'=>1405]);$c2=CompanyService::create($oid,['name'=>'شرکت بیگانه مرورگر','jy'=>1405]);
Ctx::boot($uid,$c1);$role=(int)Db::val('SELECT id FROM '.Db::t('roles')." WHERE company_id=%d AND role_key='viewer'",$c1);MemberService::add($c1,['login'=>$viewer,'role_id'=>$role]);
$detail=DetailService::save($c1,0,['code'=>'CASH','name'=>'صندوق تست','kind'=>'cash','is_active'=>1]);
$cash=AccountService::bySysKey($c1,'cash');$capital=AccountService::bySysKey($c1,'capital');
echo wp_json_encode(['login'=>$login,'password'=>$pass,'uid'=>$uid,'other'=>$other,'oid'=>$oid,'viewer'=>$viewer,'viewer_id'=>$vid,'c1'=>$c1,'c2'=>$c2,'detail'=>$detail,'cash'=>$cash['id'],'capital'=>$capital['id'],'page_id'=>(int)get_option('agah_erp_page_id')]);
