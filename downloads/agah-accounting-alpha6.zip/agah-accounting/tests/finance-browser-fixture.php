<?php
/** fixture خصوصی مراحل۱۰–۱۲؛ خارج از محیط تست اجرا نمی‌شود. */
if(!defined('ABSPATH')||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
ob_start();require __DIR__.'/browser-fixture.php';$f=json_decode(ob_get_clean(),true);
use Agah\Erp\Core\{Ctx,Db};
use Agah\Erp\Modules\Accounting\AccountService;
use Agah\Erp\Modules\Expenses\ExpenseService;
use Agah\Erp\Modules\Parties\PartyService;
use Agah\Erp\Modules\Treasury\TreasuryService;
use Agah\Erp\Modules\Catalog\CatalogService;
use Agah\Erp\Modules\Inventory\StockService;
use Agah\Erp\Modules\Trade\InvoiceService;
Ctx::boot($f['uid'],$f['c1']);$c=$f['c1'];$f['party']=PartyService::save($c,0,['name'=>'شخص مالی مرورگر','kind'=>'real','is_customer'=>1,'is_supplier'=>1,'is_active'=>1]);$f['bank']=TreasuryService::saveAccount($c,0,['name'=>'بانک مالی مرورگر','code'=>'FB','kind'=>'bank','is_active'=>1]);$f['category']=ExpenseService::saveLookup($c,'category',0,['code'=>'EX','name'=>'هزینه مالی مرورگر','kind'=>'expense','account_id'=>(int)AccountService::bySysKey($c,'other_expense')['id'],'is_active'=>1]);$f['income_category']=ExpenseService::saveLookup($c,'category',0,['code'=>'IN','name'=>'درآمد مالی مرورگر','kind'=>'income','account_id'=>(int)AccountService::bySysKey($c,'other_income')['id'],'is_active'=>1]);
$f['expense']=ExpenseService::issue($c,['category_id'=>$f['category'],'party_id'=>$f['party'],'doc_date'=>'2026-10-17','due_date'=>'2026-10-18','amount'=>200]);ExpenseService::issue($c,['category_id'=>$f['income_category'],'party_id'=>$f['party'],'doc_date'=>'2026-10-17','due_date'=>'2026-10-18','amount'=>500],[['method'=>'transfer','treasury_account_id'=>$f['bank'],'amount'=>300]]);
$unit=(int)Db::val('SELECT id FROM '.Db::t('units').' WHERE company_id=%d LIMIT 1',$c);$base=['code'=>'S','name'=>'خدمت جست‌وجوی مالی','kind'=>'service','unit_id'=>$unit,'sale_account_id'=>(int)AccountService::bySysKey($c,'sales_services')['id'],'purchase_account_id'=>(int)AccountService::bySysKey($c,'purchases')['id'],'is_active'=>1];$svc=CatalogService::save($c,'item',0,$base);$inv=InvoiceService::save($c,0,['kind'=>'sale','party_id'=>$f['party'],'invoice_date'=>'2026-10-17','due_date'=>'2026-10-18'],[['item_id'=>$svc,'qty_scaled'=>10000,'unit_price'=>200]]);InvoiceService::issue($c,$inv,1);
TreasuryService::issue($c,['kind'=>'receipt','doc_date'=>'2026-10-17','party_id'=>$f['party']],[['method'=>'cheque','treasury_account_id'=>$f['bank'],'amount'=>50,'cheque_no'=>'FIN-BROWSER','due_date'=>'2026-10-18']]);$w=StockService::saveWarehouse($c,0,['name'=>'انبار اعلان','code'=>'N','is_active'=>1]);$tax=(int)Db::val('SELECT id FROM '.Db::t('tax_rates')." WHERE company_id=%d AND code='unconfirmed'",$c);$item=CatalogService::save($c,'item',0,array_merge($base,['code'=>'GOOD','kind'=>'goods','name'=>'کالای اعلان مالی','tax_rate_id'=>$tax,'sale_account_id'=>(int)AccountService::bySysKey($c,'sales_goods')['id']]));StockService::setMinimum($c,$w,$item,10000);
$f['expense_account']=(int)AccountService::bySysKey($c,'other_expense')['id'];$f['year']=(int)Db::val('SELECT id FROM '.Db::t('fiscal_years').' WHERE company_id=%d LIMIT 1',$c);$f['before']=count(\Agah\Erp\Core\Schema::tables());
Ctx::boot($f['oid'],$f['c2']);$fp=PartyService::save($f['c2'],0,['name'=>'شخص بیگانه مالی','kind'=>'real','is_supplier'=>1,'is_active'=>1]);$fc=ExpenseService::saveLookup($f['c2'],'category',0,['code'=>'F','name'=>'سرفصل بیگانه','kind'=>'expense','account_id'=>(int)AccountService::bySysKey($f['c2'],'other_expense')['id'],'is_active'=>1]);$f['foreign_expense']=ExpenseService::issue($f['c2'],['category_id'=>$fc,'party_id'=>$fp,'doc_date'=>'2026-10-17','due_date'=>'2026-10-18','amount'=>100]);
echo wp_json_encode($f);
