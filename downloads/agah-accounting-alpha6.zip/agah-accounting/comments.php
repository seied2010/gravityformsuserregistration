<?php
if ( ! defined( 'ABSPATH' ) || post_password_required() ) return;
?>
<section id="comments" class="comments">
<?php if ( have_comments() ) : ?>
	<h2><?php echo esc_html( number_format_i18n( get_comments_number() ) ); ?> دیدگاه</h2>
	<ol class="comment-list"><?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true ) ); ?></ol>
	<?php the_comments_navigation(); ?>
<?php endif; ?>
<?php comment_form( array( 'title_reply' => 'دیدگاه خود را بنویسید', 'label_submit' => 'ارسال دیدگاه' ) ); ?>
</section>
