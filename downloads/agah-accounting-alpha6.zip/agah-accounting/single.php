<?php
if(!defined('ABSPATH')) exit; get_header(); while ( have_posts() ) : the_post(); $cat = agah_primary_category(); ?>
<article <?php post_class( 'post-single' ); ?>>
	<header class="post-head"><div class="shell narrow">
		<?php agah_breadcrumbs(); ?>
		<?php if ( $cat ) : ?><a class="chip-cat" href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a><?php endif; ?>
		<h1><?php the_title(); ?></h1>
		<div class="meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time> <span aria-hidden="true">•</span> <?php echo esc_html( agah_reading_time() ); ?></div>
	</div></header>

	<?php if ( has_post_thumbnail() ) : ?>
	<div class="shell narrow wide"><figure class="post-cover"><?php the_post_thumbnail( 'large' ); ?></figure></div>
	<?php endif; ?>

	<div class="shell narrow">
		<div class="post-content"><?php the_content(); wp_link_pages(); ?></div>
		<?php the_tags( '<div class="post-tags">', '', '</div>' ); ?>
		<nav class="post-nav" aria-label="نوشته‌های بعدی و قبلی">
			<?php previous_post_link( '<div class="nav-prev">%link</div>', 'قبلی: %title' ); ?>
			<?php next_post_link( '<div class="nav-next">%link</div>', 'بعدی: %title' ); ?>
		</nav>
	</div>

	<?php
	$ids = wp_get_post_categories( get_the_ID() );
	$rel = new WP_Query( array( 'category__in' => $ids, 'post__not_in' => array( get_the_ID() ), 'posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
	if ( $rel->have_posts() ) : ?>
	<section class="section section-tint related"><div class="shell">
		<div class="section-head"><h2>نوشته‌های مرتبط</h2></div>
		<div class="grid grid-3"><?php while ( $rel->have_posts() ) : $rel->the_post(); get_template_part( 'template-parts/card' ); endwhile; wp_reset_postdata(); ?></div>
	</div></section>
	<?php endif; ?>

	<?php if ( comments_open() || get_comments_number() ) : ?>
	<div class="shell narrow comments-wrap"><?php comments_template(); ?></div>
	<?php endif; ?>
</article>
<?php endwhile; get_footer(); ?>
