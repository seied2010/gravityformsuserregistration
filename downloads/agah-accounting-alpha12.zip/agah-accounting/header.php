<!DOCTYPE html>
<html <?php
if(!defined('ABSPATH')) exit; language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preload" href="<?php echo esc_url( get_template_directory_uri() . '/assets/fonts/vazirmatn.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#content">پرش به محتوا</a>

<?php $tb = agah_mod( 'agah_topbar_text', '' ); if ( $tb ) : ?>
<div class="topbar"><div class="shell">
	<span data-agah="agah_topbar_text"><?php echo esc_html( $tb ); ?></span>
	<?php $ph = agah_mod( 'agah_phone', '' ); if ( $ph ) : ?>
		<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $ph ) ); ?>" dir="ltr"><?php echo esc_html( $ph ); ?></a>
	<?php endif; ?>
</div></div>
<?php endif; ?>

<header class="site-header"><div class="shell">
	<a class="brand" data-agah="custom_logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php if ( has_custom_logo() ) : echo wp_get_attachment_image((int)get_theme_mod('custom_logo'),'full',false,['class'=>'custom-logo','alt'=>get_bloginfo('name')]); else : ?>
			<span class="brand-mark" data-agah="agah_mark" aria-hidden="true"><?php echo esc_html( agah_mod( 'agah_mark', 'ID' ) ); ?></span>
			<span data-agah="blogname"><?php bloginfo( 'name' ); ?></span>
		<?php endif; ?>
	</a>
	<button class="nav-toggle" aria-controls="main-nav" aria-expanded="false">منو</button>
	<nav id="main-nav" class="main-nav" aria-label="منوی اصلی">
		<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'nav-menu', 'fallback_cb' => 'agah_fallback_menu' ) ); ?>
	</nav>
	<div class="header-cta">
		<?php if ( is_user_logged_in() && ! is_customize_preview() ) : ?>
			<a class="btn btn-outline btn-sm" href="<?php echo esc_url( agah_acc_page_url() ); ?>">سامانه حسابداری</a>
			<a class="btn btn-primary btn-sm" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">خروج</a>
		<?php else : ?>
		<?php if ( $t = agah_mod( 'agah_login_text', 'ورود' ) ) : ?><a class="btn btn-outline btn-sm" data-agah="agah_login_url" href="<?php echo esc_url( agah_mod( 'agah_login_url', agah_acc_page_url() ) ); ?>"><span data-agah="agah_login_text"><?php echo esc_html( $t ); ?></span></a><?php endif; ?>
		<?php if ( $t = agah_mod( 'agah_signup_text', 'شروع رایگان' ) ) : ?><a class="btn btn-primary btn-sm" data-agah="agah_signup_url" href="<?php echo esc_url( agah_mod( 'agah_signup_url', '#pricing' ) ); ?>"><span data-agah="agah_signup_text"><?php echo esc_html( $t ); ?></span></a><?php endif; ?>
	</div>
		<?php endif; ?>
	</div>
</div></header>
<main id="content">
