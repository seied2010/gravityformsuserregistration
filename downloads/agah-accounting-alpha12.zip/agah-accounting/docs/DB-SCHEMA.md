> **Schema10 / alpha11:** چهار جدول production_boms، production_bom_lines، production_orders و production_order_lines و دو FK nullable تولید به stock_moves افزوده شدند؛ تعداد جدول‌ها۶۰ است. قرارداد پول صد‌م ریال Schema9 حفظ می‌شود. [قرارداد تولید](MANUFACTURING-ALPHA11.md).

> **Schema9:** ستون‌های مبلغ BIGINT، اکنون یک‌صدم ریال‌اند؛ Qty×۱۰۰۰۰ و نرخ basis point بدون تغییر. تبدیل داده و snapshot با PrecisionMigration تراکنشی است. ستون‌های کد کالای snapshot، پستی/ثبت شخص و اجزای معاف حقوق افزوده‌اند؛۵۶جدول ثابت‌اند. شرح ارتقا و حدود در CORRECTIONS-ALPHA8.md است. توضیحات نسخه‌های پیشین زیر تاریخی‌اند.

# ساختار پایگاه داده — Schema6 (۴۷ جدول)

افزوده‌های جاری در بخش Schema6 انتهای سند آمده‌اند؛ بخش‌های قبلی تاریخچه ساختار هستند.

جدول‌های پایهٔ Schema 4 در فهرست زیر حفظ شده‌اند؛ هفت جدول و ستون‌های تازه در بخش «Schema 5 — alpha4» انتهای همین سند آمده‌اند.

تمام جدول‌ها پیشوند `{wpdb->prefix}agah_`، موتور InnoDB و charset سایت دارند. مبالغ BIGINT ریال، تاریخ حسابداری DATE میلادی و زمان ثبت UTC است. Schema 1 نسخهٔ ورودی بود؛ تحویل مراحل ۱–۳ با Schema 3 به‌صورت افزایشی نصب/ارتقا می‌شود. `schema_migrations(version,applied_at)` اجرای موفق نسخه را ثبت می‌کند؛ هیچ backfill یا حذف داده‌ای در این ارتقا وجود ندارد.

| جدول | کلید/رابطهٔ اصلی | کاربرد/حذف |
|---|---|---|
| companies | id، uuid یکتا | شرکت؛ حذف UI ندارد |
| roles | unique(company_id,role_key)، unique(company_id,id)، FK company | نقش مستقل شرکت؛ نقش سفارشی بدون سابقه قابل حذف |
| role_caps | role_id,cap؛ FK role با CASCADE | ماتریس مجوزهای نقش |
| company_members | company_id,user_id؛ FK مرکب نقش | عضویت؛ حذف منطقی status=removed |
| settings | company_id,skey | تنظیمات whitelist؛ company_id=0 پلتفرم |
| fiscal_years | company_id,id؛ FK company | سال مالی؛ closing_voucher_id رزرو مرحلهٔ ۱۱ |
| fiscal_periods | company_id,fiscal_year_id؛ FK مرکب سال | دوره‌های ماهانه |
| accounts | company_id,code/sys_key/id یکتا؛ parent_id FK مرکب | کدینگ؛ سیستم/دارای گردش حذف نمی‌شود |
| details | company_id,code/id یکتا؛ FK company | تفصیلی؛ دارای گردش حذف نمی‌شود |
| vouchers | uuid؛ unique(company_id,fiscal_year_id,number)؛ FK مرکب سال | number=NULL پیش‌نویس؛ revision جدید برای تعارض ویرایش |
| voucher_lines | company_id + voucher/account/detail FK مرکب | CASCADE فقط برای حذف پیش‌نویس از سرویس؛ FK از اتصال بیگانه جلوگیری می‌کند |
| sequences | company_id,fiscal_year_id,kind | شمارندهٔ تراکنشی بدون فاصله |
| audit_log | id؛ company_id,id یکتا؛ ایندکس شرکت/زمان، موجودیت و رویداد | فقط افزودنی؛ هش قبلی/فعلی؛ بدون حذف UI |
| idempotency | token SHA256 کلید اصلی؛ index(company_id,user_id)، expires_at | action، request_hash، pending/done و result_url؛ TTL ۲۴ ساعت |
| auth_states | user_id کلید اصلی | راز و راز معلق رمزنگاری‌شده، نشست/انقضای معلق، last_step، HMACهای بازیابی و version |
| rate_limits | bucket HMAC کلید اصلی؛ index expires_at | شمارندهٔ اتمیک با پنجرهٔ ثابت |
| login_otp | (user_id,session_hash) کلید اصلی؛ index expires_at | code_hash، انقضا، تلاش و مصرف |
| audit_heads | company_id کلید اصلی | mutex ردیفی تا commit؛ company_id=0 برای رویداد امنیتی |
| schema_migrations | version کلید اصلی | ثبت زمان موفقیت مهاجرت |

جدول‌های امنیت شخصی، به کاربر WordPress تعلق دارند و company_id ندارند؛ آن‌ها موجودیت تجاری بین‌شرکتی نیستند. idempotency و audit_heads ممکن است برای عمل پلتفرمی company_id=0 داشته باشند و به رکورد مالی خارجی اشاره نمی‌کنند؛ FK به companies برای این دو تعریف نشده است. روابط تجاری موجود با کلید مرکب حفظ شده‌اند و آزمون اتصال نقش/حساب/تفصیلی بیگانه در DB اجرا شده است.

```mermaid
erDiagram
 companies ||--o{ roles : company_id
 roles ||--o{ company_members : "company_id role_id"
 roles ||--o{ role_caps : role_id
 companies ||--o{ fiscal_years : company_id
 fiscal_years ||--o{ fiscal_periods : "company_id fiscal_year_id"
 fiscal_years ||--o{ vouchers : "company_id fiscal_year_id"
 vouchers ||--o{ voucher_lines : "company_id voucher_id"
 accounts ||--o{ voucher_lines : "company_id account_id"
 details ||--o{ voucher_lines : "company_id detail_id"
```

DDL مرجع در `erp/src/Core/Schema.php` است. هیچ مسیر downgrade خودکار وجود ندارد. بازگردانی نسخه از پشتیبان کامل فایل و DB انجام شود؛ تغییر شمارهٔ گزینهٔ Schema، جایگزین بازیابی نیست.


## افزوده‌های مراحل ۴ تا ۶

DDL مرجع جدید `Core/BusinessSchema.php` است و در Schema نصب می‌شود. تمام جدول‌های زیر id,uuid,company_id,created_at,updated_at و UNIQUE(company_id,id) دارند. همهٔ روابط تجاری FK مرکب‌اند؛ voucher_lines نیز کلید یکتای مرکب برای ارجاع مغایرت‌گیری گرفته است.

| جدول | محتوا و روابط |
|---|---|
| parties | کد یکتا، نوع، نقش مشتری/تأمین‌کننده، شناسهٔ رمزشده+ایندکس کور+hint، سقف اعتبار؛ detail_id |
| units / item_groups | واحد و گروه واقعی با code یکتا و وضعیت فعال |
| tax_rates | code+valid_from یکتا، بازهٔ زمانی، bp nullable، confirmed و revision |
| items | واحد/گروه/نرخ و دو حساب معین؛ قیمت صحیح ریال و بارکد یکتا |
| treasury_accounts | نوع bank/cash/petty، جزئیات بانکی، تفصیلی انحصاری و حساب معین |
| treasury_docs | نوع/سال/شمارهٔ یکتا، تاریخ، شخص/مبدأ/مقصد، پیش‌دریافت/پرداخت، مبلغ، سند و وضعیت |
| treasury_doc_items | شمارهٔ ردیف، روش، حساب، مبلغ و ارجاع؛ doc_id |
| cheques | برگه/قلم/شخص/بانک، جهت، شماره، سررسید، مبلغ، status/revision |
| cheque_events | وضعیت قبلی/جدید، تاریخ و دلیل، سند اختیاری برای گذار مالی |
| invoices / invoice_lines | قرارداد اولیهٔ تسویهٔ فاکتور و snapshot مالیات؛ UI صدور در مراحل ۷–۸ |
| settlements | فاکتور + برگه + قلم، مبلغ، active/reversed؛ برگشت قلم فقط سهم همان قلم را آزاد می‌کند |
| bank_reconciliations | بانک/تاریخ یکتا، ماندهٔ صورتحساب و revision |
| bank_reconciliation_items | سطر دفتر + مغایرت‌گیری؛ تطبیق اتمیک و هم‌بانکی در سرویس |

ارتقای ۳→۴ داده‌های قدیمی را نگه می‌دارد. فقط نقش company_admin مجوزهای جدید party.sensitive و tax_rate.confirm می‌گیرد؛ نقش سفارشی و حسابدار به‌صورت خودکار مجوز حساس نمی‌گیرند. ثبت مهاجرت نسخهٔ ۴ و دادهٔ پایهٔ واحد «عدد» و نرخ نامشخص، افزوده‌های مورد انتظارند. حذف رکوردهای دارای گردش/ارجاع ممنوع و حذف برگهٔ خزانه صرفاً ابطال است.

## Schema 5 — alpha4

۴۱ جدول: هفت جدول تازه warehouses,stock_docs,stock_moves,stock_layers,stock_picks,stock_minimums,invoice_advances. هر کدام id/uuid/company_id و UNIQUE(company_id,id) و زمان UTC دارند. تمام ارجاعات به انبار/کالا/فاکتور/خط/لایه/برگه خزانه و سند با FK مرکب RESTRICT هستند؛ در TradeSchema::fks تعریف و آزمایش شده‌اند.

invoices: parent_id مرکب به invoices، revision، created_by، description، discount_amount/extra_cost، cost_basis، goods_mode/cost_method snapshot و print_snapshot بدون شناسه محرمانه. invoice_lines: source_line_id مرکب به invoice_lines، warehouse_id مرکب، نام کالا/واحد snapshot، gross/discount/header_discount/extra_cost/total_cost با int ریال. qty_scaled قبلی int×10000 حفظ شد؛ تغییر نوع و تبدیل اعشاری پنهان نداریم. treasury_docs.counter_sys حساب مقابل استرداد را ثبت می‌کند.

stock_moves مقدار و ارزش علامت‌دار و مبدأ واقعی دارد. stock_layers مانده FIFO و stock_picks برداشت هر لایه را نگه می‌دارند. ابطال status را void می‌کند و برداشت‌ها را بازمی‌گرداند؛ ردیف مالی حذف نمی‌شود. invoice_advances مبلغ اعمال‌شدهٔ پیش‌پرداخت و وضعیت دارد.

روابط: warehouses/items → stock_moves → stock_layers → stock_picks؛ invoices → invoice_lines → stock_moves؛ invoices/treasury_docs → invoice_advances. parent_id/source_line_id مسیر تبدیل/برگشت را حفظ می‌کنند. ارتقا افزایشی است و ستون‌های قدیمی دست‌نخورده‌اند؛ دادهٔ مالی نمونه seed نمی‌شود.

## Schema6 — alpha5

شش جدول افزایشی: cost_dimensions (نوع، کد، نام، تفصیلی اختیاری مرکز)، expense_categories (نوع و حساب)، expense_docs (سال/شماره/تاریخ/سررسید/مبلغ/شخص/سه بُعد/سند/وضعیت)، expense_settlements (برگه هزینه به قلم خزانه)، expense_images (MIME/SHA256/اندازه/BLOB خصوصی) و year_closings (سال مبدأ/بعد، active_slot، اسناد تعدیل/موقت/نتیجه/اختتامیه/افتتاحیه، snapshot دوره و مانده و دلایل).

همگی UUID و company_id و UNIQUE(company_id,id) و زمان UTC دارند. تمام ارجاعات با FK مرکب RESTRICT هستند. unique(company_id,fiscal_year_id,active_slot) فقط یک بستن فعال را می‌پذیرد؛ run بازگشایی‌شده active_slot=NULL می‌گیرد. هیچ ردیف مالی فیزیکی حذف نمی‌شود. ایندکس invoices(company_id,status,invoice_date,kind) به گزارش ماهانه کمک می‌کند. ساختار و محتوای جدول‌های قبلی حذف/تبدیل نمی‌شوند.

مسیرها: دسته/شخص/ابعاد → expense_docs → expense_images؛ expense_docs/treasury_docs/treasury_doc_items → expense_settlements؛ fiscal_years و پنج voucher → year_closings. نمونه مالی seed نمی‌شود. برای backup BLOB از روش binary-safe استفاده شود.

## Schema7 — alpha6

۹ جدول افزایشی در OperationsSchema: files با چهار FK اختیاری مبدأ، نام اصلی/تصادفی، دسته، MIME/hash/size و mediumblob؛ employeesتفصیلیکارمند؛ contractsبازه و حقوقثابت؛ attendanceماه‌کارمند/کار/مرخصی/اضافه‌کار/متغیر/کسورات؛ payroll_paramsJSONسالمالی؛ payslipsشماره/ماه/خالص/ناخالص/بیمه/مالیات/snapshot/سند/active_slot؛ payslip_itemsاقلام‌محاسبه؛ assetsروش/عمر/نرخ/بها/اسقاط/حساب‌ها؛ asset_eventsخرید/استهلاک/واگذاری/تاریخ/ماه/عواید/snapshot/سند/active_slot.

همهcompany_id,UUID,زمانUTC وUNIQUE(company_id,id) دارند؛ FKهای مرکب RESTRICT. فیش یکتاcompany/employee/period/active_slot، استهلاک یکتاcompany/asset/period/active_slot است. ابطال active_slotراNULLمی‌کند تا تاریخچه باقی بماند و صدورجدید ممکن شود. فقط خود فایل قابلحذففیزیکی است؛ payroll/assetsمالی حذف نمی‌شوند. ستون/تصویرقبلی تغییری نکرده است.

مهاجرت به نقش‌هایbuiltinمدیر/حسابدار فقط capsتازهpayroll/asset اضافه می‌کند؛ نقشcustomبدونتغییر. حسابasset_lossدرصورتفقدان زیرکل۷۰۳ در کدخالی۷۰۳۰۳–۷۰۳۹۹ افزوده می‌شود؛ هیچ حسابقدیمی بازنویسی نمی‌شود. حسابهایseedشرکتجدید همین حساب را دارند. درنبودکل۷۰۳یاکدخالی، حساب مناسب باید دستی تعریف شود. نمونه مالی ساخته نمی‌شود.

## Schema8 — alpha7

جدول تازه‌ای ندارد و۵۶جدول قبلی حفظ می‌شوند. ReleaseSetup فقط capsهایlegal.view/edit/export وhealth.view را به نقش‌های داخلی مربوط اضافه می‌کند؛ هیچ نقش سفارشی یا ردیف مالی قدیمی بازنویسی نمی‌شود. تنظیم‌های legal_vat_credit_mode (پیش‌فرضreview) وlegal_vat_credit_note در جدول settings موجود و scopedبهشرکت‌اند. snapshotهای فاکتور و حقوق منبع گزارش قانونی باقی می‌مانند. رکورد نسخه مهاجرت افزوده می‌شود.

پشتیبان فایل .agah رمز‌شده خارج وب است؛ جدول ذخیره فایل عمومی برای آن ساخته نمی‌شود. وضعیت کلی اجرا/هویت نصب/مانع موقت restore در WordPress options است و داده مالی آشکار یا کلید در آن ثبت نمی‌شود. restore مالی رفتار خاص احراز هویت دارد؛ BACKUP-RECOVERY.md مرجع است. کلیدهای خارجی حین بازیابی خاموش نمی‌شوند.
