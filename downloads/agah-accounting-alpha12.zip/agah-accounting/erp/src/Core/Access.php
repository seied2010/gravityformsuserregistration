<?php
/** درگاه سرویس‌های عمومی: زمینه و مجوز اجباری؛ قفل شرکت همهٔ تغییرات پیکربندی/مالی را سری می‌کند. */
namespace Agah\Erp\Core;
if(!defined('ABSPATH')) exit;
final class Access {
    public static function need($cid,$cap) {
        if(Ctx::cidOrZero()!==(int)$cid) throw new NotFoundException();
        Ctx::need($cap);
    }
    /** قفل شرکت باید پیش از قفل سال/حساب/سند گرفته شود تا ترتیب قفل‌ها یکسان بماند. */
    public static function write($cid,$cap,callable $fn) {
        if(class_exists('Agah\\Erp\\Modules\\Maintenance\\BackupService')&&\Agah\Erp\Modules\Maintenance\BackupService::blocked())throw new ConflictException('بازیابی سامانه در حال اجراست؛ کمی بعد تلاش کنید.');
        self::need($cid,$cap);
        return Db::tx(function()use($cid,$cap,$fn){
            if(!Db::row('SELECT id FROM '.Db::t('companies').' WHERE id=%d FOR UPDATE',$cid)) throw new NotFoundException();
            Ctx::boot(Ctx::uid(),$cid,true);
            Ctx::need($cap);
            return $fn();
        });
    }
}
