<?php
/** Schema7: private attachments, payroll snapshots and fixed-asset ledger. Additive only. */
namespace Agah\Erp\Core;
if(!defined('ABSPATH'))exit;
final class OperationsSchema {
    public static function tables(){return ['files','employees','contracts','attendance','payroll_params','payslips','payslip_items','assets','asset_events']; }
    public static function ddl($p,$c){$defs=[
'files'=>"invoice_id bigint(20) unsigned DEFAULT NULL,\n  voucher_id bigint(20) unsigned DEFAULT NULL,\n  party_id bigint(20) unsigned DEFAULT NULL,\n  expense_id bigint(20) unsigned DEFAULT NULL,\n  original_name varchar(190) NOT NULL,\n  stored_name char(64) NOT NULL,\n  category varchar(80) NOT NULL DEFAULT '',\n  mime varchar(60) NOT NULL,\n  sha256 char(64) NOT NULL,\n  byte_size int(10) unsigned NOT NULL,\n  file_data mediumblob NOT NULL,\n  created_by bigint(20) unsigned NOT NULL,\n  KEY company_search (company_id,category),",
'employees'=>"code varchar(30) NOT NULL,\n  name varchar(190) NOT NULL,\n  detail_id bigint(20) unsigned NOT NULL,\n  is_active tinyint(1) NOT NULL DEFAULT 1,\n  UNIQUE KEY company_code (company_id,code),",
'contracts'=>"employee_id bigint(20) unsigned NOT NULL,\n  start_date date NOT NULL,\n  end_date date NOT NULL,\n  base_salary bigint(20) unsigned NOT NULL,\n  benefits bigint(20) unsigned NOT NULL,\n  benefits_insurance_exempt bigint(20) unsigned NOT NULL DEFAULT 0,\n  benefits_tax_exempt bigint(20) unsigned NOT NULL DEFAULT 0,\n  overtime_base_extra bigint(20) unsigned NOT NULL DEFAULT 0,\n  KEY company_employee (company_id,employee_id,start_date,end_date),",
'attendance'=>"employee_id bigint(20) unsigned NOT NULL,\n  fiscal_year_id bigint(20) unsigned NOT NULL,\n  period_key char(7) NOT NULL,\n  work_days int(10) unsigned NOT NULL,\n  leave_days int(10) unsigned NOT NULL,\n  overtime_minutes int(10) unsigned NOT NULL,\n  extra_benefits bigint(20) unsigned NOT NULL,\n  extra_insurance_exempt bigint(20) unsigned NOT NULL DEFAULT 0,\n  extra_tax_exempt bigint(20) unsigned NOT NULL DEFAULT 0,\n  deductions bigint(20) unsigned NOT NULL,\n  UNIQUE KEY company_period (company_id,employee_id,period_key),",
'payroll_params'=>"fiscal_year_id bigint(20) unsigned NOT NULL,\n  params_json longtext NOT NULL,\n  UNIQUE KEY company_year (company_id,fiscal_year_id),",
'payslips'=>"employee_id bigint(20) unsigned NOT NULL,\n  contract_id bigint(20) unsigned NOT NULL,\n  attendance_id bigint(20) unsigned NOT NULL,\n  fiscal_year_id bigint(20) unsigned NOT NULL,\n  period_key char(7) NOT NULL,\n  number int(10) unsigned NOT NULL,\n  doc_date date NOT NULL,\n  status varchar(10) NOT NULL DEFAULT 'issued',\n  active_slot tinyint(1) unsigned DEFAULT 1,\n  gross bigint(20) unsigned NOT NULL,\n  insurance_employee bigint(20) unsigned NOT NULL,\n  insurance_employer bigint(20) unsigned NOT NULL,\n  tax bigint(20) unsigned NOT NULL,\n  deductions bigint(20) unsigned NOT NULL,\n  net bigint(20) unsigned NOT NULL,\n  snapshot longtext NOT NULL,\n  voucher_id bigint(20) unsigned DEFAULT NULL,\n  UNIQUE KEY company_employee_period (company_id,employee_id,period_key,active_slot),\n  UNIQUE KEY company_number (company_id,fiscal_year_id,number),\n  KEY company_date (company_id,status,doc_date),",
'payslip_items'=>"payslip_id bigint(20) unsigned NOT NULL,\n  kind varchar(30) NOT NULL,\n  amount bigint(20) unsigned NOT NULL,\n  UNIQUE KEY company_item (company_id,payslip_id,kind),",
'assets'=>"code varchar(30) NOT NULL,\n  name varchar(190) NOT NULL,\n  acquired_date date NOT NULL,\n  start_date date NOT NULL,\n  cost bigint(20) unsigned NOT NULL,\n  residual bigint(20) unsigned NOT NULL,\n  method varchar(12) NOT NULL,\n  life_months int(10) unsigned NOT NULL,\n  annual_bp int(10) unsigned NOT NULL,\n  asset_account_id bigint(20) unsigned NOT NULL,\n  contra_account_id bigint(20) unsigned NOT NULL,\n  expense_account_id bigint(20) unsigned NOT NULL,\n  status varchar(10) NOT NULL DEFAULT 'active',\n  UNIQUE KEY company_code (company_id,code),",
'asset_events'=>"asset_id bigint(20) unsigned NOT NULL,\n  kind varchar(12) NOT NULL,\n  doc_date date NOT NULL,\n  period_key char(7) DEFAULT NULL,\n  active_slot tinyint(1) unsigned DEFAULT 1,\n  amount bigint(20) unsigned NOT NULL,\n  proceeds bigint(20) unsigned NOT NULL DEFAULT 0,\n  account_id bigint(20) unsigned DEFAULT NULL,\n  detail_id bigint(20) unsigned DEFAULT NULL,\n  status varchar(10) NOT NULL DEFAULT 'issued',\n  voucher_id bigint(20) unsigned DEFAULT NULL,\n  snapshot longtext NOT NULL,\n  KEY company_asset (company_id,asset_id,status,doc_date),\n  UNIQUE KEY company_period (company_id,asset_id,period_key,active_slot),",
        ];$out=[];foreach($defs as $name=>$body)$out[]="CREATE TABLE {$p}{$name} (\n  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n  uuid char(36) NOT NULL,\n  company_id bigint(20) unsigned NOT NULL,\n  $body\n  created_at datetime NOT NULL,\n  updated_at datetime NOT NULL,\n  PRIMARY KEY  (id),\n  UNIQUE KEY uuid (uuid),\n  UNIQUE KEY company_id_id (company_id,id)\n) $c;";return $out;
    }
    public static function fks(){ $out=[];foreach(self::tables() as $t)$out[]=[$t,'fk_o_'.$t.'_company',['company_id'],'companies',['id'],'RESTRICT'];$refs=[
'files'=>['invoice_id'=>'invoices','voucher_id'=>'vouchers','party_id'=>'parties','expense_id'=>'expense_docs'],
'employees'=>['detail_id'=>'details'],
'contracts'=>['employee_id'=>'employees'],
'attendance'=>['employee_id'=>'employees','fiscal_year_id'=>'fiscal_years'],
'payroll_params'=>['fiscal_year_id'=>'fiscal_years'],
'payslips'=>['employee_id'=>'employees','contract_id'=>'contracts','attendance_id'=>'attendance','fiscal_year_id'=>'fiscal_years','voucher_id'=>'vouchers'],
'payslip_items'=>['payslip_id'=>'payslips'],
'assets'=>['asset_account_id'=>'accounts','contra_account_id'=>'accounts','expense_account_id'=>'accounts'],
'asset_events'=>['asset_id'=>'assets','account_id'=>'accounts','detail_id'=>'details','voucher_id'=>'vouchers'],
        ];foreach($refs as $t=>$rs)foreach($rs as $col=>$parent)$out[]=[$t,'fk_o_'.$t.'_'.$col,['company_id',$col],$parent,['company_id','id'],'RESTRICT'];return $out; }
    /** Existing custom roles stay unchanged; payroll is private to administrators/accountants by default. */
    public static function seed(){
        foreach(Db::col('SELECT id FROM '.Db::t('companies')) as $cid){
            if(Db::val('SELECT id FROM '.Db::t('accounts')." WHERE company_id=%d AND sys_key='asset_loss'",$cid))continue;
            $parent=Db::val('SELECT id FROM '.Db::t('accounts')." WHERE company_id=%d AND code='703' AND level=2",$cid);if(!$parent)continue;
            for($n=3;$n<=99;$n++){ $code='703'.str_pad((string)$n,2,'0',STR_PAD_LEFT);if(Db::val('SELECT id FROM '.Db::t('accounts').' WHERE company_id=%d AND code=%s',$cid,$code))continue;
                Db::insert('accounts',['company_id'=>$cid,'parent_id'=>$parent,'code'=>$code,'name'=>'زیان واگذاری دارایی ثابت','level'=>3,'nature'=>'debit','stmt_class'=>'other_expense','sys_key'=>'asset_loss','detail_rule'=>'none','detail_kind'=>'','is_system'=>1,'created_at'=>gmdate('Y-m-d H:i:s')]);break;
            }
        }
foreach(['company_admin','accountant'] as $role)foreach(['payroll','asset'] as $r)foreach(['view','create','edit','delete','approve','export'] as $a)Db::exec('INSERT IGNORE INTO '.Db::t('role_caps').' (role_id,cap) SELECT id,%s FROM '.Db::t('roles').' WHERE role_key=%s',$r.'.'.$a,$role);}
}
