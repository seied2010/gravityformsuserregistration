<?php
/** Sales catalogue only. Requests are leads, never payment receipts or ERP entitlements. */
if (!defined('ABSPATH')) exit;
function agah_pricing_catalogue() {
    return array(
        'specialized' => array('name'=>'تخصصی','monthly'=>500000),
        'hybrid' => array('name'=>'ترکیبی','monthly'=>1000000),
        'enterprise' => array('name'=>'سازمانی','monthly'=>null),
    );
}
function agah_pricing_domains(){return array('trading'=>'بازرگانی','manufacturing'=>'تولیدی','services'=>'خدماتی');}
function agah_pricing_open(){return (bool)get_theme_mod('agah_launch_open',true);}
function agah_pricing_amount($plan,$period){
    $plans=agah_pricing_catalogue();
    if(!isset($plans[$plan])||$plan==='enterprise'||!in_array($period,array('monthly','annual'),true))return null;
    $monthly=$plans[$plan]['monthly'];
    return $period==='annual'?intdiv($monthly*108,10):$monthly;
}
function agah_pricing_number($n){return strtr(number_format($n,0,'.',','),array('0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹',','=>'٬'));}
function agah_pricing_value($data,$key){return isset($data[$key])&&is_string($data[$key])?sanitize_key(wp_unslash($data[$key])):'';}
/** Validate all posted selections. Recompute quotations from catalogue, never a browser supplied amount. */
function agah_pricing_selection($data){
    $plan=agah_pricing_value($data,'agah_plan');
    if($plan==='')return array();
    if(!isset(agah_pricing_catalogue()[$plan]))return new WP_Error('plan','طرح معتبر نیست.');
    $domain=agah_pricing_value($data,'agah_domain');$period=agah_pricing_value($data,'agah_period');$method=agah_pricing_value($data,'agah_method');
    if($plan==='specialized'&&!isset(agah_pricing_domains()[$domain]))return new WP_Error('domain','نوع حسابداری را انتخاب کنید.');
    if($plan!=='enterprise'&&!in_array($period,array('monthly','annual'),true))return new WP_Error('period','دوره پرداخت را انتخاب کنید.');
    if(!in_array($method,array('','onsite','zarinpal'),true))return new WP_Error('method','روش پرداخت معتبر نیست.');
    return array('plan'=>$plan,'domain'=>$plan==='specialized'?$domain:'','period'=>$plan==='enterprise'?'':$period,'method'=>$method,'amount_toman'=>agah_pricing_open()?agah_pricing_amount($plan,$period):null,'promotion'=>agah_pricing_open());
}
function agah_pricing_summary($s){
    if(!$s)return '';
    $text='طرح درخواستی: '.agah_pricing_catalogue()[$s['plan']]['name'];
    if($s['domain'])$text.=' — '.agah_pricing_domains()[$s['domain']];
    if($s['period'])$text.="\nدوره: ".($s['period']==='annual'?'سالانه، پرداخت یکجای ۱۲ ماه':'ماهانه');
    if($s['amount_toman']!==null)$text.="\nمبلغ پیشنهادی کل دوره: ".agah_pricing_number($s['amount_toman']).' تومان';
    else $text.="\nقیمت: پس از تماس و توافق";
    if($s['method'])$text.="\nروش پرداخت درخواستی: ".($s['method']==='onsite'?'پرداخت در محل':'زرین‌پال');
    return $text."\nاین درخواست پرداخت یا اشتراک فعال نیست؛ ظرفیت و مبلغ باید پیش از دریافت وجه تأیید شود.";
}
function agah_pricing_assets(){
    if(is_front_page()||is_singular())wp_enqueue_script('agah-pricing',get_template_directory_uri().'/assets/js/pricing.js',array(),AGAH_THEME_VERSION,true);
}
add_action('wp_enqueue_scripts','agah_pricing_assets');
function agah_pricing_customize($c){
    $c->add_setting('agah_launch_open',array('default'=>true,'sanitize_callback'=>function($v){return (bool)$v;},'transport'=>'refresh'));
    $c->add_control('agah_launch_open',array('section'=>'agah_pricing','type'=>'checkbox','label'=>'جشنواره افتتاحیه باز است (پس از ۱۰ مشتری پرداخت‌کننده ببندید)','description'=>'فعلاً فروش با تأیید مدیریت انجام می‌شود؛ ثبت درخواست، ظرفیت جشنواره را رزرو نمی‌کند.'));
}
add_action('customize_register','agah_pricing_customize');
function agah_pricing_render(){
    $open=agah_pricing_open();$plans=agah_pricing_catalogue();
    $common=array('اسناد حسابداری و فاکتورها بدون سقف تعداد','دفتر روزنامه و کل؛ تراز آزمایشی ۶ و ۸ ستونی','ترازنامه و صورت سود و زیان بر پایه اسناد','دریافت و پرداخت، حساب‌های بانکی و پیگیری چک‌ها','مالیات ارزش افزوده با نرخ‌های قابل تنظیم','دسترسی مستقل کاربران و ثبت سابقه تغییرات','خروجی Excel واقعی و چاپ اسناد و فاکتورها','حقوق و دستمزد با پارامترهای قابل تنظیم؛ مدیریت دارایی ثابت');
    ?>
<section class="section section-tint" id="pricing" aria-labelledby="agah-pricing-heading"><div class="shell">
<div class="section-head"><h2 id="agah-pricing-heading"><?php echo esc_html(agah_mod('agah_pr_title','طرح‌ها و قیمت‌ها')); ?></h2>
<p>برای هر شرکت یک اشتراک؛ اسناد و فاکتورها بدون محدودیت تعداد.</p></div>
<p class="agah-launch-banner"><?php echo $open?'جشنواره افتتاحیه — این قیمت‌ها فقط ویژه ۱۰ مشتری اول است.':'جشنواره افتتاحیه پایان یافته است؛ برای تعرفه جدید تماس بگیرید.'; ?></p>
<?php if($open): ?><fieldset class="agah-billing-toggle"><legend>دوره پرداخت</legend><label><input type="radio" name="agah_billing_view" value="monthly" checked> ماهانه</label><label><input type="radio" name="agah_billing_view" value="annual"> سالانه <strong>۱۰٪ تخفیف</strong></label></fieldset>
<p class="agah-pricing-terms">قیمت جشنواره برای دوره خریداری‌شده ثابت است؛ تعرفه تمدید پیش از خرید بعدی اعلام می‌شود. ظرفیت با تأیید پرداخت محاسبه می‌شود؛ ثبت درخواست رزرو نیست.</p><?php endif; ?>
<div class="grid grid-3 agah-pricing-grid">
<?php foreach($plans as $key=>$plan): ?>
<article class="plan <?php echo $key==='hybrid'?'hl':''; ?>" <?php if($key==='hybrid')echo 'data-badge="همه ماژول‌های موجود"'; ?> data-pricing-card="<?php echo esc_attr($key); ?>">
<h3><?php echo esc_html($plan['name']); ?></h3><p class="desc"><?php echo esc_html($key==='specialized'?'یک نوع حسابداری متناسب با فعالیت شما':($key==='hybrid'?'بازرگانی، تولیدی و خدماتی در کنار هم':'نصب اختصاصی روی سرور خریدار')); ?></p>
<?php if($key!=='enterprise'&&$open): ?>
<div class="agah-price-monthly"><div class="price"><?php echo esc_html(agah_pricing_number($plan['monthly'])); ?> <small>تومان در ماه</small></div><p>پرداخت ماهانه: <?php echo esc_html(agah_pricing_number($plan['monthly'])); ?> تومان</p></div>
<div class="agah-price-annual"><div class="price"><?php echo esc_html(agah_pricing_number(intdiv(agah_pricing_amount($key,'annual'),12))); ?> <small>تومان، معادل ماهانه</small></div><p><strong>پرداخت یکجای سال: <?php echo esc_html(agah_pricing_number(agah_pricing_amount($key,'annual'))); ?> تومان</strong></p><p>۱۲ ماه استفاده با ۱۰٪ تخفیف</p></div>
<?php else: ?><div class="price">تماس بگیرید</div><?php endif; ?>
<?php if($key==='specialized'): ?><fieldset class="agah-domain-options"><legend>نوع حسابداری مورد نیاز</legend><?php foreach(agah_pricing_domains() as $d=>$label): ?><label><input type="radio" name="agah_specialty" value="<?php echo esc_attr($d); ?>" <?php checked($d,'trading'); ?>> <?php echo esc_html($label); ?></label><?php endforeach; ?></fieldset><?php endif; ?>
<ul><?php if($key==='enterprise'): foreach(array('استقرار روی سرور خریدار طبق قرارداد','انتخاب ماژول‌ها متناسب با نیاز سازمان','راه‌اندازی و انتقال داده با بررسی فنی','شرایط آموزش و پشتیبانی در قرارداد') as $feature): ?><li><?php echo esc_html($feature); ?></li><?php endforeach; else: foreach($common as $feature): ?><li><?php echo esc_html($feature); ?></li><?php endforeach; ?>
<?php if($key==='hybrid'): ?><li>فروش کالا و خدمات در یک شرکت</li><li>انبار و بهای موجودی با روش میانگین یا FIFO</li><li>فرمول ساخت نسخه‌دار، مصرف مواد و بهای محصول</li>
<?php else: ?><li data-domain-feature="trading">بازرگانی: خرید و فروش، برگشت و گردش انبار</li><li data-domain-feature="services">خدماتی: فاکتور خدمات و پیگیری دریافت از مشتری</li><li data-domain-feature="manufacturing">تولیدی: فرمول ساخت، مصرف واقعی مواد و بهای محصول</li><?php endif; endif; ?></ul>
<?php if($key==='hybrid'||$key==='specialized'): ?><p class="agah-production-note" <?php if($key==='specialized')echo 'data-production-note'; ?>>تولید فعلی: تک‌محصولی، تکمیل یکجا و انبار دائمی؛ تحویل جزئی و برنامه‌ریزی ظرفیت هنوز ارائه نمی‌شود.</p><?php endif; ?>
<a class="btn <?php echo $key==='hybrid'?'btn-primary':'btn-outline'; ?>" data-plan-select="<?php echo esc_attr($key); ?>" href="<?php echo esc_url(add_query_arg(array('agah_plan'=>$key,'agah_domain'=>'trading','agah_period'=>'monthly'),home_url('/')).'#contact'); ?>"><?php echo $key==='enterprise'?'تماس بگیرید':'درخواست طرح '.$plan['name']; ?></a>
</article><?php endforeach; ?></div><p class="agah-pricing-terms">انتخاب طرح، درخواست خرید را ثبت می‌کند. پرداخت و فعال‌سازی پس از تأیید انجام می‌شود؛ این صفحه درگاه پرداخت مستقیم نیست.</p>
<noscript><p>بدون جاوااسکریپت هر دو نرخ ماهانه و سالانه نمایش داده می‌شود؛ دوره و نوع حسابداری را در فرم درخواست انتخاب کنید.</p></noscript>
</div></section>
<?php }
function agah_pricing_contact_fields(){
    $s=agah_pricing_selection($_GET);if(is_wp_error($s))$s=array();
    ?><fieldset class="agah-request-plan"><legend>انتخاب طرح (اختیاری برای درخواست عمومی)</legend>
<label>طرح<select name="agah_plan"><option value="">درخواست عمومی / مشاوره</option><?php foreach(agah_pricing_catalogue() as $key=>$p): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($s['plan']??'',$key); ?>><?php echo esc_html($p['name']); ?></option><?php endforeach; ?></select></label>
<label data-request-domain>نوع حسابداری<select name="agah_domain"><?php foreach(agah_pricing_domains() as $key=>$p): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($s['domain']??'trading',$key); ?>><?php echo esc_html($p); ?></option><?php endforeach; ?></select></label>
<label data-request-period>دوره<select name="agah_period"><option value="monthly">ماهانه</option><option value="annual" <?php selected($s['period']??'','annual'); ?>>سالانه — ۱۰٪ تخفیف و پرداخت یکجا</option></select></label>
<label data-request-method>روش پرداخت درخواستی<select name="agah_method"><option value="">هماهنگی با کارشناس</option><option value="onsite">پرداخت در محل</option><option value="zarinpal">زرین‌پال</option></select></label>
<p data-request-summary role="status" aria-live="polite">درخواست خرید، پرداخت یا فعال‌سازی اشتراک نیست.</p></fieldset>
<script type="application/json" class="agah-pricing-data"><?php echo wp_json_encode(array('plans'=>agah_pricing_catalogue(),'domains'=>agah_pricing_domains(),'open'=>agah_pricing_open()),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?></script>
<?php }
