<?php

/** Customizer for the ERP presentation only; it never expands access to company data. */
if(!defined('ABSPATH'))exit;
function agah_erp_customize($manager){
    $manager->add_panel('agah_erp_panel',['title'=>'ظاهر سامانه حسابداری','priority'=>35]);
    foreach(['identity'=>'نام و نشان','appearance'=>'رنگ و خوانایی','layout'=>'چیدمان'] as $k=>$label)$manager->add_section('agah_erp_'.$k,['title'=>$label,'panel'=>'agah_erp_panel']);
    $defs=[ 'agah_erp_title'=>['نام سامانه','سامانه حسابداری','identity','text'], 'agah_erp_brand'=>['رنگ دکمه‌ها و تأکید','#1F6F5C','appearance','color'], 'agah_erp_primary'=>['رنگ عنوان‌ها','#12304A','appearance','color'], 'agah_erp_background'=>['رنگ زمینه','#F5F8F7','appearance','color'], 'agah_erp_radius'=>['گردی گوشه‌ها',14,'appearance','range',0,28], 'agah_erp_font_size'=>['اندازه متن (پیکسل)',16,'appearance','range',14,20], 'agah_erp_width'=>['عرض فضای کاری (پیکسل)',1440,'layout','range',980,1680], ];
    foreach($defs as $id=>$d){
        $sanitize='sanitize_text_field';
        if($d[3]==='color')$sanitize='sanitize_hex_color';
        if($d[3]==='range')$sanitize=function($v)use($d){
            return max($d[4],min($d[5],absint($v)));
        }
        ;
        $manager->add_setting($id,['default'=>$d[1],'sanitize_callback'=>$sanitize,'transport'=>'refresh']);
        $control=['label'=>$d[0],'section'=>'agah_erp_'.$d[2],'type'=>$d[3]];
        if($d[3]==='range')$control['input_attrs']=['min'=>$d[4],'max'=>$d[5],'step'=>1];
        if($d[3]==='color')$manager->add_control(new WP_Customize_Color_Control($manager,$id,$control));
        else$manager->add_control($id,$control);
    }
    $manager->add_setting('agah_erp_logo',['default'=>0,'sanitize_callback'=>'absint','transport'=>'refresh']);
    $manager->add_control(new WP_Customize_Media_Control($manager,'agah_erp_logo',['label'=>'نشان سامانه','section'=>'agah_erp_identity','mime_type'=>'image']));
    $manager->add_setting('agah_erp_font',['default'=>'vazirmatn','sanitize_callback'=>function($v){
        return in_array($v,['vazirmatn','tahoma','arial'],true)?$v:'vazirmatn';
    }
    ,'transport'=>'refresh']);
    $manager->add_control('agah_erp_font',['label'=>'فونت محلی','section'=>'agah_erp_appearance','type'=>'select','choices'=>['vazirmatn'=>'وزیرمتن (فایل محلی)','tahoma'=>'Tahoma سیستم','arial'=>'Arial سیستم']]);
    $manager->get_section('agah_erp_navigation')->panel='agah_erp_panel';
    if(isset($manager->selective_refresh))foreach(['blogname','blogdescription','custom_logo','site_icon'] as $id)$manager->selective_refresh->add_partial($id,['selector'=>'[data-agah="'.$id.'"]','settings'=>[$id],'fallback_refresh'=>true,'render_callback'=>'__return_false']);
    // Every editable theme field has a native blue pencil, including settings without a permanent visible element.
    if(isset($manager->selective_refresh))foreach($manager->settings() as $id=>$setting){
        if(strpos($id,'agah_')!==0&&!in_array($id,['blogname','blogdescription','custom_logo','site_icon'],true))continue;
        if(!$manager->selective_refresh->get_partial($id))$manager->selective_refresh->add_partial($id,['selector'=>'[data-agah="'.$id.'"]','settings'=>[$id],'fallback_refresh'=>true,'render_callback'=>'__return_false']);
    }
}
add_action('customize_register','agah_erp_customize',30);
function agah_erp_presentation(){
    $colors=[];
    foreach(['brand'=>'#1F6F5C','primary'=>'#12304A','background'=>'#F5F8F7'] as $k=>$default)$colors[$k]=sanitize_hex_color(get_theme_mod('agah_erp_'.$k,$default))?:$default;
    $size=max(14,min(20,absint(get_theme_mod('agah_erp_font_size',16))));
    $radius=max(0,min(28,absint(get_theme_mod('agah_erp_radius',14))));
    $width=max(980,min(1680,absint(get_theme_mod('agah_erp_width',1440))));
    $fonts=['vazirmatn'=>'Vazirmatn,Tahoma,sans-serif','tahoma'=>'Tahoma,sans-serif','arial'=>'Arial,sans-serif'];
    $font=$fonts[get_theme_mod('agah_erp_font','vazirmatn')]??$fonts['vazirmatn'];
    $css='.erp{--c-brand:'.$colors['brand'].';--c-secondary:'.$colors['brand'].';--c-primary:'.$colors['primary'].';--c-bg:'.$colors['background'].';--radius:'.$radius.'px;--erp-width:'.$width.'px;font-size:'.$size.'px;font-family:'.$font.'}body.agah-accounting-page .content-wrap{max-width:'.$width.'px}';
    // Text on configurable brand backgrounds always gets a measured WCAG AA contrast choice.
    $lum=function($hex){
        $hex=strlen($hex)===4?'#'.$hex[1].$hex[1].$hex[2].$hex[2].$hex[3].$hex[3]:$hex;$rgb=sscanf($hex,'#%02x%02x%02x');
        $l=[];
        foreach($rgb as $v){
            $x=$v/255;
            $l[]=$x<=0.04045?$x/12.92:pow(($x+0.055)/1.055,2.4);
        }
        return .2126*$l[0]+.7152*$l[1]+.0722*$l[2];
    }
    ;
    if(1.05/($lum($colors['primary'])+.05)<4.5)$css.='.erp{--c-primary:#12304A}';
    $l=$lum($colors['brand']);
    $on=(1.05/($l+.05))>=(($l+.05)/.05)?'#ffffff':'#000000';
    $css.='.erp{--erp-on-brand:'.$on.'}';
    return $css;
}
add_action('wp_enqueue_scripts',function(){
    if(class_exists('Agah\\Erp\\Http\\SecurityController')&&\Agah\Erp\Http\SecurityController::isPage())wp_add_inline_style('agah-erp',agah_erp_presentation());
}
,30);
add_filter('body_class',function($classes){
    if(class_exists('Agah\\Erp\\Http\\SecurityController')&&\Agah\Erp\Http\SecurityController::isPage())$classes[]='agah-accounting-page';return $classes;
}
);
function agah_preview_settings_anchors(){
    if(!is_customize_preview()||!current_user_can('edit_theme_options'))return;
    global $wp_customize;
    if(!$wp_customize)return;
    echo '<details class="agah-preview-settings"><summary>قلم‌های ویرایش همه تنظیمات قالب</summary><p>برای ویرایش هر مورد روی قلم آبی همان مورد کلیک کنید.</p><div>';
    foreach($wp_customize->controls() as $id=>$control){
        if(strpos($id,'agah_')!==0&&!in_array($id,['blogname','blogdescription','custom_logo','site_icon'],true))continue;
        echo '<span data-agah="'.esc_attr($id).'">'.esc_html($control->label).'</span>';
    }
    echo '</div></details>';
}
add_action('wp_footer','agah_preview_settings_anchors',5);
add_action('wp_head',function(){
    if(is_customize_preview()&&current_user_can('edit_theme_options'))echo '<style>.agah-preview-settings{position:relative;margin:30px;padding:24px;background:#f1f7ff;border:2px solid #1678ba;z-index:100}.agah-preview-settings>div{display:flex;flex-wrap:wrap;gap:28px}.agah-preview-settings span{display:inline-block;padding:10px 30px;min-width:180px}.customize-partial-edit-shortcut button{background:#007cba!important;color:white!important}</style>';
}
);
