<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* ذخیرهٔ درخواست‌ها در پیشخوان (منوی «درخواست‌ها»)، علاوه بر ایمیل */
function agah_register_lead_cpt() {
	register_post_type( 'agah_lead', array(
		'labels'       => array( 'name' => 'درخواست‌ها', 'singular_name' => 'درخواست', 'menu_name' => 'درخواست‌ها', 'edit_item' => 'مشاهدهٔ درخواست', 'search_items' => 'جستجوی درخواست‌ها', 'not_found' => 'درخواستی ثبت نشده است.' ),
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => false,
		'menu_icon'    => 'dashicons-email-alt',
		'menu_position'=> 26,
		'supports'     => array( 'title', 'editor' ),
		'capabilities' => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap' => true,
	) );
}
add_action( 'init', 'agah_register_lead_cpt' );

function agah_contact_form() {
	$sent = isset( $_GET['agah_sent'] ) ? sanitize_key( wp_unslash( $_GET['agah_sent'] ) ) : '';
	ob_start();
	if ( '1' === $sent ) {
		echo '<div class="notice ok" role="status">' . esc_html( agah_mod( 'agah_ct_ok', 'پیام شما ثبت شد. به‌زودی با شما تماس می‌گیریم.' ) ) . '</div>';
	} elseif ( 'err' === $sent ) {
		echo '<div class="notice bad" role="alert">درخواست ثبت نشد؛ نام، شماره تماس و انتخاب طرح و دوره را بررسی کنید و دوباره تلاش کنید.</div>';
	} elseif ( 'wait' === $sent ) {
		echo '<div class="notice bad" role="alert">لطفاً چند لحظه بعد دوباره تلاش کنید.</div>';
	}
	?>
	<form class="cform" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="agah_contact">
		<?php wp_nonce_field( 'agah_contact', 'agah_nonce' ); ?>
		<p class="hp" aria-hidden="true"><label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
		<label>نام و نام خانوادگی <input type="text" name="c_name" required maxlength="80" autocomplete="name"></label>
		<label>شمارهٔ تماس <input type="text" name="c_phone" required maxlength="20" inputmode="tel" dir="ltr" autocomplete="tel"></label>
		<?php agah_pricing_contact_fields(); ?>
		<label>موضوع یا پیام <textarea name="c_msg" rows="4" maxlength="1500"></textarea></label>
		<button class="btn btn-primary btn-lg" type="submit" data-agah="agah_ct_btn"><?php echo esc_html( agah_mod( 'agah_ct_btn', 'ارسال درخواست' ) ); ?></button>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'agah_contact', 'agah_contact_form' );

function agah_handle_contact() {
	$ref = wp_get_referer() ? remove_query_arg( 'agah_sent', wp_get_referer() ) : home_url( '/' );
	$go  = function ( $code ) use ( $ref ) {
		wp_safe_redirect( add_query_arg( 'agah_sent', $code, $ref ) . '#contact' );
		exit;
	};

	$nonce = isset( $_POST['agah_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['agah_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'agah_contact' ) ) {
		$go( 'err' );
	}
	if ( ! empty( $_POST['website'] ) ) { // ربات: بی‌صدا موفق نشان بده
		$go( '1' );
	}
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'agah_ct_' . md5( $ip );
	if ( get_transient( $key ) ) {
		$go( 'wait' );
	}

	$name  = isset( $_POST['c_name'] ) ? sanitize_text_field( wp_unslash( $_POST['c_name'] ) ) : '';
	$phone = isset( $_POST['c_phone'] ) ? preg_replace( '/[^0-9+۰-۹]/u', '', sanitize_text_field( wp_unslash( $_POST['c_phone'] ) ) ) : '';
	$msg   = isset( $_POST['c_msg'] ) ? sanitize_textarea_field( wp_unslash( $_POST['c_msg'] ) ) : '';
	if ( mb_strlen( $name ) < 2 || mb_strlen( $phone ) < 7 ) {
		$go( 'err' );
	}

	$selection=agah_pricing_selection($_POST);
	if(is_wp_error($selection))$go('err');
	$body = "نام: $name\nشمارهٔ تماس: $phone\n\n$msg";
	$summary=agah_pricing_summary($selection);
	if($summary)$body.="\n\n".$summary;
	$id   = wp_insert_post( array( 'post_type' => 'agah_lead', 'post_status' => 'publish', 'post_title' => $name, 'post_content' => $body ) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, 'agah_phone', $phone );
		if($selection)update_post_meta($id,'agah_requested_plan',$selection);
	}
	if(!$id||is_wp_error($id))$go('err');
	$to = sanitize_email( agah_mod( 'agah_ct_to', '' ) );
	if ( ! $to ) {
		$to = get_option( 'admin_email' );
	}
	wp_mail( $to, 'درخواست جدید از سایت: ' . $name, $body );

	set_transient( $key, 1, 60 );
	$go( '1' );
}
add_action( 'admin_post_nopriv_agah_contact', 'agah_handle_contact' );
add_action( 'admin_post_agah_contact', 'agah_handle_contact' );
