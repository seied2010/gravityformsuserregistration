<?php
/** Default: authenticated human form only, signed age-limited token, honeypot and rate cap. */
if(!defined('ABSPATH'))exit;
function agah_comment_guard_fields(){
    $time=time();$post=(int)get_the_ID();$uid=get_current_user_id();
    echo '<input type="hidden" name="agah_comment_time" value="'.$time.'"><input type="hidden" name="agah_comment_token" value="'.esc_attr(hash_hmac('sha256',$time.'|'.$post.'|'.$uid,wp_salt('nonce'))).'">';
    echo '<p class="agah-comment-trap" aria-hidden="true"><label>این قسمت خالی بماند<input name="agah_comment_website_check" autocomplete="off" tabindex="-1"></label></p>';
}
add_action('comment_form_after_fields','agah_comment_guard_fields');add_action('comment_form_logged_in_after','agah_comment_guard_fields');
add_filter('comments_open',function($open,$post){return get_option('agah_allow_automated_comments','0')==='1'?$open:($open&&is_user_logged_in());},20,2);
add_filter('pre_comment_approved',function($approved,$data){
    if(get_option('agah_allow_automated_comments','0')==='1'||current_user_can('moderate_comments'))return $approved;
    $time=isset($_POST['agah_comment_time'])&&is_scalar($_POST['agah_comment_time'])?(int)$_POST['agah_comment_time']:0;
    $token=isset($_POST['agah_comment_token'])&&is_string($_POST['agah_comment_token'])?wp_unslash($_POST['agah_comment_token']):'';
    $expected=hash_hmac('sha256',$time.'|'.(int)$data['comment_post_ID'].'|'.get_current_user_id(),wp_salt('nonce'));
    if(!is_user_logged_in()||!empty($data['comment_type'])&&$data['comment_type']!=='comment'||!empty($_POST['agah_comment_website_check'])||time()-$time<3||time()-$time>86400||!hash_equals($expected,$token))return new WP_Error('agah_comment_guard','ثبت دیدگاه خودکار محدود است؛ وارد حساب شوید و از فرم دیدگاه صفحه استفاده کنید.',['status'=>403]);
    if(class_exists('Agah\\Erp\\Security\\RateLimiter')&&!\Agah\Erp\Security\RateLimiter::consume('comment|'.get_current_user_id(),5,300))return new WP_Error('agah_comment_rate','تعداد دیدگاه‌ها بیش از حد مجاز است؛ چند دقیقه بعد تلاش کنید.',['status'=>429]);
    return $approved;
},20,2);
add_action('wp_head',function(){echo '<style>.agah-comment-trap{position:absolute!important;left:-10000px!important;width:1px;height:1px;overflow:hidden}</style>';});
