/** آزمون HTTP و مرورگر روی سایت دورریختنی؛ fixture شامل اطلاعات آزمایشی است و نباید منتشر شود. */
const {chromium}=require('playwright');const fs=require('fs');const path=require('path');
const fixture=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));const output=process.argv[3]||'/tmp/agah-browser';fs.mkdirSync(output,{recursive:true});
const base=process.env.AGAH_TEST_URL||'http://127.0.0.1:8081';let passed=0,failed=0;let browser;
const assert=(v,m)=>{if(!v)throw new Error(m||'Assertion failed');};
async function test(name,fn){try{await fn();passed++;console.log('PASS '+name);}catch(e){failed++;console.log('FAIL '+name+' — '+e.message);}}
const url=(p='',extra={})=>base+'/?'+new URLSearchParams({page_id:String(fixture.page_id),...(p?{c:String(fixture.c1),p}:{}),...extra});
async function login(context,user=fixture.login){const page=await context.newPage();await page.goto(url());await page.locator('#user_login').fill(user);await page.locator('#user_pass').fill(fixture.password);await Promise.all([page.waitForURL(u=>u.searchParams.has('page_id')),page.locator('#wp-submit').click()]);await page.waitForLoadState();assert(await page.locator('#user_login').count()===0,'Login did not establish a session');return page;}
async function post(page,fields,includeNonce=true){return page.evaluate(async({fields,includeNonce})=>{let data=new URLSearchParams(fields);const form=document.querySelector('form:has(input[name="act"][value="'+fields.act+'"])');if(form){for(const key of ['_n','_idem'])if(includeNonce||key!=='_n')data.set(key,form.querySelector('[name="'+key+'"]').value);}const response=await fetch(location.href,{method:'POST',body:data});return {status:response.status,text:await response.text(),url:response.url};},{fields,includeNonce});}
(async()=>{
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:1440,height:1000}});let page;
 await test('Login POST without CSRF nonce is rejected',async()=>{const c=await browser.newContext();const r=await c.request.post(base+'/wp-login.php',{form:{log:fixture.login,pwd:fixture.password,redirect_to:url()}});assert(!(await c.cookies()).some(x=>x.name.startsWith('wordpress_logged_in')));await c.close();});
 await test('HTTP ERP page security headers and generic login form',async()=>{const p=await context.newPage();const r=await p.goto(url());const h=r.headers();assert(h['x-frame-options']==='DENY');assert(h['x-content-type-options']==='nosniff');assert(h['content-security-policy'].includes("frame-ancestors 'none'"));assert(h['cache-control'].includes('no-store'));assert(await p.locator('#user_login').count()===1);await p.close();});
 await test('Real WordPress login and ERP company list',async()=>{page=await login(context);assert(await page.getByText('شرکت‌های شما',{exact:true}).count()===1);});
 let external=[];page.on('request',r=>{if(!r.url().startsWith(base)&&!r.url().startsWith('data:'))external.push(new URL(r.url()).hostname);});
 let fatal=[];page.on('pageerror',e=>fatal.push(e.message));
 for(const p of ['dashboard','accounts','fiscal','audit','settings','members','roles','details','vouchers','reports','voucher_new','security'])await test('Render authenticated page '+p,async()=>{const r=await page.goto(url(p));assert(r.status()===200);const text=await page.locator('body').innerText();assert(!text.includes('خطای داخلی'),'PHP view error');assert(!text.includes('خطای مهمی'),'PHP fatal');if(p!=='security')assert(await page.locator('.erp-nav').count()===1);});

 await test('Account edit and save through real company form',async()=>{
    await page.goto(url('accounts',{edit:fixture.capital}));const form=page.locator('form:has(input[value="module_account_update"])');await form.locator('[name="erp_name"]').fill('سرمایه آزمون مرورگر');await Promise.all([page.waitForNavigation(),form.locator('button[type="submit"]').click()]);assert(await page.locator('form:has(input[value="module_account_update"]) [name="erp_name"]').inputValue()==='سرمایه آزمون مرورگر');
 });
 await test('Create custom role and member using real forms',async()=>{
    await page.goto(url('roles'));const rf=page.locator('form:has(input[value="module_role_save"])');await rf.locator('[name="erp_name"]').fill('نقش آزمون مرورگر');await rf.locator('[value="dashboard.view"]').check();await rf.locator('[value="voucher.view"]').check();await Promise.all([page.waitForNavigation(),rf.locator('button[type="submit"]').click()]);assert((await page.locator('tbody').first().innerText()).includes('نقش آزمون مرورگر'));
    await page.goto(url('members'));const mf=page.locator('form:has(input[value="module_member_add"])');await mf.locator('[name="login"]').fill('member_'+Date.now());await mf.locator('[name="email"]').fill('member'+Date.now()+'@example.test');await mf.locator('[name="password"]').fill(fixture.password);await mf.locator('[name="role_id"]').selectOption({label:'نقش آزمون مرورگر'});await Promise.all([page.waitForNavigation(),mf.locator('button[type="submit"]').click()]);assert((await page.locator('tbody').first().innerText()).includes('نقش آزمون مرورگر'));
 });

 await test('Legacy company creation uses shared CSRF/idempotency controller',async()=>{
    await page.goto(url());const cf=page.locator('form:has(input[value="company_create"])');const data=await cf.evaluate(form=>Object.fromEntries(new FormData(form)));Object.assign(data,{erp_name:'شرکت ساخته‌شده با فرم',jy:'1405',kind:'legal',display_unit:'toman'});
    const a=await context.request.post(page.url(),{form:data});assert(a.status()===200);assert((await a.text()).includes('شرکت ساخته‌شده با فرم'));await context.request.post(page.url(),{form:data});await page.reload();assert(await page.locator('.erp-list li').filter({hasText:'شرکت ساخته‌شده با فرم'}).count()===1);
 });
 await test('Legacy fiscal-year form creates twelve-month year',async()=>{
    await page.goto(url('fiscal'));const fy=page.locator('form:has(input[value="fy_create"])');await fy.locator('[name="jy"]').fill('1406');await Promise.all([page.waitForNavigation(),fy.locator('button[type="submit"]').click()]);assert((await page.locator('body').innerText()).includes('1406'));
 });
 await test('Company IDOR returns HTTP 404 before financial HTML',async()=>{const r=await page.goto(url('dashboard',{c:fixture.c2}));assert(r.status()===404);assert(!(await page.content()).includes('شرکت بیگانه مرورگر'));});
 await test('Local Jalali picker selects real Persian date',async()=>{await page.goto(url('voucher_new'));await page.getByRole('button',{name:'انتخاب تاریخ شمسی'}).click();assert(await page.getByRole('dialog',{name:'تقویم شمسی'}).count()===1);await page.getByRole('button',{name:'امروز',exact:true}).click();assert(/^\d{4}\/\d{2}\/\d{2}$/.test(await page.locator('[name="voucher_date"]').inputValue()));});
 await test('Voucher rows add/remove and exact live totals',async()=>{await page.locator('[data-add-line]').click();assert(await page.locator('[data-line]').count()===3);await page.locator('[data-remove-line]').last().click();assert(await page.locator('[data-line]').count()===2);await page.locator('[data-debit]').first().fill('۱۲۳٫۴');assert((await page.locator('[data-totals]').innerText()).includes('۱٬۲۳۴'));});
 let voucherId;const oneCode='HTTP-'+Date.now();
 await test('Real form saves voucher and PRG loads persisted lines',async()=>{
    await page.locator('[name="voucher_date"]').fill('1405/07/26');await page.locator('[name="description"]').fill('سند مرورگر با ذخیره واقعی');
    const rows=page.locator('[data-line]');await rows.nth(0).locator('[data-account]').selectOption(String(fixture.cash));await rows.nth(0).locator('[data-detail]').selectOption(String(fixture.detail));await rows.nth(0).locator('[name$="[description]"]').fill('=1+1');await rows.nth(0).locator('[data-debit]').fill('۱۰۰');await rows.nth(0).locator('[data-credit]').fill('۰');
    await rows.nth(1).locator('[data-account]').selectOption(String(fixture.capital));await rows.nth(1).locator('[data-credit]').fill('۱۰۰');await rows.nth(1).locator('[data-debit]').fill('۰');
    await Promise.all([page.waitForURL(u=>u.searchParams.get('p')==='voucher_view'),page.getByRole('button',{name:'ذخیرهٔ سند (Alt+S)'}).click()]);voucherId=new URL(page.url()).searchParams.get('id');assert(voucherId);assert((await page.locator('body').innerText()).includes('سند مرورگر با ذخیره واقعی'));
 });
 await test('Approve then finalize through real POST forms',async()=>{await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'تأیید و تخصیص شماره',exact:true}).click()]);assert((await page.locator('.erp-metadata').innerText()).includes('تأییدشده'));await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'قطعی‌کردن',exact:true}).click()]);assert((await page.locator('.erp-metadata').innerText()).includes('قطعی'));assert(await page.getByRole('link',{name:'ویرایش سند',exact:true}).count()===0);});
 await test('CSV export is real attachment and matches ledger',async()=>{await page.goto(url('reports'));const href=await page.getByRole('link',{name:'CSV تمام ردیف‌ها'}).getAttribute('href');const r=await context.request.get(new URL(href,base).href);const text=await r.text();assert(r.status()===200);assert(r.headers()['content-type'].includes('text/csv'));assert(text.includes('سند'));assert(text.includes('1000'));assert(text.includes("'=1+1"),'CSV formula neutralization');});
 await test('Excel export is genuine XLSX with typed worksheet data',async()=>{const href=await page.getByRole('link',{name:'Excel XLSX تمام ردیف‌ها'}).getAttribute('href');const r=await context.request.get(new URL(href,base).href);const bytes=await r.body();assert(bytes[0]===0x50&&bytes[1]===0x4b);assert(bytes.includes(Buffer.from('xl/worksheets/sheet1.xml')));assert(bytes.includes(Buffer.from('t="n"')));assert(!bytes.includes(Buffer.from('<f>')));});
 await test('GET export without nonce rejected',async()=>{const r=await context.request.get(url('reports',{export:'csv'}));assert(r.status()===422);});
 await test('POST CSRF without nonce does not create detail',async()=>{await page.goto(url('details'));const r=await post(page,{act:'module_detail_save',c:String(fixture.c1),back:'details',id:'0',code:'CSRF',erp_name:'نباید ذخیره شود',kind:'other',is_active:'1'},false);assert(r.text.includes('منقضی'));assert(!r.text.includes('<td>نباید ذخیره شود</td>'));});
 await test('Detail form saves once and duplicate POST replays result',async()=>{
    await page.goto(url('details'));const f=page.locator('form:has(input[value="module_detail_save"])');
    const data=await f.evaluate(form=>Object.fromEntries(new FormData(form)));Object.assign(data,{code:oneCode,erp_name:'تفصیلی فقط یک بار',kind:'other',is_active:'1'});
    const first=await context.request.post(page.url(),{form:data});assert(first.status()===200);assert(!(await first.text()).includes('data-error-field'));const second=await context.request.post(page.url(),{form:data});assert(second.status()===200);await page.reload();assert(await page.locator('tbody tr').filter({hasText:'تفصیلی فقط یک بار'}).count()===1);
 });
 await test('Form validation preserves entered values and shows error',async()=>{await page.goto(url('details'));const f=page.locator('form:has(input[value="module_detail_save"])');const data=await f.evaluate(form=>Object.fromEntries(new FormData(form)));Object.assign(data,{code:oneCode,erp_name:'نام حفظ شده',kind:'other',is_active:'1'});const r=await context.request.post(page.url(),{form:data});assert((await r.text()).includes('تکراری'));await page.goto(url('details'));});
 await test('Desktop voucher/report screenshot renders with local font',async()=>{await page.goto(url('reports'));await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:path.join(output,'reports-desktop.png'),fullPage:true});assert(await page.evaluate(()=>document.fonts.check('16px Vazirmatn')));});
 await test('Mobile RTL and bounded layout',async()=>{await page.setViewportSize({width:390,height:844});await page.goto(url('vouchers'));assert(await page.locator('.erp').getAttribute('dir')==='rtl');const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+2);assert(!overflow,'Page horizontal overflow');await page.screenshot({path:path.join(output,'vouchers-mobile.png'),fullPage:true});});
 await test('ERP makes no external UI requests',async()=>{assert(external.length===0,external.join(', '));});
 await test('No JavaScript runtime exceptions',async()=>{assert(fatal.length===0,fatal.join('; '));});

 let recovery=[];
 const codeFor=secret=>{
    const crypto=require('crypto');let bits='';for(const c of secret)bits+='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'.indexOf(c).toString(2).padStart(5,'0');
    const bytes=[];for(let i=0;i+8<=bits.length;i+=8)bytes.push(parseInt(bits.slice(i,i+8),2));
    const step=BigInt(Math.floor(Date.now()/30000)),counter=Buffer.alloc(8);counter.writeBigUInt64BE(step);
    const h=crypto.createHmac('sha1',Buffer.from(bytes)).update(counter).digest(),offset=h[h.length-1]&15;
    return String((h.readUInt32BE(offset)&0x7fffffff)%1000000).padStart(6,'0');
 };
 await test('TOTP enrollment with password, encrypted pending secret and eight backup codes via UI',async()=>{
    await page.goto(url('security'));await page.locator('input[name="password"]').fill(fixture.password);
    await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'شروع فعال‌سازی رمزساز'}).click()]);
    const secret=await page.locator('.erp-secret').inputValue();assert(/^[A-Z2-7]{32}$/.test(secret));
    await page.locator('input[name="code"]').fill(codeFor(secret));
    await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'تأیید و فعال‌سازی'}).click()]);
    recovery=await page.locator('.erp-recovery code').allTextContents();assert(recovery.length===8);assert((await page.locator('body').innerText()).includes('این نشست تأیید شده'));
 });
 let stepContext,stepPage;
 await test('Direct wp-login session cannot bypass ERP second factor',async()=>{
    stepContext=await browser.newContext();stepPage=await login(stepContext);await stepPage.goto(url('reports'));assert(await stepPage.locator('input[name="code"]').count()===1);assert(await stepPage.locator('.erp-nav').count()===0);
 });
 await test('Recovery code authenticates only the current new session',async()=>{
    await stepPage.locator('input[name="code"]').fill(recovery[0]);await Promise.all([stepPage.waitForNavigation(),stepPage.getByRole('button',{name:'تأیید هویت',exact:true}).click()]);await stepPage.goto(url('reports'));assert(await stepPage.locator('.erp-table').count()===1);
 });
 await test('Consumed recovery code rejected in another login session',async()=>{
    const third=await browser.newContext();const tp=await login(third);await tp.locator('input[name="code"]').fill(recovery[0]);await Promise.all([tp.waitForNavigation(),tp.getByRole('button',{name:'تأیید هویت',exact:true}).click()]);assert((await tp.locator('body').innerText()).includes('قبلاً مصرف شده'));await third.close();
 });
 await test('Company require_2fa setting saves and enforces enrollment after disable',async()=>{
    await page.goto(url('settings'));await page.locator('[name="require_2fa"]').check();await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'ذخیرهٔ تنظیمات'}).click()]);
    await page.goto(url('security'));await page.locator('[name="password"]').fill(fixture.password);await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'غیرفعال‌کردن رمزساز'}).click()]);
    await page.goto(url('reports'));assert(await page.getByRole('button',{name:'شروع فعال‌سازی رمزساز'}).count()===1);assert(await page.locator('.erp-nav').count()===0);
 });
 await test('Idle session is logged out before ERP data or POST access',async()=>{
    const {execFileSync}=require('child_process');execFileSync('docker',['compose','-f',process.env.AGAH_TEST_COMPOSE||'/workspace/agah-test/compose.yaml','exec','-T','wordpress','php','/tmp/wp','--allow-root','eval-file','wp-content/themes/agah-accounting/tests/browser-control.php',JSON.stringify({kind:'idle',uid:fixture.uid})],{stdio:['ignore','pipe','pipe']});
    await stepPage.goto(url('reports'));assert(await stepPage.locator('#user_login').count()===1);assert(await stepPage.locator('.erp-table').count()===0);
 });
 await stepContext?.close();
 const viewerContext=await browser.newContext();let vp=await login(viewerContext,fixture.viewer);
 await test('Viewer cannot request settings editor via GET role page',async()=>{const r=await vp.goto(url('roles'));assert(r.status()===200||r.status()===403);assert(!(await vp.content()).includes('ذخیرهٔ نقش'));});
 await test('Viewer financial POST denied even with valid own nonce/token',async()=>{await vp.goto(url('vouchers'));const response=await viewerContext.request.get(url('voucher_new'));assert(!(await response.text()).includes('name="lines['));});
 const outsiderContext=await browser.newContext();const op=await login(outsiderContext,fixture.other);
 await test('WP administrator is not automatically company member',async()=>{const r=await op.goto(url('dashboard'));assert(r.status()===404);});
 console.log(`RESULT: ${passed} passed; ${failed} failed; 0 skipped`);process.exitCode=failed?1:0;
})().catch(e=>{console.error('RUNNER FAILED: '+e.stack);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();});
