<?php
if(!defined('ABSPATH')) exit;
/** آزمون دودی: wp eval-file tests/smoke.php — روی سایت تست اجرا شود (نه سایت زنده). */
use Agah\Erp\Core\{Ctx, Db, Jalali, Money, Audit, NotFoundException, ConflictException};
use Agah\Erp\Modules\Company\CompanyService;
use Agah\Erp\Modules\Accounting\{AccountService, FiscalService};
if(!defined('AGAH_TEST_MODE') || !AGAH_TEST_MODE || !defined('WP_CLI') || !WP_CLI) throw new RuntimeException('Disposable test site required');
$GLOBALS['agah_smoke_fail']=0;
function t( $name, $ok ) { echo ( $ok ? 'PASS ' : 'FAIL ' ) . $name . "\n"; if ( ! $ok ) $GLOBALS['agah_smoke_fail']++; }

// تقویم و پول
t( 'jalali 2026-10-18 = 1405/07/26', Jalali::format( '2026-10-18', false ) === '1405/07/26' );
t( 'jalali parse roundtrip', Jalali::parse( '۱۴۰۵/۰۷/۲۶' ) === '2026-10-18' );
t( 'jalali leap 1403', Jalali::isLeap( 1403 ) && ! Jalali::isLeap( 1404 ) );
t( 'money toman->rial', Money::fromInput( '۱٬۲۵۰', 'toman' ) === 1250000 );
t( 'money rounding', Money::lineAmount( Money::qtyScaled( '2.5' ), 333 ) === 833 );
t( 'money overflow throws', ( function () { try { Money::fromInput( '99999999999999999999' ); return false; } catch ( \InvalidArgumentException $e ) { return true; } } )() );

// دو کاربر، دو شرکت
$u1 = wp_insert_user( array( 'user_login' => 'smoke_a' . wp_rand(), 'user_pass' => wp_generate_password(), 'user_email' => 'a' . wp_rand() . '@t.test' ) );
$u2 = wp_insert_user( array( 'user_login' => 'smoke_b' . wp_rand(), 'user_pass' => wp_generate_password(), 'user_email' => 'b' . wp_rand() . '@t.test' ) );
$c1 = CompanyService::create( $u1, array( 'name' => 'شرکت الف', 'jy' => 1405 ) );
$c2 = CompanyService::create( $u2, array( 'name' => 'شرکت ب', 'jy' => 1405 ) );
t( 'companies created', $c1 > 0 && $c2 > $c1 );
t( 'chart seeded (>50 moin)', (int) Db::val( 'SELECT COUNT(*) FROM ' . Db::t( 'accounts' ) . ' WHERE company_id=%d AND level=3', $c1 ) > 50 );
t( 'fiscal year has 12 periods', count( FiscalService::periods( $c1, FiscalService::all( $c1 )[0]['id'] ) ) === 12 );
t( 'admin role has all caps', (int) Db::val( 'SELECT COUNT(*) FROM ' . Db::t( 'role_caps' ) . ' rc JOIN ' . Db::t( 'roles' ) . " r ON r.id=rc.role_id WHERE r.company_id=%d AND r.role_key='company_admin'", $c1 ) === count( \Agah\Erp\Security\Caps::all() ) );

// جداسازی
Ctx::boot( $u1, $c1 );
t( 'member boots own company', Ctx::cid() === $c1 && Ctx::can( 'account.create' ) );
t( 'other company => NotFound', ( function () use ( $u1, $c2 ) { try { Ctx::boot( $u1, $c2 ); return false; } catch ( NotFoundException $e ) { return true; } } )() );
t( 'WP administrator is NOT auto-member', ( function () use ( $c1 ) { try { Ctx::boot( 1, $c1 ); return false; } catch ( NotFoundException $e ) { return true; } } )() );
$foreign = (int) Db::val( 'SELECT id FROM ' . Db::t( 'accounts' ) . " WHERE company_id=%d AND code='10101'", $c2 );
t( 'foreign account id => NotFound', ( function () use ( $c1, $foreign ) { try { AccountService::get( $c1, $foreign ); return false; } catch ( NotFoundException $e ) { return true; } } )() );

// قاعده‌های کدینگ
$kol = (int) Db::val( 'SELECT id FROM ' . Db::t( 'accounts' ) . " WHERE company_id=%d AND code='101'", $c1 );
$id  = AccountService::create( $c1, array( 'parent_id' => $kol, 'code' => '10190', 'name' => 'حساب آزمون' ) );
t( 'account created', $id > 0 );
t( 'duplicate code rejected', ( function () use ( $c1, $kol ) { try { AccountService::create( $c1, array( 'parent_id' => $kol, 'code' => '10190', 'name' => 'تکراری' ) ); return false; } catch ( \Agah\Erp\Core\ValidationException $e ) { return true; } } )() );
t( 'wrong prefix rejected', ( function () use ( $c1, $kol ) { try { AccountService::create( $c1, array( 'parent_id' => $kol, 'code' => '20190', 'name' => 'x' ) ); return false; } catch ( \Agah\Erp\Core\ValidationException $e ) { return true; } } )() );
t( 'system account not deletable', ( function () use ( $c1 ) { try { AccountService::delete( $c1, AccountService::bySysKey( $c1, 'cash' )['id'] ); return false; } catch ( ConflictException $e ) { return true; } } )() );
AccountService::delete( $c1, $id );
t( 'user account deletable', true );

// بازهٔ مالی
t( 'date inside open year ok', FiscalService::assertOpen( $c1, '2026-10-18' )['jy'] == 1405 );
t( 'date outside year rejected', ( function () use ( $c1 ) { try { FiscalService::assertOpen( $c1, '2030-01-01' ); return false; } catch ( ConflictException $e ) { return true; } } )() );
$p = Db::row( 'SELECT id FROM ' . Db::t( 'fiscal_periods' ) . ' WHERE company_id=%d AND start_date<=%s AND end_date>=%s', $c1, '2026-10-18', '2026-10-18' );
FiscalService::setPeriodStatus( $c1, $p['id'], 'closed' );
t( 'closed period rejected', ( function () use ( $c1 ) { try { FiscalService::assertOpen( $c1, '2026-10-18' ); return false; } catch ( ConflictException $e ) { return true; } } )() );

// ممیزی
t( 'audit chain intact', null === Audit::verify( $c1 ) );
Db::exec( 'UPDATE ' . Db::t( 'audit_log' ) . " SET new_json='{\"x\":1}' WHERE company_id=%d ORDER BY id LIMIT 1", $c1 );
t( 'audit tamper detected', null !== Audit::verify( $c1 ) );

// تراکنش: برگشت کامل
$before = (int) Db::val( 'SELECT COUNT(*) FROM ' . Db::t( 'companies' ) );
try { Db::tx( function () { Db::insert( 'companies', array( 'uuid' => \Agah\Erp\Core\Crypto::uuid(), 'name' => 'rb', 'created_at' => gmdate( 'Y-m-d H:i:s' ), 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ) ); throw new \Exception( 'x' ); } ); } catch ( \Exception $e ) {}
t( 'rollback leaves no row', (int) Db::val( 'SELECT COUNT(*) FROM ' . Db::t( 'companies' ) ) === $before );
// شماره‌گذاری بدون فاصله با rollback
$n1 = Db::tx( function () use ( $c1 ) { return \Agah\Erp\Core\Sequence::next( $c1, 'smoke', 0 ); } );
try { Db::tx( function () use ( $c1 ) { \Agah\Erp\Core\Sequence::next( $c1, 'smoke', 0 ); throw new \Exception( 'x' ); } ); } catch ( \Exception $e ) {}
$n2 = Db::tx( function () use ( $c1 ) { return \Agah\Erp\Core\Sequence::next( $c1, 'smoke', 0 ); } );
t( 'sequence gap-free after rollback', $n2 === $n1 + 1 );
// FK هم‌شرکتی: ردیف سند شرکت الف به حساب شرکت ب وصل نشود
$fy = FiscalService::all( $c1 )[0]['id'];
$vid = Db::insert( 'vouchers', array( 'uuid' => \Agah\Erp\Core\Crypto::uuid(), 'company_id' => $c1, 'fiscal_year_id' => $fy, 'voucher_date' => '2026-10-18', 'created_at' => gmdate( 'Y-m-d H:i:s' ), 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ) );
t( 'DB blocks cross-company FK', ( function () use ( $c1, $vid, $foreign ) { global $wpdb; $wpdb->suppress_errors( true ); $r = $wpdb->insert( Db::t( 'voucher_lines' ), array( 'company_id' => $c1, 'voucher_id' => $vid, 'line_no' => 1, 'account_id' => $foreign, 'debit' => 1 ) ); $wpdb->suppress_errors( false ); return false === $r; } )() );
$fail=$GLOBALS['agah_smoke_fail'];
echo $fail ? "\nFAILED: $fail\n" : "\nALL PASSED\n";

if($fail) WP_CLI::error("Smoke failures: ".$fail);
