<?php
if(!defined('ABSPATH'))exit;
if(!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
require __DIR__.'/support/production-fixture.php';
\Agah\Erp\Core\Db::exec('DELETE FROM '.\Agah\Erp\Core\Db::t('rate_limits'));
$f=agah_mfg_fixture();$cid=$f['cid'];
$viewer='mfg_view_'.bin2hex(random_bytes(5));$vid=wp_insert_user(['user_login'=>$viewer,'user_email'=>$viewer.'@test.invalid','user_pass'=>$f['password'],'role'=>'subscriber']);$role=(int)\Agah\Erp\Core\Db::val('SELECT id FROM '.\Agah\Erp\Core\Db::t('roles')." WHERE company_id=%d AND role_key='viewer'",$cid);\Agah\Erp\Modules\Company\MemberService::add($cid,['login'=>$viewer,'role_id'=>$role]);
$f['viewer']=$viewer;$f['viewer_id']=$vid;
$other=wp_insert_user(['user_login'=>'mfg_out_'.bin2hex(random_bytes(5)),'user_pass'=>$f['password'],'role'=>'administrator']);$foreign=\Agah\Erp\Modules\Company\CompanyService::create($other,['name'=>'شرکت تولید بیگانه','jy'=>1405,'activity_type'=>'manufacturing']);$f['foreign']=$foreign;
echo wp_json_encode($f);
