<?php
/** Verify an actual alpha7 snapshot after installing alpha8 ZIP; binary cells and audit bytes must survive. */
if(!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE||!defined('WP_CLI')||!WP_CLI)throw new RuntimeException('Disposable only');
use Agah\Erp\Core\{Db,Schema,PrecisionMigration,Money};
if(Schema::VERSION!=='9')throw new RuntimeException('Expected Schema9');
$before=unserialize(file_get_contents('/tmp/agah-alpha7-upgrade.serialized'),['allowed_classes'=>false]);if(!is_array($before)||count($before)!==56)throw new RuntimeException('Missing original alpha7 snapshot');
$changed=0;$rowsChecked=0;
foreach($before as $table=>$rows){$keys=array_keys($rows[0]??[]);$mapped=PrecisionMigration::MAP[$table]??[];$json=['payroll_params'=>'params_json','payslips'=>'snapshot','asset_events'=>'snapshot','year_closings'=>'balance_snapshot'][$table]??null;
    $expected=[];foreach($rows as $row){foreach($mapped as $col)if(array_key_exists($col,$row)){$row[$col]=(string)((int)$row[$col]*100);$changed++;}if($json&&$row[$json]!==null)$row[$json]=wp_json_encode(PrecisionMigration::jsonScale(json_decode($row[$json],true)));$expected[]=hash('sha256',serialize($row));}$actual=[];
    foreach(Db::rows('SELECT * FROM '.Db::t($table)) as $row){$row=array_intersect_key($row,array_flip($keys));$actual[]=hash('sha256',serialize($row));}
    $counts=array_count_values($actual);foreach($expected as $hash){if(empty($counts[$hash]))throw new RuntimeException('Lost/changed economic value, metadata or binary cell: '.$table);$counts[$hash]--;}$rowsChecked+=count($rows);
    echo 'PASS upgrade: '.$table.' ('.count($rows)." original rows retained; monetary fields converted exactly)\n";
}
if(Db::val('SELECT svalue FROM '.Db::t('settings')." WHERE company_id=0 AND skey='money_storage_scale'")!=='100')throw new RuntimeException('Scale marker missing');
$sample=Db::row('SELECT id,amount FROM '.Db::t('invoices').' ORDER BY id LIMIT 1');PrecisionMigration::run();if($sample!==Db::row('SELECT id,amount FROM '.Db::t('invoices').' ORDER BY id LIMIT 1'))throw new RuntimeException('Repeated migration changed values');
echo "RESULT: 56 tables verified; $rowsChecked original rows; $changed monetary cells converted; audit and BLOB bytes preserved; repeat upgrade idempotent\n";
