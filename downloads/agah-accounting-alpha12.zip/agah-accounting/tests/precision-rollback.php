<?php
/** Deliberately corrupt disposable fixtures to prove whole-install migration rollback, never production. */
if(!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE||!defined('WP_CLI')||!WP_CLI||!get_option('agah_backup_test_marker'))throw new RuntimeException('Dedicated backup test site only');
use Agah\Erp\Core\{Db,Money,PrecisionMigration,Business};
$doc=Db::row('SELECT id,company_id,amount,fiscal_year_id FROM '.Db::t('expense_docs').' ORDER BY id LIMIT 1');if(!$doc)throw new RuntimeException('Missing disposable fixture');
function precision_capture(){return serialize(Db::rows('SELECT id,total_debit,total_credit FROM '.Db::t('vouchers').' ORDER BY id'));}
$baseline=precision_capture();$marker="UPDATE ".Db::t('settings')." SET svalue=%s WHERE company_id=0 AND skey='money_storage_scale'";
try{
    Db::update('expense_docs',['amount'=>Money::MAX],['id'=>$doc['id']]);Db::exec($marker,'1');$failed=false;try{PrecisionMigration::run();}catch(RuntimeException $e){$failed=true;}
    if(!$failed||precision_capture()!==$baseline||Db::val('SELECT svalue FROM '.Db::t('settings')." WHERE company_id=0 AND skey='money_storage_scale'")!=='1')throw new RuntimeException('Overflow did not rollback all earlier tables');
    echo "PASS overflow rolls back earlier converted tables and scale marker atomically\n";
}finally{Db::update('expense_docs',['amount'=>$doc['amount']],['id'=>$doc['id']]);Db::exec($marker,'100');}
$id=Business::save('payroll_params',(int)$doc['company_id'],0,['fiscal_year_id'=>$doc['fiscal_year_id'],'params_json'=>'{invalid']);
try{
    Db::exec($marker,'1');$failed=false;try{PrecisionMigration::run();}catch(RuntimeException $e){$failed=true;}
    if(!$failed||precision_capture()!==$baseline)throw new RuntimeException('Malformed snapshot did not roll back earlier money updates');
    echo "PASS malformed historical snapshot rolls back every monetary table\n";
}finally{Db::delete('payroll_params',['id'=>$id]);Db::exec($marker,'100');}
PrecisionMigration::run();if(precision_capture()!==$baseline)throw new RuntimeException('Already-upgraded values doubled');echo "PASS repeated successful upgrade is idempotent\nRESULT: 3 passed; 0 failed; 0 skipped\n";
