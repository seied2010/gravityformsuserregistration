<?php
if(!defined('ABSPATH')) exit;
/** بردارهای رسمی RFC و سیاست گذرواژه؛ در بستر وردپرس برای استفاده از API جاری اجرا می‌شود. */
use Agah\Erp\Security\{Totp,Auth};
use Agah\Erp\Core\{Money,Crypto,Jalali};
foreach([59=>'94287082',1111111109=>'07081804',1111111111=>'14050471',1234567890=>'89005924',2000000000=>'69279037',20000000000=>'65353130'] as $time=>$expected) {
    agah_test('RFC6238 SHA1 timestamp '.$time,function()use($time,$expected){agah_assert(Totp::code('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ',intdiv($time,30),8)===$expected);});
}
agah_test('TOTP wrong format rejected',function(){agah_assert(Totp::matchStep(Totp::secret(),'1e2345')===null);});
agah_test('TOTP current/adjacent steps and expiry',function(){ $s=Totp::secret();$step=100000;agah_assert(Totp::matchStep($s,Totp::code($s,$step),$step*30)===$step);agah_assert(Totp::matchStep($s,Totp::code($s,$step-2),$step*30)===null); });
agah_test('Base32 random key uses 32 valid symbols',function(){agah_assert((bool)preg_match('/^[A-Z2-7]{32}$/D',Totp::secret()));});
agah_test('Password short/no letter/no number rejected',function(){foreach(['abc123','abcdefghijk','123456789012'] as $s)agah_assert(Auth::passwordError($s)!=='');agah_assert(Auth::passwordError('حسابداری۱۴۰۵امن')==='');});
agah_test('Money accepts Persian digits and exact toman fraction',function(){agah_assert(Money::fromInput('۱٬۲۵۰٫۱','toman')===1250100);agah_assert(Money::toInputValue(1250100,'toman')==='1250.1');});
agah_test('Money overflow and fractions rejected',function(){agah_throws(InvalidArgumentException::class,function(){Money::add(Money::MAX,1);});agah_throws(InvalidArgumentException::class,function(){Money::fromInput('0.001','rial');});});
agah_test('Encryption authentication detects tampering',function(){ $p=Crypto::encrypt('sensitive');agah_assert(strpos($p,'sensitive')===false);$p[strlen($p)-5]=$p[strlen($p)-5]==='A'?'B':'A';agah_assert(Crypto::decrypt($p)===''); });
agah_test('Jalali leap day and roundtrip',function(){agah_assert(Jalali::parse('۱۴۰۳/۱۲/۳۰')==='2025-03-20');agah_throws(InvalidArgumentException::class,function(){Jalali::parse('1404/12/30');});});
