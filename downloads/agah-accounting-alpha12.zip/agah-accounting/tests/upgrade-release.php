<?php
/** Schema7→8: old columns/rows hashed with serialize so existing binary images are preserved. */
if(!defined('ABSPATH')||!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)throw new RuntimeException('Disposable test site only');
use Agah\Erp\Core\{Db,Schema};
$mode=$args[0]??'verify';$path='/tmp/agah-alpha6-snapshot.json';
if($mode==='capture'){
 if(Schema::VERSION!=='7')throw new RuntimeException('Expected alpha6 Schema7');$out=[];
 foreach(Schema::tables() as $table){$cols=Db::col('SHOW COLUMNS FROM '.Db::t($table));$select=implode(',',array_map(function($c){return '`'.str_replace('`','``',$c).'`';},$cols));$hashes=[];foreach(Db::rows('SELECT '.$select.' FROM '.Db::t($table)) as $row)$hashes[]=hash('sha256',serialize($row));sort($hashes);$out[$table]=['columns'=>$cols,'hashes'=>$hashes];}$out['_theme_mods_hash']=hash('sha256',serialize(get_theme_mods()));file_put_contents($path,wp_json_encode($out));chmod($path,0600);echo 'Captured '.(count($out)-1)." alpha6 tables with binary-safe hashes\n";return;
}
if(Schema::VERSION!=='8')throw new RuntimeException('Expected alpha7 Schema8');$data=json_decode(file_get_contents($path),true);$n=0;$themeHash=$data['_theme_mods_hash'];unset($data['_theme_mods_hash']);if(hash('sha256',serialize(get_theme_mods()))!==$themeHash)throw new RuntimeException('Theme preferences changed');echo "PASS upgrade preserves all saved Customizer preferences\n";
foreach($data as $table=>$snapshot){if(!in_array($table,Schema::tables(),true))throw new RuntimeException('Unknown table');$select=implode(',',array_map(function($c){return '`'.str_replace('`','``',$c).'`';},$snapshot['columns']));$hashes=[];foreach(Db::rows('SELECT '.$select.' FROM '.Db::t($table)) as $row)$hashes[]=hash('sha256',serialize($row));sort($hashes);if(in_array($table,['role_caps','schema_migrations','accounts'],true)){foreach($snapshot['hashes'] as $hash)if(!in_array($hash,$hashes,true))throw new RuntimeException('Old row lost/changed: '.$table);}elseif($hashes!==$snapshot['hashes'])throw new RuntimeException('Data changed: '.$table);echo 'PASS upgrade preserves '.$table.' ('.count($snapshot['hashes'])." old rows)\n";$n++;}
if(count(Schema::tables())!==56||Schema::missingForeignKeys())throw new RuntimeException('Missing constraints');echo 'RESULT: '.$n." preserved tables; 0 failed\n";
