<?php
if(!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
ob_start();require __DIR__.'/trade-browser-fixture.php';$f=json_decode(ob_get_clean(),true);
use Agah\Erp\Core\{Ctx,Db,Settings};
use Agah\Erp\Modules\Company\CompanyService;
use Agah\Erp\Modules\Accounting\AccountService;
use Agah\Erp\Modules\Parties\PartyService;
use Agah\Erp\Modules\Catalog\CatalogService;
$cid=$f['c1'];wp_set_current_user($f['uid']);Ctx::boot($f['uid'],$cid);
$f['tax']=CatalogService::save($cid,'tax',0,['code'=>'QA10','name'=>'ارزش افزوده ده درصد آزمون','bp'=>1000,'valid_from'=>'2026-03-21','valid_to'=>'2027-03-20','confirmed'=>1]);Settings::set('tax_confirmed','1',$cid);$unit=(int)Db::val('SELECT id FROM '.Db::t('units').' WHERE company_id=%d LIMIT 1',$cid);
$f['service']=CatalogService::save($cid,'item',0,['code'=>'QA-S','name'=>'خدمت اعشاری مرورگر','kind'=>'service','unit_id'=>$unit,'tax_rate_id'=>$f['tax'],'sale_account_id'=>(int)AccountService::bySysKey($cid,'sales_services')['id'],'purchase_account_id'=>(int)AccountService::bySysKey($cid,'purchases')['id'],'is_active'=>1]);
$employee=\Agah\Erp\Modules\Payroll\PayrollService::employee($cid,0,['code'=>'QA-YEAR','name'=>'کارمند تفکیک سال','is_active'=>1]);
\Agah\Erp\Modules\Payroll\PayrollService::contract($cid,0,['employee_id'=>$employee,'start_date'=>'2026-03-21','end_date'=>'2027-03-20','base_salary'=>100000,'benefits'=>0]);$year=(int)\Agah\Erp\Modules\Accounting\FiscalService::forDate($cid,'2026-03-21')['id'];$liability=(int)Db::val('SELECT id FROM '.Db::t('accounts')." WHERE company_id=%d AND code='30202'",$cid);
\Agah\Erp\Modules\Payroll\PayrollService::params($cid,$year,['employee_bp'=>700,'employer_bp'=>2300,'overtime_bp'=>14000,'monthly_minutes'=>13200,'insurance_ceiling'=>0,'tax_exemption'=>10000000,'brackets'=>[['upper'=>null,'rate_bp'=>1000]],'expense_account_id'=>(int)AccountService::bySysKey($cid,'salary_expense')['id'],'salary_account_id'=>(int)AccountService::bySysKey($cid,'salary_payable')['id'],'insurance_account_id'=>$liability,'tax_account_id'=>$liability,'deduction_account_id'=>$liability]);
\Agah\Erp\Modules\Payroll\PayrollService::attendance($cid,['employee_id'=>$employee,'period_key'=>'1405-01','work_days'=>30,'leave_days'=>0,'overtime_minutes'=>0,'extra_benefits'=>0,'deductions'=>0]);\Agah\Erp\Modules\Payroll\PayrollService::issue($cid,$employee,'1405-01','2026-04-20');
$f['site_admin']='qa_admin_'.bin2hex(random_bytes(5));$f['admin_uid']=wp_insert_user(['user_login'=>$f['site_admin'],'user_email'=>$f['site_admin'].'@qa.test','user_pass'=>$f['password'],'role'=>'administrator']);
$f['target']='qa_member_'.bin2hex(random_bytes(5));$f['target_uid']=wp_insert_user(['user_login'=>$f['target'],'user_email'=>$f['target'].'@qa.test','user_pass'=>$f['password'],'role'=>'subscriber']);$f['c3']=CompanyService::create($f['uid'],['name'=>'شرکت دوم تخصیص دسترسی','jy'=>1405,'activity_type'=>'manufacturing']);
$f['viewer_role']=(int)Db::val('SELECT id FROM '.Db::t('roles')." WHERE company_id=%d AND role_key='viewer'",$cid);$f['accountant_role']=(int)Db::val('SELECT id FROM '.Db::t('roles')." WHERE company_id=%d AND role_key='accountant'",$f['c3']);$f['admin_role']=(int)Db::val('SELECT id FROM '.Db::t('roles')." WHERE company_id=%d AND role_key='company_admin'",$cid);
echo wp_json_encode($f);
