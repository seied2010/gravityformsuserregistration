<?php
if(!defined('ABSPATH'))exit;
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)throw new RuntimeException('Disposable site only');
require __DIR__.'/support/production-fixture.php';
use Agah\Erp\Core\{Ctx,Db,Schema,Audit};use Agah\Erp\Modules\Manufacturing\ProductionService as P;use Agah\Erp\Modules\Inventory\StockService as S;use Agah\Erp\Modules\Maintenance\BackupService as B;
if(defined('AGAH_BACKUP_KEY')||defined('AGAH_BACKUP_DIR'))throw new RuntimeException('Use an isolated test instance with no backup constants');
$dir='/tmp/agah-production-backup-'.bin2hex(random_bytes(16));mkdir($dir,0700);define('AGAH_BACKUP_DIR',$dir);define('AGAH_BACKUP_KEY',base64_encode(random_bytes(32)));
try{
 $f=agah_mfg_fixture('fifo');$cid=$f['cid'];$id=P::plan($cid,0,$f['plan']);P::start($cid,$id,1,'2026-10-21');P::complete($cid,$id,2,['finish_date'=>'2026-10-21','actual_qty'=>100000,'labor_cost'=>10000,'overhead_cost'=>5000]);$before=P::order($cid,$id);$raw=S::balanceInternal($cid,$f['wh'],$f['items']['A']);$product=S::balanceInternal($cid,$f['to'],$f['items']['P']);$name=B::create();$info=B::inspect($name);if($info['schema']!=='10'||count($info['counts'])!==60)throw new RuntimeException('Incomplete manufacturing archive');echo "PASS encrypted archive includes every manufacturing table and nullable source link\n";
 P::voidOrder($cid,$id,3,'تغییر آزمایشی پیش از بازیابی');B::restore($name);Ctx::boot($f['uid'],$cid,true);if(P::order($cid,$id)!==$before||S::balanceInternal($cid,$f['wh'],$f['items']['A'])!==$raw||S::balanceInternal($cid,$f['to'],$f['items']['P'])!==$product)throw new RuntimeException('Manufacturing state changed after restore');echo "PASS restore recovers exact order snapshot material costs FIFO picks and product value\n";
 if(S::reconcile($cid)['difference']!==0||Audit::verify($cid)!==null||Schema::missingForeignKeys()||(int)Db::val('SELECT @@FOREIGN_KEY_CHECKS')!==1)throw new RuntimeException('Invalid restored accounting state');echo "PASS restored stock and ledger reconcile with foreign keys and audit intact\nRESULT: 3 passed; 0 failed\n";
}finally{foreach(glob($dir.'/*') as $file)unlink($file);rmdir($dir);}
