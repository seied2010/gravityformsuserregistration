<?php
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)throw new RuntimeException('Disposable site only');
use Agah\Erp\Core\{KeySetup,Crypto};
$GLOBALS['n']=0;function check_key($ok,$label){if(!$ok)throw new RuntimeException($label);$GLOBALS['n']++;echo 'PASS '.$label."\n";}
$raw=wp_salt('secure_auth').'|'.wp_salt('auth');$encoded=base64_encode($raw);
$source="<?php\ndefine('EXAMPLE', 'unchanged');\nrequire_once ABSPATH . 'wp-settings.php';\n";
$new=KeySetup::prepareConfig($source,$encoded);
check_key(is_string($new)&&strpos($new,"define('AGAH_ENC_KEY'")<strpos($new,'require_once'),'standard bootstrap injection');
check_key(KeySetup::prepareConfig($new,$encoded)===null,'configured key never overwritten');
foreach(["<?php\n/*\nrequire_once ABSPATH . 'wp-settings.php';\n*/", "<?php\nfunction f(){\nrequire_once ABSPATH . 'wp-settings.php';\n}","<?php\nif(false)\nrequire_once ABSPATH . 'wp-settings.php';",'<?php invalid PHP'] as $bad)check_key(KeySetup::prepareConfig($bad,$encoded)===null,'complex/comment/invalid config rejected');
$old=KeySetup::meta();$meta=[];
try{
 $method=new ReflectionMethod(KeySetup::class,'privateFiles');$method->setAccessible(true);$meta=$method->invoke(null,$encoded);
 update_option(KeySetup::OPTION,$meta+['storage'=>'private','fingerprint'=>KeySetup::fingerprint($raw)],false);
 check_key(KeySetup::storedValue()===$encoded,'two private files readback');
 $root=WP_CONTENT_DIR.'/'.$meta['directory'];
 check_key((fileperms($root)&0777)===0700&&(fileperms($root.'/'.$meta['files'][0])&0777)===0600,'private directory and file permissions');
 $blob='v1:'.base64_encode(($nonce=random_bytes(24)).sodium_crypto_secretbox('legacy company/party/TOTP',$nonce,hash_hkdf('sha256',$raw,32,'agah-erp-enc')));
 if(!defined('AGAH_ENC_KEY')&&!getenv('AGAH_ENC_KEY')){
 check_key(Crypto::decrypt($blob)==='legacy company/party/TOTP','legacy encryption preserved');
 check_key(Crypto::blind('legacy idempotency recovery OTP')===hash_hmac('sha256',\Agah\Erp\Core\Money::normDigits('legacy idempotency recovery OTP'),hash_hkdf('sha256',$raw,32,'agah-erp-idx')),'all blind-index purposes preserved');
 $salt=function(){return 'altered salts for test only';};add_filter('salt',$salt);
 check_key(Crypto::decrypt($blob)==='legacy company/party/TOTP','private key survives WordPress salt change');remove_filter('salt',$salt);
 }
 file_put_contents($root.'/'.$meta['files'][0],'corrupt');
 check_key(KeySetup::storedValue()===$encoded,'second independent copy recovers corrupted first copy');
 file_put_contents($root.'/'.$meta['files'][1],'corrupt');
 check_key(KeySetup::storedValue()==='','both corrupt copies rejected');
 check_key(KeySetup::assertFallback($raw)===null,'same original fallback remains recoverable');
 try{KeySetup::assertFallback('wrong changed salts');$failed=false;}catch(\Agah\Erp\Core\AppException $e){$failed=$e->status===503;}check_key($failed,'lost key with changed salts fails closed');
 update_option(KeySetup::OPTION,['storage'=>'private','directory'=>'../outside','files'=>$meta['files'],'fingerprint'=>KeySetup::fingerprint($raw)]);
 check_key(KeySetup::storedValue()==='','path traversal rejected');
}finally{update_option(KeySetup::OPTION,$old,false);if($meta){$rm=new ReflectionMethod(KeySetup::class,'removePrivate');$rm->setAccessible(true);$rm->invoke(null,$meta);}}
wp_set_current_user(0);try{KeySetup::activate();$denied=false;}catch(\Agah\Erp\Core\ForbiddenException $e){$denied=true;}check_key($denied,'unauthorized service call rejected');
echo "RESULT: ".$GLOBALS['n']." passed\n";
