<?php
if(!defined('ABSPATH'))exit;
if(!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)exit;
require dirname(__DIR__).'/support/production-fixture.php';$f=agah_mfg_fixture();$id=\Agah\Erp\Modules\Manufacturing\ProductionService::plan($f['cid'],0,$f['plan']);
echo wp_json_encode(['uid'=>$f['uid'],'cid'=>$f['cid'],'id'=>$id,'wh'=>$f['wh'],'to'=>$f['to'],'raw'=>$f['items']['A'],'product'=>$f['items']['P'],'plan'=>$f['plan']]);
