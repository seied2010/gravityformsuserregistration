"""Competing PHP processes on the same company: no mocked transactions or stock values."""
import concurrent.futures,json,os,subprocess
compose=os.environ.get('AGAH_TEST_COMPOSE','/workspace/agah-test/compose.yaml')
prefix=['docker','compose','-f',compose,'exec','-T','wordpress','php','/tmp/wp','--allow-root','eval-file']
def call(name,job=None):
    cmd=prefix+['wp-content/themes/agah-accounting/tests/integration/production-concurrency-'+name+'.php']
    if job is not None:cmd+=[json.dumps(job,separators=(',',':'))]
    p=subprocess.run(cmd,capture_output=True,text=True,check=True)
    return p.stdout.strip()
f=json.loads(call('setup'));passed=0
def check(name,ok):
    global passed
    if not ok:raise RuntimeError(name)
    passed+=1;print('PASS '+name,flush=True)
def run(kind,ids=None):
    jobs=[f|{'kind':kind,'id':x} for x in (ids or [f['id']]*4)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:return list(pool.map(lambda j:call('worker',j),jobs))
def state():return json.loads(call('worker',f|{'kind':'state'}))
for kind in ['start','complete','void']:
    r=run(kind);check('Four concurrent '+kind+' requests commit exactly once',r.count('ok')==1 and r.count('conflict')==3)
    s=state();check('Stock and ledger reconcile after concurrent '+kind,s['difference']==0 and s['audit_bad'] is None)
    if kind=='start':check('Only one material consumption is persisted',s['raw']=={'qty':800000,'value':80000} and s['start_vouchers']==1)
    elif kind=='complete':check('Only one completed product receipt is persisted',s['product']=={'qty':100000,'value':30000} and s['finish_vouchers']==1)
    else:check('One cancellation restores exact raw and product balances',s['raw']=={'qty':1000000,'value':100000} and s['product']=={'qty':0,'value':0})
ids=json.loads(call('worker',f|{'kind':'race_setup'}));r=run('start',ids)
check('Two orders competing for limited material cannot oversell stock',sorted(r)==['conflict','ok'])
s=state();check('Shared stock is consumed once and audit remains intact',s['raw']=={'qty':400000,'value':40000} and s['difference']==0 and s['audit_bad'] is None)
print(f'RESULT: {passed} passed; 0 failed')
