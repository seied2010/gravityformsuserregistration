<?php
if(!defined('ABSPATH'))exit;
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)throw new RuntimeException('Disposable site required');
use Agah\Erp\Core\{Ctx,Db,ConflictException,Audit};use Agah\Erp\Modules\Manufacturing\ProductionService as P;use Agah\Erp\Modules\Inventory\StockService;
$j=json_decode($args[0]??'',true);wp_set_current_user($j['uid']);Ctx::boot($j['uid'],$j['cid']);$cid=$j['cid'];$id=$j['id'];
try{switch($j['kind']){
 case 'start':P::start($cid,$id,1,'2026-10-21');echo 'ok';break;
 case 'complete':P::complete($cid,$id,2,['finish_date'=>'2026-10-21','actual_qty'=>100000]);echo 'ok';break;
 case 'void':P::voidOrder($cid,$id,3,'برگشت هم‌زمان آزمایشی');echo 'ok';break;
 case 'state':echo wp_json_encode(['status'=>P::order($cid,$id)['status'],'raw'=>StockService::balanceInternal($cid,$j['wh'],$j['raw']),'product'=>StockService::balanceInternal($cid,$j['to'],$j['product']),'start_vouchers'=>(int)Db::val('SELECT COUNT(*) FROM '.Db::t('vouchers')." WHERE company_id=%d AND source_type='production_start' AND source_id=%d",$cid,$id),'finish_vouchers'=>(int)Db::val('SELECT COUNT(*) FROM '.Db::t('vouchers')." WHERE company_id=%d AND source_type='production_finish' AND source_id=%d",$cid,$id),'difference'=>StockService::reconcile($cid)['difference'],'audit_bad'=>Audit::verify($cid)]);break;
 case 'race_setup':$plan=array_merge($j['plan'],['planned_qty'=>300000]);echo wp_json_encode([P::plan($cid,0,$plan),P::plan($cid,0,$plan)]);break;
 default:throw new RuntimeException('Unknown test action');
}}catch(ConflictException $e){echo 'conflict';}
