<?php
if(!defined('ABSPATH'))exit;
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)throw new RuntimeException('Disposable test site required');
use Agah\Erp\Core\{Ctx,Db,Crypto};
use Agah\Erp\Modules\Company\CompanyService;
use Agah\Erp\Modules\Accounting\{AccountService,VoucherService};
use Agah\Erp\Modules\Catalog\CatalogService;
use Agah\Erp\Modules\Inventory\StockService;
use Agah\Erp\Modules\Manufacturing\ProductionService;
function agah_mfg_fixture($method='average'){
 $tag=Crypto::token(5);$password=Crypto::token(20);$login='mfg_'.$tag;$uid=wp_insert_user(['user_login'=>$login,'user_pass'=>$password,'user_email'=>$login.'@test.invalid','role'=>'administrator']);$cid=CompanyService::create($uid,['name'=>'شرکت تولید آزمایشی '.$tag,'jy'=>1405,'activity_type'=>'manufacturing','display_unit'=>'rial']);wp_set_current_user($uid);Ctx::boot($uid,$cid);
 StockService::configure($cid,$method,'inventory');$wh=StockService::saveWarehouse($cid,0,['code'=>'MAT','name'=>'انبار مواد','is_active'=>1]);$to=StockService::saveWarehouse($cid,0,['code'=>'FIN','name'=>'انبار محصول','is_active'=>1]);$unit=(int)Db::val('SELECT id FROM '.Db::t('units').' WHERE company_id=%d LIMIT 1',$cid);$base=['kind'=>'goods','unit_id'=>$unit,'sale_account_id'=>(int)AccountService::bySysKey($cid,'sales_goods')['id'],'purchase_account_id'=>(int)AccountService::bySysKey($cid,'purchases')['id'],'is_active'=>1];$items=[];foreach(['A'=>'ماده الف','B'=>'ماده ب','P'=>'محصول آزمایشی'] as $code=>$name)$items[$code]=CatalogService::save($cid,'item',0,$base+['code'=>$code,'name'=>$name]);
 $accounts=ProductionService::accounts($cid);ProductionService::configure($cid,$accounts);
 $receipt=StockService::issue($cid,['kind'=>'receipt','doc_date'=>'2026-10-21'],[['warehouse_id'=>$wh,'item_id'=>$items['A'],'qty_scaled'=>1000000,'cost'=>100000],['warehouse_id'=>$wh,'item_id'=>$items['B'],'qty_scaled'=>1000000,'cost'=>200000]]);
 $vid=VoucherService::save($cid,0,['voucher_date'=>'2026-10-21','description'=>'هزینه واقعی دستمزد و سربار آزمون'],[['account_id'=>$accounts['labor'],'debit'=>100000,'credit'=>0],['account_id'=>$accounts['overhead'],'debit'=>50000,'credit'=>0],['account_id'=>(int)AccountService::bySysKey($cid,'opening_balance')['id'],'debit'=>0,'credit'=>150000]]);$v=VoucherService::get($cid,$vid);VoucherService::transition($cid,$vid,'approve','',(int)$v['revision']);
 $bom=ProductionService::saveBom($cid,0,['code'=>'BOM','name'=>'فرمول پایه محصول','product_id'=>$items['P'],'base_qty'=>10000,'is_active'=>1],[['item_id'=>$items['A'],'qty_scaled'=>20000],['item_id'=>$items['B'],'qty_scaled'=>5000]]);
 $plan=['bom_id'=>$bom,'planned_qty'=>100000,'doc_date'=>'2026-10-21','material_warehouse_id'=>$wh,'warehouse_id'=>$to];
 return ['uid'=>$uid,'cid'=>$cid,'wh'=>$wh,'to'=>$to,'items'=>$items,'accounts'=>$accounts,'receipt'=>$receipt,'expense_voucher'=>$vid,'bom'=>$bom,'plan'=>$plan,'login'=>$login,'password'=>$password,'page_id'=>(int)get_option('agah_erp_page_id')];
}
