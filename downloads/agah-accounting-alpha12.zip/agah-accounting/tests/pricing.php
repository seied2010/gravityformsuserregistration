<?php
if(!defined('ABSPATH'))exit;
if(!defined('WP_CLI')||!WP_CLI||!defined('AGAH_TEST_MODE')||!AGAH_TEST_MODE)throw new RuntimeException('Disposable site required');
$GLOBALS['agah_pricing_pass']=0;$GLOBALS['agah_pricing_fail']=0;
function price_check($n,$ok){if($ok){$GLOBALS['agah_pricing_pass']++;echo "PASS $n\n";}else{$GLOBALS['agah_pricing_fail']++;echo "FAIL $n\n";}}
price_check('Catalogue contains exactly three plans',array_keys(agah_pricing_catalogue())===array('specialized','hybrid','enterprise'));
price_check('Specialized monthly 500000 toman',agah_pricing_amount('specialized','monthly')===500000);
price_check('Specialized yearly 5400000 toman',agah_pricing_amount('specialized','annual')===5400000);
price_check('Hybrid monthly 1000000 toman',agah_pricing_amount('hybrid','monthly')===1000000);
price_check('Hybrid yearly 10800000 toman',agah_pricing_amount('hybrid','annual')===10800000);
price_check('Enterprise is quote-only',agah_pricing_amount('enterprise','annual')===null);
price_check('Unknown tariff is rejected',agah_pricing_amount('injected','monthly')===null);
price_check('Unknown period is rejected',agah_pricing_amount('hybrid','weekly')===null);
$old=get_theme_mod('agah_launch_open',true);set_theme_mod('agah_launch_open',true);
try{
 $s=agah_pricing_selection(array('agah_plan'=>'specialized','agah_domain'=>'manufacturing','agah_period'=>'annual','agah_method'=>'zarinpal','amount_toman'=>'1'));
 price_check('Server recomputes price despite forged amount',is_array($s)&&$s['amount_toman']===5400000&&$s['domain']==='manufacturing');
 price_check('Lead explicitly does not assert payment',strpos(agah_pricing_summary($s),'پرداخت یا اشتراک فعال نیست')!==false);
 $x=agah_pricing_selection(array('agah_plan'=>'hybrid','agah_domain'=>'manufacturing','agah_period'=>'annual'));
 price_check('Hybrid has no specialty choice',$x['domain']===''&&$x['amount_toman']===10800000);
 price_check('Missing specialty is rejected',is_wp_error(agah_pricing_selection(array('agah_plan'=>'specialized','agah_period'=>'monthly'))));
 price_check('Invalid payment preference is rejected',is_wp_error(agah_pricing_selection(array('agah_plan'=>'hybrid','agah_period'=>'monthly','agah_method'=>'fake'))));
 price_check('Unknown plan is rejected',is_wp_error(agah_pricing_selection(array('agah_plan'=>'<script>'))));
 set_theme_mod('agah_launch_open',false);
 $closed=agah_pricing_selection(array('agah_plan'=>'hybrid','agah_period'=>'annual'));
 price_check('Closed festival supplies no promotional quote',$closed['amount_toman']===null&&!$closed['promotion']);
 ob_start();agah_pricing_render();$html=ob_get_clean();
 price_check('Closed festival removes all promotional amounts',strpos($html,'۵۰۰٬۰۰۰')===false&&strpos($html,'۵٬۴۰۰٬۰۰۰')===false&&strpos($html,'جشنواره افتتاحیه پایان')!==false);
 price_check('Anonymous pricing does not change ERP schema',get_option('agah_erp_db_ver')==='10'&&count(\Agah\Erp\Core\Schema::tables())===60);
}finally{set_theme_mod('agah_launch_open',$old);}
$pass=$GLOBALS['agah_pricing_pass'];$fail=$GLOBALS['agah_pricing_fail'];echo "RESULT: $pass passed; $fail failed\n";if($fail)WP_CLI::error('Pricing tests failed');
