<?php
if(!defined('ABSPATH')) exit; get_header(); while ( have_posts() ) : the_post(); ?>
<div class="page-hero"><div class="shell">
	<h1><?php if(class_exists('Agah\\Erp\\Http\\SecurityController')&&\Agah\Erp\Http\SecurityController::isPage())echo '<span data-agah="agah_erp_title">'.esc_html(get_theme_mod('agah_erp_title','سامانه حسابداری')?:'سامانه حسابداری').'</span>';else the_title(); ?></h1>
	
</div></div>
<div class="shell content-wrap no-side">
	<article class="entry">
		<?php if ( has_post_thumbnail() ) the_post_thumbnail( 'large', array( 'style' => 'border-radius:var(--radius);margin-bottom:1.2rem' ) ); ?>
		<?php the_content(); ?>
		<?php wp_link_pages(); ?>
		<?php if ( comments_open() || get_comments_number() ) comments_template(); ?>
	</article>
	
</div>
<?php endwhile; get_footer(); ?>
