(()=>{'use strict';
const section=document.querySelector('#pricing'),forms=[...document.querySelectorAll('.agah-request-plan')];
const fa=n=>Number(n).toLocaleString('fa-IR');
if(section){
 section.classList.add('agah-pricing-ready');
 const update=()=>{const annual=section.querySelector('[name=agah_billing_view]:checked')?.value==='annual';section.classList.toggle('agah-show-annual',annual);const domain=section.querySelector('[name=agah_specialty]:checked')?.value||'trading';section.querySelectorAll('[data-domain-feature]').forEach(el=>el.hidden=el.dataset.domainFeature!==domain);const note=section.querySelector('[data-production-note]');if(note)note.hidden=domain!=='manufacturing';
 section.querySelectorAll('[data-plan-select]').forEach(a=>{const u=new URL(a.href);u.searchParams.set('agah_period',annual?'annual':'monthly');u.searchParams.set('agah_domain',domain);a.href=u.href;});};
 section.addEventListener('change',update);update();
 section.querySelectorAll('[data-plan-select]').forEach(a=>a.addEventListener('click',e=>{if(!forms.length||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;const u=new URL(a.href),form=forms[0];['agah_plan','agah_domain','agah_period'].forEach(k=>form.querySelector(`[name=${k}]`).value=u.searchParams.get(k)||'');form.dispatchEvent(new Event('change',{bubbles:true}));e.preventDefault();form.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth',block:'center'});form.querySelector('[name=agah_plan]').focus({preventScroll:true});}));
}
forms.forEach(form=>{const raw=form.nextElementSibling;if(!raw?.classList.contains('agah-pricing-data'))return;let data;try{data=JSON.parse(raw.textContent);}catch{return;}
 const update=()=>{const plan=form.querySelector('[name=agah_plan]').value,period=form.querySelector('[name=agah_period]').value,domain=form.querySelector('[name=agah_domain]').value;
 form.querySelector('[data-request-domain]').hidden=plan!=='specialized';form.querySelector('[data-request-period]').hidden=!plan||plan==='enterprise';form.querySelector('[data-request-method]').hidden=!plan;
 let text='درخواست عمومی / مشاوره';if(plan&&data.plans[plan]){text='طرح '+data.plans[plan].name+(plan==='specialized'?' — '+data.domains[domain]:'');if(plan==='enterprise'||!data.open)text+='؛ قیمت پس از تماس و توافق';else{const n=data.plans[plan].monthly;text+=period==='annual'?'؛ پرداخت یکجای سال: '+fa(n*108/10)+' تومان (معادل ماهانه '+fa(n*9/10)+' تومان)':'؛ پرداخت ماهانه: '+fa(n)+' تومان';}text+='؛ نیازمند تأیید ظرفیت و مبلغ پیش از پرداخت.';}form.querySelector('[data-request-summary]').textContent=text;};
 form.addEventListener('change',update);update();
 // Keep native selects and keyboard semantics, with a labelled search beside each select.
 form.querySelectorAll('select').forEach(select=>{const input=document.createElement('input');input.type='search';input.placeholder='جست‌وجو در گزینه‌ها…';input.setAttribute('aria-label','جست‌وجو در '+select.parentElement.firstChild.textContent.trim());select.before(input);input.addEventListener('input',()=>{const q=input.value.trim().replace(/ي/g,'ی').replace(/ك/g,'ک');[...select.options].forEach(o=>o.hidden=!!q&&!o.selected&&!o.textContent.includes(q));});input.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();select.focus();}if(e.key==='Escape'){input.value='';input.dispatchEvent(new Event('input'));select.focus();}});});
});
})();
