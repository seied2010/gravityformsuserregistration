<?php
/**
 * قالب «حسابداری آگاه» — نقطهٔ ورود قالب.
 *
 * ساختار کلی (جزئیات در docs/ARCHITECTURE.md):
 *   ۱) لایهٔ سایت (معرفی/وبلاگ/تماس/سئو): همین فایل + inc/*.php
 *   ۲) لایهٔ سامانهٔ حسابداری (ERP): پوشهٔ erp/ — کاملاً مستقل از لایهٔ سایت.
 *      هیچ فایلی در erp/ به توابع agah_* لایهٔ سایت وابسته نیست؛ بنابراین برای تبدیل به افزونه
 *      کافی است پوشهٔ erp/ همراه یک فایل هدر افزونه منتقل شود (docs/PLUGIN-SPLIT.md).
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'AGAH_THEME_VERSION', '3.0.0-alpha8' );

function agah_setup() {
	load_theme_textdomain( 'agah', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 240, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	register_nav_menus( array(
		'primary' => 'منوی اصلی',
		'footer'  => 'منوی پایین سایت',
	) );
	add_image_size( 'agah-card', 640, 400, true );
}
add_action( 'after_setup_theme', 'agah_setup' );

function agah_assets() {
	wp_enqueue_style( 'agah-style', get_stylesheet_uri(), array(), AGAH_THEME_VERSION );
	wp_add_inline_style( 'agah-style', agah_dynamic_css() );
	wp_enqueue_script( 'agah-nav', get_template_directory_uri() . '/assets/js/nav.js', array(), AGAH_THEME_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'agah_assets' );

function agah_widgets() {
	register_sidebar( array(
		'name' => 'سایدبار', 'id' => 'sidebar-1',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget' => '</section>',
		'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>',
	) );
}
add_action( 'widgets_init', 'agah_widgets' );

/** خواندن یک تنظیم سفارشی‌ساز با مقدار پیش‌فرض (مقدار خالی = پیش‌فرض). */
function agah_mod( $key, $default = '' ) {
	$v = get_theme_mod( $key, $default );
	return ( $v === '' || $v === null ) ? $default : $v;
}

/** متغیرهای CSS لایهٔ سایت از تنظیمات سفارشی‌ساز (رنگ‌ها، گردی گوشه‌ها، عرض). */
function agah_dynamic_css() {
	$map = array(
		'--c-primary'   => agah_mod( 'agah_c_primary', '#12304A' ),
		'--c-brand'     => agah_mod( 'agah_c_brand', '#1F6F5C' ),
		'--c-secondary' => agah_mod( 'agah_c_brand', '#1F6F5C' ),
		'--c-accent'    => agah_mod( 'agah_c_accent', '#C8963E' ),
		'--c-bg'        => agah_mod( 'agah_c_bg', '#F5F8F7' ),
		'--radius'      => absint( agah_mod( 'agah_radius', 14 ) ) . 'px',
		'--shell'       => absint( agah_mod( 'agah_width', 1180 ) ) . 'px',
	);
	$css = ':root{';
	foreach ( $map as $k => $v ) {
		$css .= $k . ':' . esc_attr( $v ) . ';';
	}
	$css .= '}body{font-size:' . absint( agah_mod( 'agah_fs', 16 ) ) . 'px}';
	return $css;
}

function agah_excerpt_length() { return 28; }
add_filter( 'excerpt_length', 'agah_excerpt_length' );
add_filter( 'excerpt_more', '__return_empty_string' );

function agah_pagination() {
	the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => 'قبلی', 'next_text' => 'بعدی', 'class' => 'pagination' ) );
}

function agah_fallback_menu() {
	echo '<ul class="nav-menu"><li><a href="' . esc_url( home_url( '/' ) ) . '">صفحهٔ اصلی</a></li>';
	wp_list_pages( array( 'title_li' => '', 'depth' => 1, 'number' => 5 ) );
	echo '</ul>';
}

/** پیش‌نمایش سفارشی‌ساز: جای درست آیکن قلم آبی. */
function agah_preview_css() {
	if ( is_customize_preview() ) {
		echo '<style>[data-customize-partial-id]{position:relative}.agah-e{display:inline}</style>';
	}
}
add_action( 'wp_head', 'agah_preview_css' );

require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/contact.php';
require get_template_directory() . '/inc/seo.php';
require get_template_directory() . '/inc/blog.php';
require get_template_directory() . '/inc/comment-guard.php';

/* سامانهٔ حسابداری (ERP) — مستقل از لایهٔ سایت */
require get_template_directory() . '/erp/bootstrap.php';

/** نشانی صفحهٔ سامانه (برای دکمه‌های هدر سایت). فقط یک پوشش نازک روی ERP. */
function agah_acc_page_url() {
	return function_exists( 'agah_erp_url' ) ? agah_erp_url() : home_url( '/accounting/' );
}
