/* فرم‌های ERP: جلوگیری از ارسال دوباره، محاسبهٔ دقیق BigInt و تفصیلی وابسته؛ دادهٔ کاربر با innerHTML نوشته نمی‌شود. */
(function () {
    'use strict';
    document.querySelectorAll('.erp-scroll').forEach(el=>{el.tabIndex=0;el.setAttribute('role','region');el.setAttribute('aria-label','جدول؛ برای دیدن ستون‌های بیشتر اسکرول کنید');});
    const digits = s => String(s).replace(/[۰-۹]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/[٬,\s]/g,'').replace(/٫/g,'.');
    const showErrors=(errors,form)=>{
        let modal=document.querySelector('#agah-form-errors');if(!modal){modal=document.createElement('dialog');modal.id='agah-form-errors';modal.className='erp-error-dialog';modal.setAttribute('aria-labelledby','agah-error-title');document.body.append(modal);}
        modal.replaceChildren();const title=document.createElement('h2');title.id='agah-error-title';title.textContent='اطلاعات را اصلاح کنید';modal.append(title);const list=document.createElement('ul');
        let first=null;Object.entries(errors).forEach(([field,message])=>{const li=document.createElement('li');li.textContent=message;li.dataset.errorField=field;list.append(li);const name=field.replace(/\.([^.]*)/g,'[$1]');const input=form?.elements.namedItem(name);if(input?.setAttribute){input.setAttribute('aria-invalid','true');first=first||input;}});modal.append(list);
        const close=document.createElement('button');close.type='button';close.className='btn btn-primary';close.textContent='اصلاح اطلاعات';close.addEventListener('click',()=>{modal.close();first?.focus();});modal.append(close);if(!modal.open)modal.showModal();close.focus();
    };
    document.querySelectorAll('.erp form[method="post"]').forEach(form=>{
        form.addEventListener('invalid',e=>{e.preventDefault();const label=e.target.closest('label')?.childNodes[0]?.textContent?.trim()||'فیلد لازم';showErrors({[e.target.name]:e.target.tagName==='SELECT'?'گزینه '+label+' را انتخاب کنید.':label+' را به‌درستی وارد کنید.'},form);},true);
        form.addEventListener('submit',async e=>{
            const action=form.elements.namedItem('act')?.value;
            if(!action||action==='module_invoice_official'||action==='module_party_reveal'||action==='module_legal_sensitive'||!(action.startsWith('module_')||['company_create','account_create','account_toggle','account_delete','fy_create','period_toggle'].includes(action)))return;
            e.preventDefault();if(form.dataset.submitting)return;const data=new FormData(form);if(e.submitter?.name)data.append(e.submitter.name,e.submitter.value);form.dataset.submitting='1';
            const buttons=[...form.querySelectorAll('button[type="submit"]')];buttons.forEach(b=>{b.disabled=true;b.setAttribute('aria-busy','true');});form.querySelectorAll('[aria-invalid]').forEach(x=>x.removeAttribute('aria-invalid'));
            try{const response=await fetch(form.action||location.href,{method:'POST',body:data,credentials:'same-origin',headers:{'X-Agah-Form':'1','Accept':'application/json'}});const result=await response.json();if(result.errors&&Object.keys(result.errors).length)showErrors(result.errors,form);else if(response.ok&&result.redirect)location.assign(result.redirect);else showErrors({form:'پاسخ معتبر دریافت نشد؛ صفحه را تازه و وضعیت ثبت را بررسی کنید.'},form);}
            catch(err){showErrors({form:'ارتباط با سرور کامل نشد؛ اطلاعات فرم حفظ شده است. پیش از ارسال دوباره وضعیت ثبت را بررسی کنید.'},form);}
            finally{delete form.dataset.submitting;buttons.forEach(b=>{b.disabled=false;b.removeAttribute('aria-busy');});}
        });
    });
    document.querySelectorAll('[data-print]').forEach(b=>b.addEventListener('click',()=>window.print()));
    const form=document.querySelector('.erp-voucher-form');
    if(form) {
        const body=form.querySelector('[data-lines]');let next=body.children.length;
        const fmt=n=>{const neg=n<0n;const a=neg?-n:n;const dec=String(a%100n).padStart(2,'0').replace(/0+$/,'');return(neg?'-':'')+new Intl.NumberFormat('fa-IR').format(a/100n)+(dec?'٫'+dec:'');};
        const amount=s=>{
            s=digits(s||'0');if(!/^\d+(\.\d{1,3})?$/.test(s)) throw new Error('invalid');
            const [whole,frac='0']=s.split('.');
            const precision=form.dataset.unit==='toman'?3:2;if(frac.length>precision)throw new Error('precision');return BigInt(whole)*10n**BigInt(precision)+BigInt(frac.padEnd(precision,'0'));
        };
        const totals=()=>{
            let debit=0n,credit=0n;const output=form.querySelector('[data-totals]');
            try {
                body.querySelectorAll('[data-line]').forEach(r=>{debit+=amount(r.querySelector('[data-debit]').value);credit+=amount(r.querySelector('[data-credit]').value);});
                output.textContent='جمع بدهکار: '+fmt(debit)+' ریال | بستانکار: '+fmt(credit)+' ریال | اختلاف: '+fmt(debit-credit)+' ریال';
                output.classList.toggle('erp-err',debit!==credit);
            } catch(e) {output.textContent='مبلغ معتبر وارد کنید؛ جمع نهایی در سرور کنترل می‌شود.';output.classList.add('erp-err');}
        };
        const dependent=r=>{
            const a=r.querySelector('[data-account]'),d=r.querySelector('[data-detail]'),o=a.selectedOptions[0];
            const rule=o?.dataset.rule||'optional',kind=o?.dataset.kind||'';
            [...d.options].forEach(opt=>{opt.hidden=opt.value!=='0' && (rule==='none'||(kind && opt.dataset.kind!==kind));opt.disabled=opt.hidden;});
            if(d.selectedOptions[0]?.disabled) d.value='0';
            d.required=rule==='required';d.options[0].disabled=d.required;
        };
        const bind=r=>{
            const a=r.querySelector('[data-account]');a.addEventListener('change',()=>dependent(r));dependent(r);
            r.querySelector('[data-account-search]').addEventListener('input',e=>{
                const q=digits(e.target.value).toLocaleLowerCase();
                [...a.options].forEach(o=>{o.hidden=o.value!=='' && !digits(o.textContent).toLocaleLowerCase().includes(q);});
            });
            r.querySelector('[data-remove-line]').addEventListener('click',()=>{if(body.children.length>1) {r.remove();totals();}});
        };
        const add=()=>{
            if(body.children.length>=200) return;
            const template=document.querySelector('[data-line-template]');const r=template.content.firstElementChild.cloneNode(true);
            r.querySelectorAll('[name]').forEach(el=>{el.name=el.name.replace('__INDEX__',String(next));});next++;
            body.append(r);bind(r);r.querySelector('select').focus();totals();
        };
        body.querySelectorAll('[data-line]').forEach(bind);body.addEventListener('input',totals);
        form.querySelector('[data-add-line]').addEventListener('click',add);totals();
        form.addEventListener('keydown',e=>{if(e.altKey&&e.key.toLowerCase()==='n'){e.preventDefault();add();}if(e.altKey&&e.key.toLowerCase()==='s'){e.preventDefault();form.requestSubmit();}});
    }
    const moneyName=/(?:^|\[)(?:amount|payment_amount|debit|credit|unit_price|discount_amount|extra_cost|credit_limit|sale_price|purchase_price|statement_balance|base_salary|benefits|extra_benefits|deductions|insurance_ceiling|tax_exemption|cost|residual|proceeds|benefits_insurance_exempt|benefits_tax_exempt|overtime_base_extra|extra_insurance_exempt|extra_tax_exempt|upper_\d+)(?:\]|$)/;
    function formatMoney(input){const start=input.selectionStart??input.value.length;const before=digits(input.value.slice(0,start)).length;const raw=digits(input.value);if(!/^-?\d*(?:\.\d*)?$/.test(raw))return;const parts=raw.split('.');input.value=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,',')+(parts.length>1?'.'+parts[1]:'');let seen=0,caret=0;while(caret<input.value.length&&seen<before){if(input.value[caret]!==',')seen++;caret++;}if(document.activeElement===input)input.setSelectionRange(caret,caret);}
    function initMoney(root=document){root.querySelectorAll('.erp input').forEach(input=>{if(input.dataset.moneyReady||!moneyName.test(input.name)||input.type==='hidden')return;input.dataset.moneyReady='1';input.inputMode='decimal';if(input.type==='number')input.type='text';input.addEventListener('input',()=>formatMoney(input));formatMoney(input);});}
    window.agahInitMoney=initMoney;initMoney();
    /* انتخابگر محلی شمسی با Intl تقویم ایرانی مرورگر؛ ذخیره و اعتبارسنجی قطعی در PHP/Jalali انجام می‌شود. */
    const calFmt=new Intl.DateTimeFormat('en-US-u-ca-persian',{year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});
    const parts=date=>{const p={};calFmt.formatToParts(date).forEach(x=>{if(x.type!=='literal')p[x.type]=Number(x.value);});return p;};
    const plus=(date,n)=>new Date(date.getTime()+n*86400000);
    function initCalendars(root=document){root.querySelectorAll('[data-jalali]').forEach(input=>{
        if(input.dataset.calendarReady)return;input.dataset.calendarReady='1';
        input.placeholder=input.placeholder||'۱۴۰۵/۰۱/۰۱';
        const trigger=document.createElement('button');trigger.type='button';trigger.className='btn btn-outline btn-sm erp-date-trigger';trigger.textContent='انتخاب تاریخ';trigger.setAttribute('aria-label','انتخاب تاریخ شمسی');
        input.insertAdjacentElement('afterend',trigger);
        trigger.addEventListener('click',()=>{
            document.querySelectorAll('.erp-calendar').forEach(x=>x.remove());
            const box=document.createElement('div');box.className='erp-calendar';box.setAttribute('role','dialog');box.setAttribute('aria-label','تقویم شمسی');
            trigger.insertAdjacentElement('afterend',box);
            let current=new Date();current=new Date(Date.UTC(current.getFullYear(),current.getMonth(),current.getDate()));
            const wanted=digits(input.value).match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
            if(wanted) {
                const approx=new Date(Date.UTC(Number(wanted[1])+621,Number(wanted[2])+1,20));
                for(let n=-65;n<65;n++){const candidate=plus(approx,n),p=parts(candidate);if(p.year===Number(wanted[1])&&p.month===Number(wanted[2])&&p.day===Number(wanted[3])){current=candidate;break;}}
            }
            const choose=date=>{const p=parts(date);input.value=p.year+'/'+String(p.month).padStart(2,'0')+'/'+String(p.day).padStart(2,'0');input.dispatchEvent(new Event('input',{bubbles:true}));box.remove();input.focus();};
            const button=(text,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=text;b.addEventListener('click',fn);return b;};
            const render=()=>{
                box.replaceChildren();const p=parts(current),first=plus(current,1-p.day),head=document.createElement('div');
                head.append(button('ماه قبل',()=>{current=plus(first,-1);render();}));
                const title=document.createElement('strong');title.textContent=new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'long',timeZone:'UTC'}).format(current);head.append(title);
                head.append(button('ماه بعد',()=>{current=plus(first,32);const np=parts(current);current=plus(current,1-np.day);render();}));box.append(head);
                const grid=document.createElement('div');grid.className='erp-calendar-grid';['ش','ی','د','س','چ','پ','ج'].forEach(t=>{const s=document.createElement('span');s.textContent=t;grid.append(s);});
                const offset=(first.getUTCDay()+1)%7;for(let i=0;i<offset;i++)grid.append(document.createElement('span'));
                for(let i=0;i<31;i++){const date=plus(first,i),v=parts(date);if(v.month!==p.month)break;const b=button(new Intl.NumberFormat('fa-IR').format(v.day),()=>choose(date));b.setAttribute('aria-label',v.year+'/'+v.month+'/'+v.day);grid.append(b);}
                box.append(grid,button('امروز',()=>choose(new Date())),button('بستن',()=>{box.remove();trigger.focus();}));
            };
            box.addEventListener('keydown',e=>{if(e.key==='Escape'){box.remove();trigger.focus();}});render();box.querySelector('button').focus();
        });
    });}
    window.agahInitCalendars=initCalendars;initCalendars();
}());
