<?php
/** Native WordPress registration. No Gravity Forms or other plugin is required. */
defined( 'ABSPATH' ) || exit;

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'hamyaar-qom', get_stylesheet_uri(), array(), '2.2.0' );
	wp_enqueue_script( 'hamyaar-qom', get_theme_file_uri( 'assets/portal.js' ), array(), '2.2.0', true );
} );
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', array( 'style', 'script' ) );
	add_theme_support( 'post-thumbnails' );
	register_nav_menus( array( 'primary' => 'فهرست اصلی', 'footer' => 'فهرست پایین صفحه' ) );
} );

require_once get_theme_file_path( 'inc/portal.php' );

function native_registration_url() {
	return add_query_arg( 'register', '1', home_url( '/' ) );
}

function native_registration_request() {
	return ( isset( $_GET['register'] ) && '1' === $_GET['register'] )
		|| ( isset( $_GET['registered'] ) && '1' === $_GET['registered'] )
		|| ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && 'create_account' === native_registration_value( 'action' ) );
}

add_filter( 'template_include', function ( $template ) {
	return native_registration_request() ? get_theme_file_path( 'registration.php' ) : $template;
}, 99 );

function native_registration_value( $key ) {
	return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
}

function native_registration_error( $message, $status = 422 ) {
	$GLOBALS['native_registration_error'] = $message;
	status_header( $status );
}

add_action( 'template_redirect', function () {
	if ( ! native_registration_request() ) { return; }
	nocache_headers();
	if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || 'create_account' !== native_registration_value( 'action' ) ) {
		return;
	}
	if ( is_user_logged_in() ) {
		native_registration_error( 'شما قبلاً وارد حساب خود شده‌اید.', 403 );
		return;
	}
	if ( ! get_option( 'users_can_register' ) ) {
		native_registration_error( 'ثبت‌نام در حال حاضر غیرفعال است.', 403 );
		return;
	}
	if ( ! wp_verify_nonce( native_registration_value( '_wpnonce' ), 'native_create_account' ) ) {
		native_registration_error( 'اعتبار فرم تمام شده است. صفحه را تازه کنید و دوباره تلاش کنید.', 403 );
		return;
	}
	if ( '' !== native_registration_value( 'website' ) ) {
		native_registration_error( 'درخواست ثبت‌نام معتبر نیست.', 400 );
		return;
	}
	$rate_key = 'native_reg_' . hash_hmac( 'sha256', $_SERVER['REMOTE_ADDR'] ?? 'unknown', wp_salt( 'nonce' ) );
	$attempts = (int) get_transient( $rate_key );
	if ( $attempts >= 10 ) {
		native_registration_error( 'تعداد درخواست‌ها زیاد است. ۱۵ دقیقهٔ دیگر دوباره تلاش کنید.', 429 );
		return;
	}
	set_transient( $rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );
	$username = trim( native_registration_value( 'username' ) );
	$email = trim( native_registration_value( 'email' ) );
	$password = native_registration_value( 'password' );
	if ( strlen( $username ) < 3 || strlen( $username ) > 60 || ! validate_username( $username ) || sanitize_user( $username, true ) !== $username ) {
		native_registration_error( 'نام کاربری باید ۳ تا ۶۰ نویسه و شامل حروف لاتین، عدد، فاصله یا نشانه‌های مجاز باشد.' );
		return;
	}
	if ( ! is_email( $email ) || strlen( $email ) > 100 ) {
		native_registration_error( 'یک نشانی ایمیل معتبر وارد کنید.' );
		return;
	}
	$password_length = mb_strlen( $password, 'UTF-8' );
	if ( $password_length < 12 || $password_length > 128 ) {
		native_registration_error( 'رمز عبور باید بین ۱۲ تا ۱۲۸ نویسه باشد.' );
		return;
	}
	if ( ! hash_equals( $password, native_registration_value( 'password_confirmation' ) ) ) {
		native_registration_error( 'رمز عبور و تکرار آن یکسان نیستند.' );
		return;
	}
	$user_id = wp_insert_user( array(
		'user_login' => $username,
		'user_email' => $email,
		'user_pass'  => $password,
		'role'       => 'subscriber',
	) );
	if ( is_wp_error( $user_id ) ) {
		$duplicate = array_intersect( $user_id->get_error_codes(), array( 'existing_user_login', 'existing_user_email' ) );
		native_registration_error( $duplicate ? 'این نام کاربری یا ایمیل قبلاً ثبت شده است.' : 'ساخت حساب انجام نشد. دوباره تلاش کنید.' );
		return;
	}
	wp_safe_redirect( add_query_arg( 'registered', '1', native_registration_url() ), 303 );
	exit;
} );
