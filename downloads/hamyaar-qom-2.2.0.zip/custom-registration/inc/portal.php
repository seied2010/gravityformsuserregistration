<?php
defined( 'ABSPATH' ) || exit;

function hq_section_categories( $section ) {
	$names = array( 'wiki' => array( 'ویکی قم', 'دانشنامه قم', 'دانشنامه' ), 'places' => array( 'قم‌شناسی', 'قم شناسی', 'اماکن تاریخی' ), 'journal' => array( 'یادداشت‌ها و پژوهش‌ها', 'یادداشت ها و پژوهش ها' ), 'history' => array( 'تاریخ و مشاهیر' ) );
	$normalize = static function ( $value ) { return str_replace( array( ' ', '‌', '-' ), '', $value ); };
	$wanted = array_map( $normalize, $names[ $section ] ?? array() );
	$ids = array();
	foreach ( get_categories( array( 'hide_empty' => false ) ) as $category ) {
		$slugs = array( 'wiki' => 'qomwiki', 'places' => 'qom-studies', 'journal' => 'essays', 'history' => 'history-notables' );
		if ( in_array( $normalize( $category->name ), $wanted, true ) || $category->slug === ( $slugs[ $section ] ?? '' ) ) { $ids[] = $category->term_id; }
	}
	return $ids;
}

function hq_section_query( $section, $limit ) {
	$categories = hq_section_categories( $section );
	$args = array( 'post_status' => 'publish', 'posts_per_page' => $limit, 'ignore_sticky_posts' => true, 'no_found_rows' => true );
	$ids = array();
	if ( $categories || 'journal' === $section ) {
		$source_args = $args + array( 'post_type' => 'post', 'fields' => 'ids' );
		if ( $categories ) { $source_args['category__in'] = $categories; }
		$ids = get_posts( $source_args );
	}
	if ( in_array( $section, array( 'wiki', 'places' ), true ) ) {
		$ids = array_merge( $ids, get_posts( $args + array( 'post_type' => 'wiki' === $section ? 'hq_wiki' : 'hq_place', 'fields' => 'ids' ) ) );
	}
	$args['post_type'] = array( 'post', 'hq_wiki', 'hq_place' );
	$args['post__in'] = $ids ?: array( 0 );
	if ( 'wiki' === $section ) { $args['orderby'] = 'title'; $args['order'] = 'ASC'; }
	return new WP_Query( $args );
}

function hq_section_url( $section ) {
	$categories = hq_section_categories( $section );
	if ( $categories ) { return get_category_link( $categories[0] ); }
	if ( 'history' === $section ) { return add_query_arg( 's', 'تاریخ قم', home_url( '/' ) ); }
	if ( 'journal' === $section ) {
		$posts_page = (int) get_option( 'page_for_posts' );
		return $posts_page ? get_permalink( $posts_page ) : add_query_arg( 's', '', home_url( '/' ) );
	}
	return get_post_type_archive_link( 'wiki' === $section ? 'hq_wiki' : 'hq_place' );
}

add_action( 'customize_register', function ( $customizer ) {
	$customizer->add_section( 'hq_home', array( 'title' => 'صفحهٔ اصلی همیار قم', 'priority' => 30 ) );
	$customizer->add_setting( 'hq_hero_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
	$customizer->add_control( new WP_Customize_Image_Control( $customizer, 'hq_hero_image', array( 'label' => 'تصویر بخش آغازین', 'section' => 'hq_home' ) ) );
	$customizer->add_setting( 'hq_hero_alt', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	$customizer->add_control( 'hq_hero_alt', array( 'label' => 'توضیح تصویر برای دسترس‌پذیری', 'section' => 'hq_home', 'type' => 'text' ) );
} );

add_action( 'init', function () {
	foreach ( array( 'hq_wiki' => array( 'دانشنامه', 'مدخل دانشنامه', 'encyclopedia' ), 'hq_place' => array( 'اماکن تاریخی', 'مکان تاریخی', 'heritage' ) ) as $type => $labels ) {
		register_post_type( $type, array(
			'labels' => array( 'name' => $labels[0], 'singular_name' => $labels[1], 'add_new_item' => 'افزودن ' . $labels[1], 'edit_item' => 'ویرایش ' . $labels[1] ),
			'public' => true, 'show_in_rest' => true, 'has_archive' => true,
			'rewrite' => array( 'slug' => $labels[2] ),
			'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ),
			'menu_icon' => 'hq_wiki' === $type ? 'dashicons-book-alt' : 'dashicons-location-alt',
		) );
	}
} );

add_action( 'after_switch_theme', function () {
	// The next init registers the content types before refreshing their routes.
	update_option( 'hq_flush_routes', '1', false );
} );
add_action( 'init', function () {
	if ( get_option( 'hq_flush_routes' ) || '2.2.0' !== get_option( 'hq_routes_version' ) ) {
		flush_rewrite_rules( false );
		delete_option( 'hq_flush_routes' );
		update_option( 'hq_routes_version', '2.2.0', false );
	}
}, 20 );

function hq_first_letter( $title ) {
	$title = preg_replace( '/^[\s\x{200c}\x{200d}\x{200e}\x{200f}]+/u', '', wp_strip_all_tags( $title ) );
	$letter = mb_substr( $title, 0, 1, 'UTF-8' );
	$map = array( 'ا' => 'الف', 'أ' => 'الف', 'إ' => 'الف', 'ٱ' => 'الف', 'ك' => 'ک', 'ي' => 'ی', 'ئ' => 'ی', 'ة' => 'ه' );
	return $map[ $letter ] ?? $letter;
}

function hq_icon( $name ) {
	$paths = array(
		'arch' => '<path d="M4 21V10a8 8 0 0 1 16 0v11M8 21V11a4 4 0 0 1 8 0v10M2 21h20M12 2v3"/>',
		'search' => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
		'book' => '<path d="M12 5v16M3 4c4-1 7 0 9 2 2-2 5-3 9-2v15c-4-1-7 0-9 2-2-2-5-3-9-2z"/>',
		'pin' => '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
		'quill' => '<path d="m4 20 5-9L20 3l1 1-8 11-9 5Zm5-9 4 4M3 21l7-7"/>',
		'arrow' => '<path d="M20 12H4m6-6-6 6 6 6"/>',
		'user' => '<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
		'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
		'route' => '<path d="m12 2 10 10-10 10L2 12 10 2zM8 15v-5h8m-3-3 3 3-3 3"/>',
	);
	return '<svg class="hq-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( $paths[ $name ] ?? $paths['arch'] ) . '</svg>';
}

function hq_post_image( $post_id, $class = '' ) {
	if ( has_post_thumbnail( $post_id ) ) {
		echo get_the_post_thumbnail( $post_id, 'medium_large', array( 'class' => $class, 'loading' => 'lazy' ) );
	} else {
		echo '<img class="' . esc_attr( $class ) . '" src="' . esc_url( get_theme_file_uri( 'assets/heritage.svg' ) ) . '" alt="تصویرسازی معماری ایرانی" loading="lazy" width="720" height="840">';
	}
}

add_action( 'add_meta_boxes', function ( $post_type ) {
	if ( ! in_array( $post_type, array( 'post', 'hq_place' ), true ) ) { return; }
	add_meta_box( 'hq-place-location', 'نشانی و مسیریابی', function ( $post ) {
		wp_nonce_field( 'hq_place_location', 'hq_place_nonce' );
		foreach ( array( 'address' => 'نشانی', 'latitude' => 'عرض جغرافیایی', 'longitude' => 'طول جغرافیایی' ) as $key => $label ) {
			echo '<p><label>' . esc_html( $label ) . '<br><input class="widefat" name="hq_' . esc_attr( $key ) . '" value="' . esc_attr( get_post_meta( $post->ID, '_hq_' . $key, true ) ) . '"' . ( 'address' === $key ? '' : ' inputmode="decimal" dir="ltr"' ) . '></label></p>';
		}
	}, $post_type );
} );
add_action( 'save_post', function ( $post_id ) {
	if ( ! in_array( get_post_type( $post_id ), array( 'post', 'hq_place' ), true ) ) { return; }
	if ( ! isset( $_POST['hq_place_nonce'] ) || ! is_string( $_POST['hq_place_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hq_place_nonce'] ) ), 'hq_place_location' ) || ! current_user_can( 'edit_post', $post_id ) || wp_is_post_revision( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}
	foreach ( array( 'address' => 0, 'latitude' => 90, 'longitude' => 180 ) as $key => $limit ) {
		if ( ! isset( $_POST[ 'hq_' . $key ] ) || ! is_string( $_POST[ 'hq_' . $key ] ) ) { continue; }
		$value = sanitize_text_field( wp_unslash( $_POST[ 'hq_' . $key ] ) );
		if ( $limit && ( ! is_numeric( $value ) || abs( (float) $value ) > $limit ) ) {
			delete_post_meta( $post_id, '_hq_' . $key );
			continue;
		}
		update_post_meta( $post_id, '_hq_' . $key, $value );
	}
} );

function hq_route_url( $post_id ) {
	$lat = get_post_meta( $post_id, '_hq_latitude', true );
	$lng = get_post_meta( $post_id, '_hq_longitude', true );
	if ( '' === $lat || '' === $lng || ! is_numeric( $lat ) || ! is_numeric( $lng ) || abs( (float) $lat ) > 90 || abs( (float) $lng ) > 180 ) { return ''; }
	return add_query_arg( array( 'api' => '1', 'destination' => $lat . ',' . $lng ), 'https://www.google.com/maps/dir/' );
}
