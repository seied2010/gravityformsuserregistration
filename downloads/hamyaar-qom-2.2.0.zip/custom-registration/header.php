<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#07261E">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'hq-site' ); ?>>
<?php wp_body_open(); ?>
<a class="hq-skip-link" href="#main-content">رفتن به محتوای اصلی</a>
<header class="hq-header">
	<div class="hq-container hq-header-inner">
		<a class="hq-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="همیار قم؛ صفحهٔ اصلی">
			<span class="hq-brand-mark"><?php echo hq_icon( 'arch' ); ?></span>
			<span><strong>همیار قم</strong><small>روایتِ تاریخ، پیوندِ امروز</small></span>
		</a>
		<button class="hq-menu-toggle" type="button" aria-expanded="false" aria-controls="hq-navigation" aria-label="باز کردن فهرست"><?php echo hq_icon( 'menu' ); ?></button>
		<nav id="hq-navigation" class="hq-navigation" aria-label="فهرست اصلی">
		<?php if ( has_nav_menu( 'primary' ) ) : ?>
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'depth' => 2 ) ); ?>
		<?php else : ?>
			<ul><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"<?php if ( is_front_page() ) { echo ' aria-current="page"'; } ?>>خانه</a></li><li><a href="<?php echo esc_url( home_url( '/#encyclopedia' ) ); ?>">دانشنامهٔ قم</a></li><li><a href="<?php echo esc_url( home_url( '/#heritage' ) ); ?>">میراث و اماکن</a></li><li><a href="<?php echo esc_url( hq_section_url( 'history' ) ); ?>">تاریخ و مشاهیر</a></li><li><a href="<?php echo esc_url( home_url( '/#journal' ) ); ?>">یادداشت‌ها</a></li></ul>
		<?php endif; ?>
		</nav>
		<div class="hq-header-actions">
		<?php if ( is_user_logged_in() ) : ?>
			<a class="hq-btn hq-btn-outline" href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>"><?php echo hq_icon( 'user' ); ?>حساب کاربری</a>
		<?php else : ?>
			<a class="hq-btn hq-btn-outline" href="<?php echo esc_url( wp_login_url( home_url( '/' ) ) ); ?>"><?php echo hq_icon( 'user' ); ?>ورود</a>
			<?php if ( get_option( 'users_can_register' ) ) : ?><a class="hq-btn hq-btn-gold" href="<?php echo esc_url( native_registration_url() ); ?>">عضویت</a><?php endif; ?>
		<?php endif; ?>
		</div>
	</div>
</header>
