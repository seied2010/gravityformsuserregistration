<?php defined( 'ABSPATH' ) || exit; ?>
<footer class="hq-footer">
	<div class="hq-container hq-footer-main">
		<div class="hq-footer-about"><a class="hq-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="hq-brand-mark"><?php echo hq_icon( 'arch' ); ?></span><span><strong>همیار قم</strong><small>روایتِ تاریخ، پیوندِ امروز</small></span></a><p>دریچه‌ای به تاریخ، باستان‌شناسی و میراث فرهنگی قم؛ برای شناختن، خواندن و دوباره دیدن.</p></div>
		<div><h2>مسیرهای شناخت</h2><ul><li><a href="<?php echo esc_url( home_url( '/#encyclopedia' ) ); ?>">دانشنامهٔ قم</a></li><li><a href="<?php echo esc_url( home_url( '/#heritage' ) ); ?>">میراث و اماکن</a></li><li><a href="<?php echo esc_url( hq_section_url( 'history' ) ); ?>">تاریخ و مشاهیر</a></li><li><a href="<?php echo esc_url( home_url( '/#journal' ) ); ?>">یادداشت‌ها و مقاله‌ها</a></li></ul></div>
		<div><h2>همراه همیار</h2><ul><li><a href="<?php echo esc_url( is_user_logged_in() ? admin_url( 'profile.php' ) : native_registration_url() ); ?>"><?php echo is_user_logged_in() ? 'حساب کاربری' : 'عضویت در همیار'; ?></a></li><?php if ( get_privacy_policy_url() ) : ?><li><a href="<?php echo esc_url( get_privacy_policy_url() ); ?>">حریم خصوصی</a></li><?php endif; ?></ul><?php if ( has_nav_menu( 'footer' ) ) { wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1 ) ); } else { echo '<ul>'; foreach ( get_pages( array( 'post_status' => 'publish', 'number' => 50 ) ) as $info_page ) { if ( false !== mb_strpos( $info_page->post_title, 'درباره' ) || false !== mb_strpos( $info_page->post_title, 'تماس' ) ) { echo '<li><a href="' . esc_url( get_permalink( $info_page ) ) . '">' . esc_html( $info_page->post_title ) . '</a></li>'; } } echo '</ul>'; } ?></div>
	</div>
	<div class="hq-container hq-footer-bottom"><span>همیار قم · با احترام به گذشته، برای امروز</span><span>تاریخ را زنده نگه داریم.</span></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
