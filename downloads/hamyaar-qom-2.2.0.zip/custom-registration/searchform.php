<?php defined( 'ABSPATH' ) || exit; $search_id = wp_unique_id( 'hq-search-' ); ?>
<form class="hq-hero-search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
	<label class="screen-reader-text" for="<?php echo esc_attr( $search_id ); ?>">جستجو در همیار</label>
	<?php echo hq_icon( 'search' ); ?><input id="<?php echo esc_attr( $search_id ); ?>" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="عبارت موردنظر را بنویسید…" required><button class="hq-btn hq-btn-primary" type="submit">جستجو</button>
</form>
