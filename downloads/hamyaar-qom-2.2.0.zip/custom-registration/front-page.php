<?php
defined( 'ABSPATH' ) || exit;
get_header();
$wiki = hq_section_query( 'wiki', 12 );
$places = hq_section_query( 'places', 3 );
$journal = hq_section_query( 'journal', 3 );
$figures = hq_section_query( 'history', 4 );
$letters = array( 'همه', 'آ', 'الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'ژ', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ک', 'گ', 'ل', 'م', 'ن', 'و', 'ه', 'ی' );
$hero_image = get_theme_mod( 'hq_hero_image' ) ?: get_theme_file_uri( 'assets/hero.webp' );
?>
<main id="main-content" class="hq-home">
<section class="hq-hero">
	<div class="hq-container hq-hero-grid">
		<div class="hq-hero-content">
			<p class="hq-kicker"><span></span>پورتال تاریخ و میراث فرهنگی قم</p>
			<h1>قم را <em>دوباره</em> ببینیم.<br>از دل تاریخ، تا امروز.</h1>
			<p class="hq-hero-description">از روایت‌های کهن و چهره‌های ماندگار تا بناها و محله‌های تاریخی؛ همیار، دریچه‌ای برای شناخت عمیق‌تر قم.</p>
			<form class="hq-hero-search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
				<label class="screen-reader-text" for="hero-search">جستجو در همیار قم</label>
				<?php echo hq_icon( 'search' ); ?><input id="hero-search" type="search" name="s" placeholder="دنبال کدام نام، مکان یا روایت هستید؟" autocomplete="off" required><button type="submit" class="hq-btn hq-btn-primary">جستجو</button>
			</form>
			<div class="hq-hero-hint"><span>یک نام، آغاز یک کشف تازه است.</span><span class="hq-shortcut" aria-hidden="true"><kbd>Ctrl</kbd><kbd>K</kbd></span></div>
			<div class="hq-topic-links"><span>از اینجا شروع کنید:</span><a href="#encyclopedia">ویکی قم</a><a href="#heritage">اماکن تاریخی</a><a href="#journal">یادداشت‌ها</a></div>
		</div>
		<figure class="hq-hero-visual">
			<div class="hq-visual-frame"><img src="<?php echo esc_url( $hero_image ); ?>" alt="<?php echo esc_attr( get_theme_mod( 'hq_hero_alt', 'امامزاده ابراهیم در قم؛ تصویر از آرشیو همیار قم' ) ); ?>" width="700" height="430" fetchpriority="high"></div>
			<figcaption><span class="hq-caption-icon"><?php echo hq_icon( 'arch' ); ?></span><span><strong>هر گوشه، روایتی برای شنیدن</strong><small>در جست‌وجوی لایه‌های پیدا و پنهان شهر</small></span><span class="hq-caption-star" aria-hidden="true">✦</span></figcaption>
			<span class="hq-visual-label" aria-hidden="true">میراثی برای دوباره دیدن</span>
		</figure>
	</div>
</section>
<section class="hq-paths" aria-label="مسیرهای شناخت قم">
	<div class="hq-container hq-path-grid">
	<?php foreach ( array( array( 'book', 'دانشنامهٔ قم', 'از نام‌ها، واژه‌ها و روایت‌ها بیشتر بدانید.', '#encyclopedia' ), array( 'arch', 'میراث و اماکن', 'بناها و محله‌های تاریخی را از نو بشناسید.', '#heritage' ), array( 'quill', 'یادداشت و پژوهش', 'با نگاه پژوهشگران، به گذشته سفر کنید.', '#journal' ) ) as $path ) : ?>
		<a class="hq-path" href="<?php echo esc_url( $path[3] ); ?>"><span class="hq-path-icon"><?php echo hq_icon( $path[0] ); ?></span><span><strong><?php echo esc_html( $path[1] ); ?></strong><small><?php echo esc_html( $path[2] ); ?></small></span><?php echo hq_icon( 'arrow' ); ?></a>
	<?php endforeach; ?>
	</div>
</section>
<section id="encyclopedia" class="hq-section hq-wiki-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker">واژه به واژه، نزدیک‌تر به قم</p><h2>دانشنامهٔ <span>قم</span></h2><p>جست‌وجویی میان نام‌ها، مکان‌ها و روایت‌های شهر.</p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'wiki' ) ); ?>">همهٔ مدخل‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-wiki-tools"><label class="hq-wiki-search" for="wiki-search-input"><?php echo hq_icon( 'search' ); ?><span class="screen-reader-text">جستجو میان مدخل‌های این بخش</span><input id="wiki-search-input" type="search" placeholder="جستجو میان مدخل‌های این بخش…" autocomplete="off"></label><span class="hq-wiki-count" aria-live="polite" data-total="<?php echo esc_attr( $wiki->post_count ); ?>"><?php echo esc_html( number_format_i18n( $wiki->post_count ) ); ?> مدخل در این بخش</span></div>
		<div class="hq-az-list" role="group" aria-label="فیلتر الفبایی دانشنامه">
		<?php foreach ( $letters as $letter ) : ?><button type="button" class="hq-az-btn<?php echo 'همه' === $letter ? ' active' : ''; ?>" data-letter="<?php echo esc_attr( $letter ); ?>" aria-pressed="<?php echo 'همه' === $letter ? 'true' : 'false'; ?>"><?php echo esc_html( $letter ); ?></button><?php endforeach; ?>
		</div>
		<div class="hq-wiki-grid">
		<?php while ( $wiki->have_posts() ) : $wiki->the_post(); ?>
			<a class="hq-wiki-card hq-card" href="<?php the_permalink(); ?>" data-letter="<?php echo esc_attr( hq_first_letter( get_the_title() ) ); ?>" data-title="<?php echo esc_attr( get_the_title() ); ?>"><span class="hq-wiki-initial"><?php echo esc_html( hq_first_letter( get_the_title() ) ); ?></span><span><strong><?php the_title(); ?></strong><small><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 10 ) ); ?></small></span><?php echo hq_icon( 'arrow' ); ?></a>
		<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<p class="hq-empty-state" id="hq-wiki-empty"<?php if ( $wiki->post_count ) { echo ' hidden'; } ?>><?php echo $wiki->post_count ? 'مدخلی با این حرف یا عبارت پیدا نشد.' : 'هنوز مدخلی در دانشنامه منتشر نشده است.'; ?></p>
	</div>
</section>
<section id="heritage" class="hq-section hq-heritage-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker">رد پای تاریخ در کوچه‌های شهر</p><h2>میراثی که <span>دیدنی‌ست</span></h2><p>مکان‌هایی برای مکث، شناخت و دوباره دیدن.</p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'places' ) ); ?>">همهٔ مکان‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-places-grid">
		<?php while ( $places->have_posts() ) : $places->the_post(); $route = hq_route_url( get_the_ID() ); ?>
			<article class="hq-place-card hq-card"><a class="hq-place-image" href="<?php the_permalink(); ?>"><?php hq_post_image( get_the_ID() ); ?><span class="hq-image-label"><?php echo hq_icon( 'pin' ); ?>قم‌شناسی</span></a><div class="hq-place-content"><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 22 ) ); ?></p><div class="hq-place-actions"><a class="hq-text-link" href="<?php the_permalink(); ?>">شناخت بیشتر <?php echo hq_icon( 'arrow' ); ?></a><?php if ( $route ) : ?><a class="hq-route-link" href="<?php echo esc_url( $route ); ?>" target="_blank" rel="noopener noreferrer"><?php echo hq_icon( 'route' ); ?>مسیریابی</a><?php endif; ?></div></div></article>
		<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<?php if ( ! $places->post_count ) : ?><p class="hq-empty-state">هنوز مکانی در این بخش منتشر نشده است.</p><?php endif; ?>
	</div>
</section>
<?php if ( $figures->have_posts() ) : ?>
<section id="figures" class="hq-section hq-figures-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker">نام‌هایی در حافظهٔ شهر</p><h2>تاریخ و <span>چهره‌های ماندگار</span></h2><p>آشنایی با کسانی که نامشان با سرگذشت قم پیوند خورده است.</p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'history' ) ); ?>">همهٔ روایت‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-figures-grid"><?php while ( $figures->have_posts() ) : $figures->the_post(); ?><a class="hq-figure-card hq-card" href="<?php the_permalink(); ?>"><span class="hq-figure-image"><?php hq_post_image( get_the_ID() ); ?></span><span class="hq-figure-title"><?php the_title(); ?></span><span class="hq-text-link">خواندن روایت <?php echo hq_icon( 'arrow' ); ?></span></a><?php endwhile; wp_reset_postdata(); ?></div>
	</div>
</section>
<?php endif; ?>
<section id="journal" class="hq-section hq-journal-section">
	<div class="hq-container">
		<div class="hq-section-heading"><div><p class="hq-kicker">برای خواندن و عمیق‌تر دیدن</p><h2>یادداشت‌ها و <span>پژوهش‌ها</span></h2><p>روایت‌ها، پرسش‌ها و نگاه‌هایی به تاریخ قم.</p></div><a class="hq-text-link" href="<?php echo esc_url( hq_section_url( 'journal' ) ); ?>">همهٔ نوشته‌ها <?php echo hq_icon( 'arrow' ); ?></a></div>
		<div class="hq-journal-grid">
		<?php while ( $journal->have_posts() ) : $journal->the_post(); ?>
			<article class="hq-journal-card"><a class="hq-journal-image" href="<?php the_permalink(); ?>"><?php hq_post_image( get_the_ID() ); ?></a><div><p class="hq-article-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><span>·</span><?php the_author(); ?></p><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 22 ) ); ?></p><a class="hq-text-link" href="<?php the_permalink(); ?>">ادامهٔ روایت <?php echo hq_icon( 'arrow' ); ?></a></div></article>
		<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<?php if ( ! $journal->post_count ) : ?><p class="hq-empty-state">هنوز یادداشتی منتشر نشده است.</p><?php endif; ?>
	</div>
</section>
<section class="hq-community hq-container">
	<div class="hq-community-panel"><span class="hq-community-art" aria-hidden="true"><?php echo hq_icon( 'book' ); ?></span><div><p class="hq-kicker">همراه یک روایت ماندگار</p><h2>شناخت شهر، از کنجکاوی ما آغاز می‌شود.</h2><p>قم را بخوانیم، درباره‌اش بیشتر بدانیم و پیوند خود را با میراث شهر زنده نگه داریم.</p></div><?php if ( is_user_logged_in() ) : ?><a class="hq-btn hq-btn-gold" href="#encyclopedia">کاوش در دانشنامه <?php echo hq_icon( 'arrow' ); ?></a><?php elseif ( get_option( 'users_can_register' ) ) : ?><a class="hq-btn hq-btn-gold" href="<?php echo esc_url( native_registration_url() ); ?>">به همیار بپیوندید <?php echo hq_icon( 'arrow' ); ?></a><?php endif; ?></div>
</section>
</main>
<?php get_footer(); ?>
