/** Hamyaar Qom: accessible, dependency-free navigation and encyclopedia filters. */
document.addEventListener('DOMContentLoaded', function () {
  'use strict';
  document.body.classList.add('hq-js');
  var toggle = document.querySelector('.hq-menu-toggle');
  var navigation = document.getElementById('hq-navigation');
  function closeMenu() {
    if (!toggle || !navigation) return;
    toggle.setAttribute('aria-expanded', 'false');
    navigation.classList.remove('is-open');
  }
  if (toggle && navigation) {
    toggle.addEventListener('click', function () {
      var open = this.getAttribute('aria-expanded') !== 'true';
      this.setAttribute('aria-expanded', String(open));
      navigation.classList.toggle('is-open', open);
    });
    navigation.addEventListener('click', function (event) {
      if (event.target.closest('a')) closeMenu();
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        closeMenu();
        toggle.focus();
      }
    });
  }
  document.addEventListener('keydown', function (event) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      var input = document.getElementById('wiki-search-input') || document.querySelector('.hq-hero-search input');
      if (!input) return;
      event.preventDefault();
      input.focus({ preventScroll: true });
      input.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' });
    }
  });
  var buttons = document.querySelectorAll('.hq-az-btn');
  var cards = document.querySelectorAll('.hq-wiki-card');
  var search = document.getElementById('wiki-search-input');
  var counter = document.querySelector('.hq-wiki-count');
  var empty = document.getElementById('hq-wiki-empty');
  var letter = 'همه';
  function normalize(value) {
    return value.replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[\u200c\u200d\u200e\u200f]/g, '').trim().toLocaleLowerCase('fa');
  }
  function filterCards() {
    var query = normalize(search ? search.value : '');
    var visible = 0;
    cards.forEach(function (card) {
      var match = (letter === 'همه' || card.dataset.letter === letter) && normalize(card.dataset.title || '').includes(query);
      card.hidden = !match;
      if (match) visible++;
    });
    if (empty) empty.hidden = visible > 0;
    if (counter) counter.textContent = visible.toLocaleString('fa-IR') + ' مدخل در این بخش';
  }
  buttons.forEach(function (button) {
    button.addEventListener('click', function () {
      letter = this.dataset.letter;
      buttons.forEach(function (item) {
        var active = item === button;
        item.classList.toggle('active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      filterCards();
    });
  });
  if (search) search.addEventListener('input', filterCards);
});
