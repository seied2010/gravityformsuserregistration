# ساختار پایگاه داده — Schema 4 (۳۴ جدول)

تمام جدول‌ها پیشوند `{wpdb->prefix}agah_`، موتور InnoDB و charset سایت دارند. مبالغ BIGINT ریال، تاریخ حسابداری DATE میلادی و زمان ثبت UTC است. Schema 1 نسخهٔ ورودی بود؛ تحویل مراحل ۱–۳ با Schema 3 به‌صورت افزایشی نصب/ارتقا می‌شود. `schema_migrations(version,applied_at)` اجرای موفق نسخه را ثبت می‌کند؛ هیچ backfill یا حذف داده‌ای در این ارتقا وجود ندارد.

| جدول | کلید/رابطهٔ اصلی | کاربرد/حذف |
|---|---|---|
| companies | id، uuid یکتا | شرکت؛ حذف UI ندارد |
| roles | unique(company_id,role_key)، unique(company_id,id)، FK company | نقش مستقل شرکت؛ نقش سفارشی بدون سابقه قابل حذف |
| role_caps | role_id,cap؛ FK role با CASCADE | ماتریس مجوزهای نقش |
| company_members | company_id,user_id؛ FK مرکب نقش | عضویت؛ حذف منطقی status=removed |
| settings | company_id,skey | تنظیمات whitelist؛ company_id=0 پلتفرم |
| fiscal_years | company_id,id؛ FK company | سال مالی؛ closing_voucher_id رزرو مرحلهٔ ۱۱ |
| fiscal_periods | company_id,fiscal_year_id؛ FK مرکب سال | دوره‌های ماهانه |
| accounts | company_id,code/sys_key/id یکتا؛ parent_id FK مرکب | کدینگ؛ سیستم/دارای گردش حذف نمی‌شود |
| details | company_id,code/id یکتا؛ FK company | تفصیلی؛ دارای گردش حذف نمی‌شود |
| vouchers | uuid؛ unique(company_id,fiscal_year_id,number)؛ FK مرکب سال | number=NULL پیش‌نویس؛ revision جدید برای تعارض ویرایش |
| voucher_lines | company_id + voucher/account/detail FK مرکب | CASCADE فقط برای حذف پیش‌نویس از سرویس؛ FK از اتصال بیگانه جلوگیری می‌کند |
| sequences | company_id,fiscal_year_id,kind | شمارندهٔ تراکنشی بدون فاصله |
| audit_log | id؛ company_id,id یکتا؛ ایندکس شرکت/زمان، موجودیت و رویداد | فقط افزودنی؛ هش قبلی/فعلی؛ بدون حذف UI |
| idempotency | token SHA256 کلید اصلی؛ index(company_id,user_id)، expires_at | action، request_hash، pending/done و result_url؛ TTL ۲۴ ساعت |
| auth_states | user_id کلید اصلی | راز و راز معلق رمزنگاری‌شده، نشست/انقضای معلق، last_step، HMACهای بازیابی و version |
| rate_limits | bucket HMAC کلید اصلی؛ index expires_at | شمارندهٔ اتمیک با پنجرهٔ ثابت |
| login_otp | (user_id,session_hash) کلید اصلی؛ index expires_at | code_hash، انقضا، تلاش و مصرف |
| audit_heads | company_id کلید اصلی | mutex ردیفی تا commit؛ company_id=0 برای رویداد امنیتی |
| schema_migrations | version کلید اصلی | ثبت زمان موفقیت مهاجرت |

جدول‌های امنیت شخصی، به کاربر WordPress تعلق دارند و company_id ندارند؛ آن‌ها موجودیت تجاری بین‌شرکتی نیستند. idempotency و audit_heads ممکن است برای عمل پلتفرمی company_id=0 داشته باشند و به رکورد مالی خارجی اشاره نمی‌کنند؛ FK به companies برای این دو تعریف نشده است. روابط تجاری موجود با کلید مرکب حفظ شده‌اند و آزمون اتصال نقش/حساب/تفصیلی بیگانه در DB اجرا شده است.

```mermaid
erDiagram
 companies ||--o{ roles : company_id
 roles ||--o{ company_members : "company_id role_id"
 roles ||--o{ role_caps : role_id
 companies ||--o{ fiscal_years : company_id
 fiscal_years ||--o{ fiscal_periods : "company_id fiscal_year_id"
 fiscal_years ||--o{ vouchers : "company_id fiscal_year_id"
 vouchers ||--o{ voucher_lines : "company_id voucher_id"
 accounts ||--o{ voucher_lines : "company_id account_id"
 details ||--o{ voucher_lines : "company_id detail_id"
```

DDL مرجع در `erp/src/Core/Schema.php` است. هیچ مسیر downgrade خودکار وجود ندارد. بازگردانی نسخه از پشتیبان کامل فایل و DB انجام شود؛ تغییر شمارهٔ گزینهٔ Schema، جایگزین بازیابی نیست.


## افزوده‌های مراحل ۴ تا ۶

DDL مرجع جدید `Core/BusinessSchema.php` است و در Schema نصب می‌شود. تمام جدول‌های زیر id,uuid,company_id,created_at,updated_at و UNIQUE(company_id,id) دارند. همهٔ روابط تجاری FK مرکب‌اند؛ voucher_lines نیز کلید یکتای مرکب برای ارجاع مغایرت‌گیری گرفته است.

| جدول | محتوا و روابط |
|---|---|
| parties | کد یکتا، نوع، نقش مشتری/تأمین‌کننده، شناسهٔ رمزشده+ایندکس کور+hint، سقف اعتبار؛ detail_id |
| units / item_groups | واحد و گروه واقعی با code یکتا و وضعیت فعال |
| tax_rates | code+valid_from یکتا، بازهٔ زمانی، bp nullable، confirmed و revision |
| items | واحد/گروه/نرخ و دو حساب معین؛ قیمت صحیح ریال و بارکد یکتا |
| treasury_accounts | نوع bank/cash/petty، جزئیات بانکی، تفصیلی انحصاری و حساب معین |
| treasury_docs | نوع/سال/شمارهٔ یکتا، تاریخ، شخص/مبدأ/مقصد، پیش‌دریافت/پرداخت، مبلغ، سند و وضعیت |
| treasury_doc_items | شمارهٔ ردیف، روش، حساب، مبلغ و ارجاع؛ doc_id |
| cheques | برگه/قلم/شخص/بانک، جهت، شماره، سررسید، مبلغ، status/revision |
| cheque_events | وضعیت قبلی/جدید، تاریخ و دلیل، سند اختیاری برای گذار مالی |
| invoices / invoice_lines | قرارداد اولیهٔ تسویهٔ فاکتور و snapshot مالیات؛ UI صدور در مراحل ۷–۸ |
| settlements | فاکتور + برگه + قلم، مبلغ، active/reversed؛ برگشت قلم فقط سهم همان قلم را آزاد می‌کند |
| bank_reconciliations | بانک/تاریخ یکتا، ماندهٔ صورتحساب و revision |
| bank_reconciliation_items | سطر دفتر + مغایرت‌گیری؛ تطبیق اتمیک و هم‌بانکی در سرویس |

ارتقای ۳→۴ داده‌های قدیمی را نگه می‌دارد. فقط نقش company_admin مجوزهای جدید party.sensitive و tax_rate.confirm می‌گیرد؛ نقش سفارشی و حسابدار به‌صورت خودکار مجوز حساس نمی‌گیرند. ثبت مهاجرت نسخهٔ ۴ و دادهٔ پایهٔ واحد «عدد» و نرخ نامشخص، افزوده‌های مورد انتظارند. حذف رکوردهای دارای گردش/ارجاع ممنوع و حذف برگهٔ خزانه صرفاً ابطال است.
