/* افزودن اقلام/تخصیص‌ها با DOM محلی؛ اعتبارسنجی مرجع در سرور است. */
(function(){'use strict';document.querySelectorAll('[data-business-add]').forEach(button=>{
 const name=button.dataset.businessAdd,body=document.querySelector('[data-business-rows="'+name+'"]'),template=document.querySelector('[data-business-template="'+name+'"]');let index=body.children.length;
 button.addEventListener('click',()=>{if(body.children.length>=100)return;const row=template.content.firstElementChild.cloneNode(true);row.querySelectorAll('[name]').forEach(input=>{input.name=input.name.replace('__INDEX__',String(index));});index++;body.append(row);window.agahInitCalendars?.(row);row.querySelector('input,select')?.focus();});
 });document.addEventListener('click',event=>{const button=event.target.closest('[data-business-remove]');if(!button)return;const row=button.closest('[data-business-rows] > *');if(row)row.remove();});}());
