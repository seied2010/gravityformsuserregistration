<?php
if(!defined('ABSPATH')) exit;
/** اجرای یک‌دستوری آزمون روی وردپرس اختصاصی؛ دادهٔ آزمایشی می‌سازد و در محیط عملیاتی ممنوع است. */
if(!defined('ABSPATH') || !defined('WP_CLI') || !WP_CLI || !defined('AGAH_TEST_MODE') || !AGAH_TEST_MODE) {
    throw new RuntimeException('Set AGAH_TEST_MODE=true on a disposable WordPress test site only.');
}
$GLOBALS['agah_passed']=0;$GLOBALS['agah_failed']=0;
/** هر شکست exit غیرصفر دارد؛ استثناهای پیش‌بینی‌نشده آزمون بعدی را مخفی نمی‌کنند. */
function agah_test($name,callable $fn) {
    
    try {$ok=$fn();if($ok===false) throw new RuntimeException('Assertion returned false');$GLOBALS['agah_passed']++;echo 'PASS '.$name."\n";}
    catch(Throwable $e){$GLOBALS['agah_failed']++;echo 'FAIL '.$name.' — '.get_class($e).': '.$e->getMessage()."\n";}
}
function agah_assert($ok,$msg='Assertion failed') {if(!$ok) throw new RuntimeException($msg);}
function agah_throws($class,callable $fn) {
    try{$fn();}catch(Throwable $e){if($e instanceof $class)return;throw $e;}throw new RuntimeException('Expected '.$class);
}
function agah_test_rate_reset($key) {
    \Agah\Erp\Core\Db::delete('rate_limits',['bucket'=>\Agah\Erp\Core\Crypto::blind('rate|'.$key)]);
}
foreach(['unit/security.php','integration/core.php','security/access.php','integration/business.php'] as $file) require __DIR__.'/'.$file;
$passed=$GLOBALS['agah_passed'];$failed=$GLOBALS['agah_failed'];
echo "\nRESULT: $passed passed; $failed failed; 0 skipped\n";
if($failed) WP_CLI::error('Test failures: '.$failed);else WP_CLI::success('All selected tests executed.');
