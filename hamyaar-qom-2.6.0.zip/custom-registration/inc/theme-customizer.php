<?php
/** Modular, native Customizer controls for all visible homepage sections. */
defined( 'ABSPATH' ) || exit;

add_action( 'customize_register', function () {
	require_once get_theme_file_path( 'inc/customizer-controls.php' );
}, 1 );

add_action( 'customize_controls_enqueue_scripts', function () {
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_script( 'hq-theme-controls', get_theme_file_uri( 'assets/customizer-controls.js' ), array( 'jquery', 'jquery-ui-sortable', 'customize-controls' ), '2.6.0', true );
	wp_enqueue_style( 'hq-theme-controls', get_theme_file_uri( 'assets/customizer-controls.css' ), array(), '2.6.0' );
} );

function hq_sanitize_one_of( $value, $options, $default ) {
	return isset( $options[ $value ] ) ? $value : $default;
}

add_action( 'customize_register', function ( $customizer ) {
	$customizer->add_section( 'hq_home', array( 'title' => 'صفحهٔ اصلی همیار قم', 'priority' => 30 ) );
	$customizer->add_setting( 'hq_hero_image', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$customizer->add_control( new WP_Customize_Image_Control( $customizer, 'hq_hero_image', array( 'label' => 'تصویر اصلی صفحه نخست', 'section' => 'hq_home' ) ) );
	$customizer->add_setting( 'hq_hero_alt', array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
	$customizer->add_control( 'hq_hero_alt', array( 'label' => 'متن جایگزین تصویر اصلی', 'section' => 'hq_home' ) );
	$customizer->add_setting( 'hq_hero_side', array( 'default' => 'left', 'sanitize_callback' => static function ( $v ) { return in_array( $v, array( 'left', 'right' ), true ) ? $v : 'left'; } ) );
	$customizer->add_control( 'hq_hero_side', array( 'label' => 'سمت تصویر اصلی', 'section' => 'hq_home', 'type' => 'select', 'choices' => array( 'left' => 'چپ', 'right' => 'راست' ) ) );
	$customizer->add_setting( 'hq_hero_object_position', array( 'default' => '', 'sanitize_callback' => 'hq_sanitize_hero_position' ) );
	$customizer->add_control( 'hq_hero_object_position', array( 'label' => 'جهت و محل برش تصویر', 'section' => 'hq_home', 'type' => 'select', 'choices' => hq_hero_positions() ) );
	$customizer->add_setting( 'hq_hero_object_fit', array( 'default' => 'cover', 'sanitize_callback' => 'hq_sanitize_hero_fit' ) );
	$customizer->add_control( 'hq_hero_object_fit', array( 'label' => 'اندازه تصویر در قاب', 'section' => 'hq_home', 'type' => 'select', 'choices' => array( 'cover' => 'پر کردن قاب (با برش)', 'contain' => 'نمایش کامل تصویر (بدون برش)' ) ) );
	$customizer->add_section( 'hq_contact', array( 'title' => 'اطلاعات تماس و پیام‌رسان‌ها', 'priority' => 31 ) );
	foreach ( array( 'whatsapp' => 'واتس‌اپ', 'bale' => 'بله' ) as $key => $label ) {
		$setting = 'hq_social_' . $key;
		$customizer->add_setting( $setting, array( 'default' => hq_legacy_social_url( $key ), 'sanitize_callback' => 'hq_sanitize_social_url' ) );
		$customizer->add_control( $setting, array( 'label' => 'لینک ' . $label, 'type' => 'url', 'section' => 'hq_contact', 'description' => 'نشانی کامل https://…؛ برای مخفی شدن آیکون خالی بگذارید. شماره یا شناسه نسخه قبلی تا زمان ذخیره لینک جدید حفظ می‌شود.' ) );
	}
	$customizer->add_section( 'hq_footer_config', array( 'title' => 'پیوندهای پایین صفحه', 'priority' => 32 ) );
	$footer_categories = array( 0 => 'انتخاب خودکار ایران و جهان' );
	foreach ( get_categories( array( 'hide_empty' => false ) ) as $category ) { $footer_categories[ $category->term_id ] = $category->name; }
	$customizer->add_setting( 'hq_footer_iran_category', array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
	$customizer->add_control( 'hq_footer_iran_category', array( 'label' => 'دسته ایران و جهان', 'type' => 'select', 'section' => 'hq_footer_config', 'choices' => $footer_categories ) );
	$customizer->add_setting( 'hq_home_layout', array( 'default' => wp_json_encode( hq_layout_default() ), 'sanitize_callback' => 'hq_sanitize_home_layout' ) );
	$customizer->add_control( new HQ_Sortable_Sections_Control( $customizer, 'hq_home_layout', array( 'label' => 'چیدمان و نمایش بخش‌های صفحه اصلی', 'section' => 'hq_home', 'priority' => 1 ) ) );
	$home_text = array(
		'hq_hero_kicker' => array( 'عبارت بالای تیتر اصلی', 'پورتال تاریخ و میراث فرهنگی قم' ),
		'hq_hero_title' => array( 'تیتر اصلی (با Enter خط جدید بسازید)', "قم را دوباره ببینیم.\nاز دل تاریخ، تا امروز." ),
		'hq_hero_description' => array( 'توضیح آغازین', 'از روایت‌های کهن و چهره‌های ماندگار تا بناها و محله‌های تاریخی؛ همیار، دریچه‌ای برای شناخت عمیق‌تر قم.' ),
		'hq_hero_search_placeholder' => array( 'متن راهنمای جستجو', 'دنبال کدام نام، مکان یا روایت هستید؟' ),
		'hq_hero_caption_title' => array( 'عنوان زیر تصویر اصلی', 'هر گوشه، روایتی برای شنیدن' ),
		'hq_hero_caption_subtitle' => array( 'توضیح زیر تصویر اصلی', 'در جست‌وجوی لایه‌های پیدا و پنهان شهر' ),
		'hq_hero_image_label' => array( 'نوشته روی تصویر', 'میراثی برای دوباره دیدن' ),
		'hq_community_kicker' => array( 'عبارت بالای دعوت به همراهی', 'همراه یک روایت ماندگار' ),
		'hq_community_title' => array( 'عنوان دعوت به همراهی', 'شناخت شهر، از کنجکاوی ما آغاز می‌شود.' ),
		'hq_community_description' => array( 'توضیح دعوت به همراهی', 'قم را بخوانیم، درباره‌اش بیشتر بدانیم و پیوند خود را با میراث شهر زنده نگه داریم.' ),
	);
	foreach ( $home_text as $name => $settings ) {
		$customizer->add_setting( $name, array( 'default' => $settings[1], 'sanitize_callback' => 'sanitize_textarea_field' ) );
		$customizer->add_control( $name, array( 'label' => $settings[0], 'section' => 'hq_home', 'type' => in_array( $name, array( 'hq_hero_title', 'hq_hero_description', 'hq_community_description' ), true ) ? 'textarea' : 'text' ) );
	}
	// The three navigation cards are editable without changing template files.
	foreach ( array(
	    'wiki' => array( 'دانشنامهٔ قم', 'از نام‌ها، واژه‌ها و روایت‌ها بیشتر بدانید.' ),
	    'places' => array( 'قم‌شناسی', 'بناها و محله‌های تاریخی را از نو بشناسید.' ),
	    'journal' => array( 'یادداشت و پژوهش', 'با نگاه پژوهشگران، به گذشته سفر کنید.' ),
	) as $key => $defaults ) {
	    foreach ( array( 'title' => array( 'عنوان', $defaults[0] ), 'description' => array( 'توضیح', $defaults[1] ) ) as $suffix => $item ) {
	        $setting = "hq_path_{$key}_{$suffix}";
	        $customizer->add_setting( $setting, array( 'default' => $item[1], 'sanitize_callback' => 'sanitize_text_field' ) );
	        $customizer->add_control( $setting, array( 'label' => "کارت {$key}: " . $item[0], 'section' => 'hq_home', 'type' => 'text' ) );
	    }
	    $setting = "hq_path_{$key}_url";
	    $customizer->add_setting( $setting, array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	    $customizer->add_control( $setting, array( 'label' => "پیوند کارت {$key} (اختیاری)", 'section' => 'hq_home', 'type' => 'url', 'description' => 'در صورت خالی‌بودن، به بخش مرتبط در صفحه اصلی می‌رود.' ) );
	}
	// Footer and header editorial copy is managed from the Customizer.
	$editorial = array(
	    'hq_brand_title' => array( 'عنوان کنار لوگو', 'همیار قم', 'title_tagline' ),
	    'hq_brand_tagline' => array( 'شعار کنار لوگو', 'روایتِ تاریخ، پیوندِ امروز', 'title_tagline' ),
	    'hq_footer_description' => array( 'توضیح فوتر', 'دریچه‌ای به تاریخ، باستان‌شناسی و میراث فرهنگی قم؛ برای شناختن، خواندن و دوباره دیدن.', 'hq_footer_config' ),
	    'hq_footer_bottom_first' => array( 'متن خط اول کپی‌رایت', 'همیار قم · با احترام به گذشته، برای امروز', 'hq_footer_config' ),
	    'hq_footer_bottom_second' => array( 'متن خط دوم کپی‌رایت', 'تاریخ را زنده نگه داریم.', 'hq_footer_config' ),
	);
	foreach ( $editorial as $name => $settings ) {
	    $customizer->add_setting( $name, array( 'default' => $settings[1], 'sanitize_callback' => 'sanitize_text_field' ) );
	    $customizer->add_control( $name, array( 'label' => $settings[0], 'section' => $settings[2], 'type' => 'text' ) );
	}
	$customizer->add_panel( 'hq_sources_panel', array( 'title' => 'منابع و بخش‌های صفحه اصلی', 'description' => 'دسته هر بخش را انتخاب کنید. دانشنامه ۱۲ مطلب، مشاهیر و یادداشت‌ها هرکدام ۴ مطلب تازه را نمایش می‌دهند.', 'priority' => 33 ) );
	$categories = array( -1 => 'تشخیص خودکار از عنوان یا نامک', 0 => 'پیش‌فرض بخش (دانشنامه: تمام نوشته‌ها)' );
	foreach ( get_categories( array( 'hide_empty' => false ) ) as $category ) { $categories[ $category->term_id ] = $category->name . ' (' . $category->count . ')'; }

	$headings = array(
		'wiki' => array( 'واژه به واژه، نزدیک‌تر به قم', 'دانشنامه قم', 'جست‌وجویی میان نام‌ها، مکان‌ها و روایت‌های شهر.' ),
		'places' => array( 'رد پای تاریخ در کوچه‌های شهر', 'قم‌شناسی', 'میراثی که دیدنی‌ست' ),
		'history' => array( 'نام‌هایی در حافظهٔ شهر', 'مشاهیر و چهره‌ها', 'آشنایی با کسانی که نامشان با سرگذشت قم پیوند خورده است.' ),
		'journal' => array( 'برای خواندن و عمیق‌تر دیدن', 'یادداشت‌ها و پژوهش‌ها', 'روایت‌ها، پرسش‌ها و نگاه‌هایی به تاریخ قم.' ),
	);
	foreach ( hq_managed_sections() as $key => $title ) {
		$section_id = 'hq_source_' . $key;
		$customizer->add_section( $section_id, array( 'title' => $title, 'panel' => 'hq_sources_panel' ) );
		$customizer->add_setting( "hq_{$key}_category", array( 'default' => 'wiki' === $key ? 0 : -1, 'sanitize_callback' => 'hq_sanitize_section_category' ) );
		$customizer->add_control( "hq_{$key}_category", array( 'label' => 'دسته مطالب این بخش', 'type' => 'select', 'section' => $section_id, 'choices' => 'wiki' === $key ? array_replace( $categories, array( -1 => 'پیش‌فرض قدیمی: همه نوشته‌های تازه', 0 => 'همه نوشته‌های تازه' ) ) : $categories, 'description' => 'انتخاب دستی بر تشخیص خودکار اولویت دارد. بخش‌های قم‌شناسی، مشاهیر و یادداشت‌ها با دسته نامشخص یا خالی، مطالب نامرتبط نمایش نمی‌دهند.' ) );
		if ( 'places' === $key ) {
			$customizer->add_setting( 'hq_places_count', array( 'default' => 3, 'sanitize_callback' => 'hq_sanitize_section_count' ) );
			$customizer->add_control( 'hq_places_count', array( 'label' => 'تعداد مطالب قم‌شناسی', 'type' => 'number', 'section' => $section_id, 'input_attrs' => array( 'min' => 1, 'max' => 24 ) ) );
		}

		foreach ( array( 'kicker' => array( 'عبارت کوچک بالای عنوان', $headings[ $key ][0] ), 'title' => array( 'عنوان بخش', $headings[ $key ][1] ), 'description' => array( 'توضیح بخش', $headings[ $key ][2] ) ) as $suffix => $setting ) {
			$name = "hq_{$key}_{$suffix}";
			$customizer->add_setting( $name, array( 'default' => $setting[1], 'sanitize_callback' => 'sanitize_textarea_field' ) );
			$customizer->add_control( $name, array( 'label' => $setting[0], 'section' => $section_id, 'type' => 'text' ) );
		}
	}
	if ( isset( $customizer->selective_refresh ) ) {
	    $partials = array(
	        'hq_hero_kicker' => '.hq-hero .hq-kicker',
	        'hq_hero_title' => '.hq-hero h1',
	        'hq_hero_description' => '.hq-hero-description',
	        'hq_community_title' => '.hq-community h2',
	        'hq_community_description' => '.hq-community p:last-child',
	    );
	    foreach ( array( 'wiki' => '#encyclopedia', 'places' => '#heritage', 'history' => '#figures', 'journal' => '#journal' ) as $key => $selector ) {
	        $partials[ "hq_{$key}_title" ] = $selector . ' .hq-section-heading h2';
	        $partials[ "hq_{$key}_description" ] = $selector . ' .hq-section-heading>div>p:last-child';
	    }
	    foreach ( $partials as $setting => $selector ) {
	        $customizer->selective_refresh->add_partial( $setting, array(
	            'selector' => $selector,
	            'settings' => array( $setting ),
	            'render_callback' => static function () use ( $setting ) {
	                $value = get_theme_mod( $setting, '' );
	                return 'hq_hero_title' === $setting ? nl2br( esc_html( $value ) ) : esc_html( $value );
	            },
	        ) );
	    }
	}
	$customizer->add_section( 'hq_archives', array( 'title' => 'نمایش دسته‌ها و بایگانی', 'priority' => 34 ) );
	$customizer->add_setting( 'hq_archive_image_categories', array( 'default' => '[]', 'sanitize_callback' => 'hq_sanitize_category_list' ) );
	$customizer->add_control( new HQ_Category_Checklist_Control( $customizer, 'hq_archive_image_categories', array( 'label' => 'فقط مطالب عکس‌دار در دسته‌های منتخب', 'section' => 'hq_archives' ) ) );
	$customizer->add_section( 'hq_pages', array( 'title' => 'نمایش برگه‌ها و نوشته‌ها', 'priority' => 35 ) );
	$page_choices = array( 0 => 'تشخیص خودکار از عنوان «درباره»' );
	foreach ( get_pages( array( 'post_status' => 'publish' ) ) as $page ) { $page_choices[ $page->ID ] = $page->post_title; }
	$customizer->add_setting( 'hq_about_page_id', array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
	$customizer->add_control( 'hq_about_page_id', array( 'label' => 'برگه «درباره ما»', 'section' => 'hq_pages', 'type' => 'select', 'choices' => $page_choices ) );
	$customizer->add_setting( 'hq_default_page_width', array( 'default' => 'wide', 'sanitize_callback' => static function ( $v ) { return hq_sanitize_one_of( $v, array( 'normal' => 1, 'wide' => 1, 'full' => 1 ), 'wide' ); } ) );
	$customizer->add_control( 'hq_default_page_width', array( 'label' => 'عرض پیش‌فرض برگه‌ها', 'section' => 'hq_pages', 'type' => 'select', 'choices' => array( 'normal' => 'معمولی (مناسب مطالعه)', 'wide' => 'پهن', 'full' => 'حداکثر عرض نمایشگر' ) ) );
	$customizer->add_setting( 'hq_single_image_fit', array( 'default' => 'contain', 'sanitize_callback' => static function ( $v ) { return hq_sanitize_one_of( $v, array( 'contain' => 1, 'cover' => 1 ), 'contain' ); } ) );
	$customizer->add_control( 'hq_single_image_fit', array( 'label' => 'نمایش تصویر شاخص داخل نوشته', 'section' => 'hq_pages', 'type' => 'select', 'choices' => array( 'contain' => 'نمایش کامل، بدون برش (پیشنهادی)', 'cover' => 'برش متناسب برای قاب ثابت' ) ) );
} );

/** Per-page overrides are stored as metadata rather than changing the content. */
add_action( 'add_meta_boxes', function ( $type ) {
	if ( ! in_array( $type, array( 'page', 'post', 'hq_wiki', 'hq_place' ), true ) ) { return; }
	add_meta_box( 'hq-page-layout', 'چیدمان و نمایش محتوا – همیار', function ( $post ) {
		wp_nonce_field( 'hq_save_page_layout', 'hq_page_layout_nonce' );
		$align = get_post_meta( $post->ID, '_hq_page_align', true );
		$width = get_post_meta( $post->ID, '_hq_page_width', true );
		$fit = get_post_meta( $post->ID, '_hq_featured_fit', true );
		if ( 'page' === $post->post_type ) {
			echo '<p><label>تراز محتوای برگه یا نوشته<br><select class="widefat" name="hq_page_align">';
			foreach ( array( '' => 'پیش‌فرض قالب', 'center' => 'وسط‌چین', 'right' => 'راست‌چین' ) as $value => $label ) { echo '<option value="' . esc_attr( $value ) . '" ' . selected( $align, $value, false ) . '>' . esc_html( $label ) . '</option>'; }
			echo '</select></label></p><p><label>پهنای محتوای این صفحه<br><select class="widefat" name="hq_page_width">';
			foreach ( array( '' => 'پیش‌فرض قالب', 'normal' => 'معمولی', 'wide' => 'پهن', 'full' => 'تمام عرض' ) as $value => $label ) { echo '<option value="' . esc_attr( $value ) . '" ' . selected( $width, $value, false ) . '>' . esc_html( $label ) . '</option>'; }
			echo '</select></label></p>';
		} else { echo '<p>متن نوشته راست‌چین است؛ تصاویر در قاب مطالعهٔ ۸۶۰ پیکسلی وسط‌چین نمایش داده می‌شوند.</p>'; }
		echo '<p><label>تصویر شاخص<br><select class="widefat" name="hq_featured_fit">';
		foreach ( array( '' => 'پیش‌فرض قالب', 'contain' => 'نمایش کامل، بدون برش', 'cover' => 'برش و پر کردن قاب' ) as $value => $label ) { echo '<option value="' . esc_attr( $value ) . '" ' . selected( $fit, $value, false ) . '>' . esc_html( $label ) . '</option>'; }
		echo '</select></label></p>';
	}, $type, 'side', 'default' );
} );

add_action( 'save_post', function ( $post_id ) {
	if ( ! isset( $_POST['hq_page_layout_nonce'] ) || ! is_string( $_POST['hq_page_layout_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hq_page_layout_nonce'] ) ), 'hq_save_page_layout' ) || ! current_user_can( 'edit_post', $post_id ) || wp_is_post_revision( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) { return; }
	foreach ( array( 'hq_page_align' => array( 'center', 'right' ), 'hq_page_width' => array( 'normal', 'wide', 'full' ), 'hq_featured_fit' => array( 'contain', 'cover' ) ) as $name => $allowed ) {
		if ( ! isset( $_POST[ $name ] ) || ! is_string( $_POST[ $name ] ) ) { continue; }
		$value = sanitize_key( wp_unslash( $_POST[ $name ] ) );
		if ( in_array( $value, $allowed, true ) ) { update_post_meta( $post_id, '_' . $name, $value ); }
		else { delete_post_meta( $post_id, '_' . $name ); }
	}
} );

function hq_single_layout( $post_id ) {
	$align = get_post_meta( $post_id, '_hq_page_align', true );
	if ( ! in_array( $align, array( 'center', 'right' ), true ) ) {
		$is_about = 'page' === get_post_type( $post_id ) && ( (int) get_theme_mod( 'hq_about_page_id', 0 ) === (int) $post_id || ( ! get_theme_mod( 'hq_about_page_id' ) && false !== mb_strpos( (string) get_the_title( $post_id ), 'درباره' ) ) );
		$align = $is_about ? 'center' : 'right';
	}
	// Article text alignment is deliberately independent from About/page settings.
	if ( 'page' !== get_post_type( $post_id ) ) { $align = 'right'; }
	$width = get_post_meta( $post_id, '_hq_page_width', true );
	if ( ! in_array( $width, array( 'normal', 'wide', 'full' ), true ) ) { $width = get_theme_mod( 'hq_default_page_width', 'wide' ); }
	$fit = get_post_meta( $post_id, '_hq_featured_fit', true );
	if ( ! in_array( $fit, array( 'contain', 'cover' ), true ) ) { $fit = get_theme_mod( 'hq_single_image_fit', 'contain' ); }
	return array( 'hq-entry--align-' . $align, 'hq-entry--width-' . $width, 'hq-entry--fit-' . $fit );
}
