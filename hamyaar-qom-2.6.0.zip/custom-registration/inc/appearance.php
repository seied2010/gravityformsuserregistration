<?php
/** Sanitized appearance helpers shared by templates and the Customizer. */
defined( 'ABSPATH' ) || exit;

function hq_hero_positions() {
	return array( '' => 'حفظ محل برش نسخه قبلی', 'center center' => 'مرکز', 'top center' => 'بالا', 'bottom center' => 'پایین', 'center right' => 'راست', 'center left' => 'چپ' );
}

function hq_sanitize_hero_position( $value ) {
	return is_string( $value ) && isset( hq_hero_positions()[ $value ] ) ? $value : '';
}

function hq_hero_position() {
	$value = hq_sanitize_hero_position( get_theme_mod( 'hq_hero_object_position', '' ) );
	if ( $value ) { return $value; }
	$focus = array();
	foreach ( array( 'x', 'y' ) as $axis ) {
		$number = get_theme_mod( 'hq_hero_focus_' . $axis, '50' );
		$focus[] = in_array( (string) $number, array( '0', '25', '50', '75', '100' ), true ) ? $number . '%' : '50%';
	}
	return implode( ' ', $focus );
}

function hq_sanitize_hero_fit( $value ) {
	return in_array( $value, array( 'cover', 'contain' ), true ) ? $value : 'cover';
}

function hq_sanitize_social_url( $value ) {
	return is_string( $value ) ? esc_url_raw( $value, array( 'https', 'http' ) ) : '';
}

/** Preserve old phone/username values until an explicit URL is saved. */
function hq_legacy_social_url( $network ) {
	if ( 'whatsapp' === $network ) {
		$number = hq_sanitize_whatsapp_number( get_theme_mod( 'hq_whatsapp_number', '' ) );
		return $number ? 'https://wa.me/' . $number : '';
	}
	$username = hq_sanitize_bale_username( get_theme_mod( 'hq_bale_username', 'mahyarmusavi' ) );
	return $username ? 'https://ble.ir/' . $username : '';
}

function hq_social_url( $network ) {
	if ( ! in_array( $network, array( 'whatsapp', 'bale' ), true ) ) { return ''; }
	$value = get_theme_mod( 'hq_social_' . $network, null );
	return hq_sanitize_social_url( null === $value ? hq_legacy_social_url( $network ) : $value );
}

function hq_social_links() {
	$links = array( 'whatsapp' => 'واتس‌اپ', 'bale' => 'بله' );
	$items = '';
	foreach ( $links as $key => $label ) {
		$url = hq_social_url( $key );
		if ( ! $url ) { continue; }
		$items .= '<a class="hq-social-link" href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer nofollow" aria-label="' . esc_attr( $label ) . '">' . hq_icon( $key ) . '<span class="screen-reader-text">' . esc_html( $label ) . '</span></a>';
	}
	if ( $items ) { echo '<nav class="hq-social-links" aria-label="شبکه‌های اجتماعی">' . $items . '</nav>'; }
}

function hq_contact_channels() {
	if ( ! hq_social_url( 'whatsapp' ) && ! hq_social_url( 'bale' ) ) { return; }
	echo '<aside class="hq-contact-channels"><h2>ارتباط در پیام‌رسان‌ها</h2>';
	hq_social_links();
	echo '</aside>';
}
