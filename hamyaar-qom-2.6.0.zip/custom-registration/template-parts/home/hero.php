<?php defined( 'ABSPATH' ) || exit; ?>
<?php
$hero_image = get_theme_mod( 'hq_hero_image' ) ?: get_theme_file_uri( 'assets/hero.webp' );
$hero_side = get_theme_mod( 'hq_hero_side', 'left' );
$hero_side = in_array( $hero_side, array( 'left', 'right' ), true ) ? $hero_side : 'left';
$image_style = 'object-position:' . hq_hero_position() . ';object-fit:' . hq_sanitize_hero_fit( get_theme_mod( 'hq_hero_object_fit', 'cover' ) ) . ';';
?>
<section class="hq-hero hq-hero--image-<?php echo esc_attr( $hero_side ); ?>">
	<div class="hq-container hq-hero-grid">
		<div class="hq-hero-content">
			<p class="hq-kicker"><span></span><?php echo esc_html( get_theme_mod( 'hq_hero_kicker', 'پورتال تاریخ و میراث فرهنگی قم' ) ); ?></p>
			<h1><?php echo nl2br( esc_html( get_theme_mod( 'hq_hero_title', "قم را دوباره ببینیم.\nاز دل تاریخ، تا امروز." ) ) ); ?></h1>
			<p class="hq-hero-description"><?php echo esc_html( get_theme_mod( 'hq_hero_description', 'از روایت‌های کهن و چهره‌های ماندگار تا بناها و محله‌های تاریخی؛ همیار، دریچه‌ای برای شناخت عمیق‌تر قم.' ) ); ?></p>
			<form class="hq-hero-search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
				<label class="screen-reader-text" for="hero-search">جستجو در همیار قم</label>
				<?php echo hq_icon( 'search' ); ?><input id="hero-search" type="search" name="s" placeholder="<?php echo esc_attr( get_theme_mod( 'hq_hero_search_placeholder', 'دنبال کدام نام، مکان یا روایت هستید؟' ) ); ?>" autocomplete="off" required><button type="submit" class="hq-btn hq-btn-primary">جستجو</button>
			</form>
			<div class="hq-hero-hint"><span>یک نام، آغاز یک کشف تازه است.</span><span class="hq-shortcut" aria-hidden="true"><kbd>Ctrl</kbd><kbd>K</kbd></span></div>
			<div class="hq-topic-links"><span>از اینجا شروع کنید:</span><a href="<?php echo esc_url( hq_home_block_enabled( 'wiki' ) ? '#encyclopedia' : hq_section_url( 'wiki' ) ); ?>">ویکی قم</a><a href="<?php echo esc_url( hq_home_block_enabled( 'places' ) ? '#heritage' : hq_section_url( 'places' ) ); ?>">قم‌شناسی</a><a href="<?php echo esc_url( hq_home_block_enabled( 'journal' ) ? '#journal' : hq_section_url( 'journal' ) ); ?>">یادداشت‌ها</a></div>
		</div>
		<figure class="hq-hero-visual">
			<div class="hq-visual-frame"><img style="<?php echo esc_attr( $image_style ); ?>" src="<?php echo esc_url( $hero_image ); ?>" alt="<?php echo esc_attr( get_theme_mod( 'hq_hero_alt', 'امامزاده ابراهیم در قم؛ تصویر از آرشیو همیار قم' ) ); ?>" width="700" height="430" fetchpriority="high"></div>
			<figcaption><span class="hq-caption-icon"><?php echo hq_icon( 'arch' ); ?></span><span><strong><?php echo esc_html( get_theme_mod( 'hq_hero_caption_title', 'هر گوشه، روایتی برای شنیدن' ) ); ?></strong><small><?php echo esc_html( get_theme_mod( 'hq_hero_caption_subtitle', 'در جست‌وجوی لایه‌های پیدا و پنهان شهر' ) ); ?></small></span><span class="hq-caption-star" aria-hidden="true">✦</span></figcaption>
			<span class="hq-visual-label" aria-hidden="true"><?php echo esc_html( get_theme_mod( 'hq_hero_image_label', 'میراثی برای دوباره دیدن' ) ); ?></span>
		</figure>
	</div>
</section>
